package com.ap.demo.respository;

import java.util.List;

import com.ap.demo.model.BoE;

public interface BoERepository {

	public long save(BoE boe);

//	public boolean update(BoE boe);
	
//	public boolean delete(Long purchaseId);
	
	public List<BoE > findAll();
	
//	public Purchase findById(Long purchaseId);
	
//	public boolean isPurchasePresent(Purchase purchase);

//	public Purchase findByPurchaseBatchNumber(String purBatchNumber);

//	public Purchase findByPurchaseBatchNumberAndPartNumber(String purBatchNumber, String partNumber);

}
