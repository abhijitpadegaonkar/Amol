package com.ap.demo.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ap.demo.model.BoE;
import com.ap.demo.model.Item;
import com.ap.demo.model.Purchase;
import com.ap.demo.respository.BoERepository;
import com.ap.demo.respository.CompanyRepository;
import com.ap.demo.respository.ItemRepository;
import com.ap.demo.respository.PurchaseRepository;
import com.ap.demo.utils.Constants;

@Controller
public class BoEController {

	private static final Logger logger = LoggerFactory.getLogger(BoEController.class);

	@Autowired
	private BoERepository boeRepository;

	@Autowired
	private PurchaseRepository purchaseRepository;

	@Autowired
	private CompanyRepository companyRepository;
	
	@Autowired
	private ItemRepository itemRepository;
	
	@Value("${app.temp.upload.dir}")
	public String appTempUploadDir;

	@GetMapping("/boe-Master")
	public String showMasterPage() {
		logger.info("Showing master page.");
		return "boe-master";
	}

	@ResponseBody
	@GetMapping("/boe")
	public List<BoE> getBoE() {
		logger.info("Fetching all Bill of Entry details.");
		return boeRepository.findAll();
	}

//	@PostMapping("/remove-purchase")
//	@ResponseBody
//	public boolean remove(@RequestParam(name = "id") Long purchaseId) {
//		logger.info("Processing request to remove purchase. Purchase Id: {}", purchaseId);
//		return purchaseRepository.delete(purchaseId);
//	}

//	@GetMapping("/update-purchase")
//	public String showUpdatePurchaseForm(@RequestParam("id") Long purchaseId) {
//		logger.info("Showing update purchase page.");
//		purchaseRepository.findById(purchaseId);
//		return "update-purchase";
//	}

//	@PostMapping("/update-purchase")
//	@ResponseBody
//	public String showUpdatePurchaseForm(@RequestParam("id") Long purchaseId, @RequestParam("username") String username,
//			@RequestParam("compIec") String compIec, @RequestParam("partNumber") String partNumber,
//			@RequestParam("typeOfPurchase") String typeOfPurchase, @RequestParam("partDesc") String partDesc,
//			@RequestParam("uom") String uom, @RequestParam(name = "createdDate", required = false) String createdDate,
//			@RequestParam(name = "updateDate", required = false) String updateDate) {

//		logger.info("Handling update purchase request. {}, {}, {}, {}, {}, {}, {}, {}", username, compIec, partNumber,
//				typeOfPurchase, partDesc, uom, createdDate, updateDate);

//	Purchase purchase = new Purchase();
//		purchase.setId(purchaseId);
//		purchase.setUsername(username);
//		purchase.setCompIec(compIec);
//		purchase.setPartDesc(partDesc);
//		purchase.setPartNumber(partNumber);
//		purchase.setTypeOfPurchase(typeOfPurchase);
//		purchase.setUom(uom);

//		purchaseRepository.update(purchase);
//		return "update-purchase";
//	}

//	@GetMapping("/add-purchases")
//	public String showAddPurchasesForm() {
//		logger.info("Showing add purchases page.");
//		return "add-purchases";
//	}

	@PostMapping("/add-boe")
	public String addBoe(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {

		logger.info("Handling BoE creation via file upload request. Filename: {}", file.getOriginalFilename());

		List<BoE> Boes;
		try {

			if (file.isEmpty() || file.getSize() > 50097152) {
				logger.info("Uploaded file is empty or exceeds 50MB max size allowed. Filename: {}",
						file.getOriginalFilename());
				redirectAttributes.addFlashAttribute("error", "Please upload a file. Max 50MB file size is allowed.");
				return "redirect:add-purchases";
			}

			if (!file.getOriginalFilename().toLowerCase().endsWith(".xls")) {
				logger.info("Uploaded file is not a .xls file. Filename: {}", file.getOriginalFilename());
				redirectAttributes.addFlashAttribute("error", "Please upload .xls file.");
				return "redirect:add-purchases";
			}

			Path copyLocation = Paths.get(appTempUploadDir + File.separator + UUID.randomUUID().toString()
					+ StringUtils.cleanPath(file.getOriginalFilename()));
			try {
				Files.copy(file.getInputStream(), copyLocation, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				logger.info("Unable to save file: {}", file.getOriginalFilename());
				redirectAttributes.addFlashAttribute("error",
						"Unable to save file: " + file.getOriginalFilename() + ". Please try again.");
				return "redirect:add-purchases";
			}

			Boes = parseBoEDataFromXlsFile(copyLocation.toFile());
			List<String> errors = new ArrayList<String>();
			List<String> infos = new ArrayList<String>();
			errors = validateBoEData(Boes, "comp1");
			
			if (errors.isEmpty()) {
				for (BoE Boe : Boes) {
					try {
//						if (!purchaseRepository.isPurchasePresent(purchase)) {
							boeRepository.save(Boe);
							infos.add("Item added. version number: " + Boe.getVersion());
//						} else {
//							errors.add("Cannot add BoE. BoE already present with this version number: "
//									+ BoE.getVersion());
//						}
					} catch (DuplicateKeyException e) {
						logger.error("Cannot add BoE: {}, Some of follwing data is duplicate: Version Number.",
								Boe.getVersion(), e);
						errors.add("Cannot add BoE: " + Boe.getVersion()
								+ ". Some of follwing data is duplicate: Version Number.");
					}
				}
			}
			
			if (!infos.isEmpty()) {
				redirectAttributes.addFlashAttribute("infos", infos);
			}
			
			if (!errors.isEmpty()) {
				redirectAttributes.addFlashAttribute("errors", errors);
				return "redirect:/add-boe";
			}
		} catch (Exception e) {
			logger.error("Unable to upload file: {}", file.getOriginalFilename(), e);
			redirectAttributes.addFlashAttribute("error", "Unable to upload " + file.getOriginalFilename());
			return "redirect:/add-boe";
		}

		logger.info("Created purchases via file upload: {}", file.getOriginalFilename());
		redirectAttributes.addFlashAttribute("info",
				"Created Bill of Entry via " + file.getOriginalFilename() + " file upload.");
		return "redirect:/add-boe";
	}
	
	private List<BoE> parseBoEDataFromXlsFile(File file) throws ParseException {

		Workbook workbook = null;
		// Create the Workbook
		try {
			workbook = WorkbookFactory.create(file);
		} catch (EncryptedDocumentException | IOException e) {
			logger.error("Unable to process add BoE file. Filename: {} ", file.getName(), e);
		}

		// Getting the Sheet at index zero
		Sheet sheet = workbook.getSheetAt(0);

		// Getting number of columns in the Sheet
		int noOfColumns = sheet.getRow(0).getLastCellNum();
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		logger.info("Add purchases file has {} sheets and sheet 0 has {} columns", workbook.getNumberOfSheets(),
				noOfColumns);

		// header list
		List<String> headers = new ArrayList<>();
		headers.add("username");
		headers.add("compIec");
		headers.add("partNumber");
		headers.add("typeOfPurchase");
		headers.add("partDesc");
		headers.add("uom");
		headers.add("purBatchNumber");
		headers.add("grrQty");
		headers.add("grrNo");
		headers.add("purInvNo");
		headers.add("purInvDate");
		headers.add("inBondBoeNum");
		headers.add("inBondBoeDate");
		headers.add("portOfImport");
		headers.add("bottleSealNumber");
		headers.add("insuranceDetails");
		headers.add("perUnitCost");
		headers.add("totalPurValue");
		headers.add("dutyBcdRate");
		headers.add("dutyBcdAmt");
		headers.add("dutyCessBcdAmt");
		headers.add("dutyCessBcdRate");
		headers.add("dutyGstRate");
		headers.add("dutyGstAmt");
		headers.add("dutyCessGstRate");
		headers.add("dutyCessGstAmt");
		headers.add("dutyOtherRate");
		headers.add("dutyOtherAmt");
		headers.add("totalCustomDuty");
		headers.add("totalGst");
		headers.add("vehicleRegNum");
		headers.add("warehouseDate");
		headers.add("ewayBillNum");
		headers.add("ewayBillDate");
		headers.add("hsnNumber");

		int begin = sheet.getFirstRowNum();
		int end = sheet.getLastRowNum();
		logger.info("Sheet has first row num: {}, last: {}", begin, end);
		List<Map<String, String>> sheetData = new ArrayList<Map<String, String>>();
		boolean skipHeader = true;

		// loop each row
		for (int rowNum = begin; rowNum <= end; rowNum++) {
			Row row = sheet.getRow(rowNum);

			// Skip fist row as header
			if (skipHeader) {
				skipHeader = false;
				continue;
			}

			// identify empty row and add error for each empty row
			if (isEmptyRow(row)) {
				sheetData.add(null);
				logger.info("Empty row found. Row index: {}", rowNum);
				continue;
			}

			String columnName = null;
			String columnValue = null;
			Map<String, String> rowData = new LinkedHashMap<String, String>();

			// loop each cell in current row
			for (int i = 0; i < headers.size(); i++) {
				columnName = headers.get(i);
				Cell cell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

				switch (cell.getCellType()) {
				case STRING:
					columnValue = cell.getStringCellValue();
					break;
				case NUMERIC:
					if (DateUtil.isCellDateFormatted(cell)) {
						Date date = cell.getDateCellValue();
						columnValue = df.format(date);
					} else {
						cell.setCellType(CellType.STRING);
						columnValue = cell.getStringCellValue();
					}
					break;
				case BOOLEAN:
					columnValue = String.valueOf(cell.getBooleanCellValue());
					break;
				case BLANK:
					columnValue = "";
					break;
				case _NONE:
					columnValue = null;
					break;
				case ERROR:
					columnValue = String.valueOf(cell.getErrorCellValue());
					break;
				case FORMULA:
					switch (cell.getCachedFormulaResultType()) {
					case NUMERIC:
					case STRING:
						cell.setCellType(CellType.STRING);
						columnValue = cell.getStringCellValue();
						break;
					default:
						break;
					}
				default:
					columnValue = "";
				}

				// add extracted cell data to row map
				rowData.put(columnName, columnValue);
			}

			// add extracted row data to sheep map
			sheetData.add(rowData);
		}

		// load extracted data into data objects
		List<BoE> Boes = loadBoEData(sheetData);

		// Closing the workbook
		try {
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return Boes;
	}
	
	private List<BoE> loadBoEData(List<Map<String, String>> sheetData) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		
		List<BoE> Boes = new ArrayList<BoE>();
		for (Map<String, String> row : sheetData) {
			BoE boe = null;
			if (row != null) {
				boe = new BoE
						((row.get("Version")),
								(row.get("Sender")),
								(row.get("Receiver")),
								(row.get("NoOfDocuments")),
								(row.get("GeneratedOn")),
								(row.get("Generator")),
								(row.get("Doc_ID")),
								(row.get("Importer")),
								(row.get("ImporterBranchID")),
								(row.get("PartyBank")),
								(row.get("DestPort")),
								(row.get("TransportMode")),
								(row.get("TypeOfBE")),
								(row.get("PortOfShipment")),
								(row.get("FreightMode")),
								(row.get("CountryOfOrigin")),
								(row.get("AlternateCountryOfOrigin")),
								(row.get("CountryOfShipment")),
								(row.get("BEHeading")),
								(row.get("BENo")),
								(row.get("BEDate")),
								(row.get("Marks")),
								(row.get("FreightCurrency")),
								(row.get("FreightBank")),
								(row.get("FreightBankCert")),
								(row.get("FreightBankCertDate")),
								(row.get("FreightCurncRate")),
								(row.get("FreightRate")),
								(row.get("FreightAmount")),
								(row.get("InsuranceCurrency")),
								(row.get("InsuranceBank")),
								(row.get("InsuranceBankCert")),
								(row.get("InsuranceBankCertDate")),
								(row.get("InsuranceCurncRate")),
								(row.get("InsuranceRate")),
								(row.get("InsuranceBasis")),
								(row.get("InsuranceAmount")),
								(row.get("MiscCurrency")),
								(row.get("MiscBank")),
								(row.get("MiscBankCert")),
								(row.get("MiscBankCertDate")),
								(row.get("MiscCurncRate")),
								(row.get("MiscRate")),
								(row.get("MiscBasis")),
								(row.get("MiscAmount")),
								(row.get("AgencyCurrency")),
								(row.get("AgencyBank")),
								(row.get("AgencyBankCert")),
								(row.get("AgencyBankCertDate")),
								(row.get("AgencyRate")),
								(row.get("AgencyBasis")),
								(row.get("AgencyAmount")),
								(row.get("LoadingCurrency")),
								(row.get("LoadingBank")),
								(row.get("LoadingBankCert")),
								(row.get("LoadingBankCertDate")),
								(row.get("LoadingCurncRate")),
								(row.get("LoadingRate")),
								(row.get("LoadingBasis")),
								(row.get("LoadingAmount")),
								(row.get("WareHouse")),
								(row.get("WareHouseCode")),
								(row.get("PartyRef")),
								(row.get("RevenueDeposit")),
								(row.get("RevenueDepBasis")),
								(row.get("BECategory")),
								(row.get("FilingStatus")),
								(row.get("FirstCheck")),
								(row.get("FirstCheckRemarks")),
								(row.get("GreenChannel")),
								(row.get("GreenChannelRemarks")),
								(row.get("UnderSec46")),
								(row.get("UnderSec46Remarks")),
								(row.get("UnderSec48")),
								(row.get("UnderSec48Remarks")),
								(row.get("KachhaBE")),
								(row.get("KachhaBERemarks")),
								(row.get("HighSeaSale")),
								(row.get("HighSeaSellerIEC")),
								(row.get("HighSeaSellerBranchSNo")),
								(row.get("HighSeaSeller")),
								(row.get("HighSeaSellerAddress")),
								(row.get("HighSeaSellerCity")),
								(row.get("HighSeaSellerPinCode")),
								(row.get("StateCode")),
								(row.get("StateName")),
								(row.get("CommTaxType")),
//								(row.get("CommTax_Type")),
								(row.get("CommTaxRegnNo")),
								(row.get("ClearanceAgainstBond")),
								(row.get("BondDetails")),
								(row.get("ProcurementCertNumber")),
								(row.get("ProcurementCertDate")),
								(row.get("CertificateType")),
								(row.get("Commissionerate")),
								(row.get("Division")),
								(row.get("Range")),
								(row.get("FinalDestination")),
								(row.get("Remarks")),
								(row.get("TotalDuty")),
								(row.get("TotalCIFValue")),
								(row.get("TotalAssessableValue")),
								(row.get("TotalBasicDuty")),
								(row.get("TotalSurchargeDuty")),
								(row.get("TotalCVDDuty")),
								(row.get("TotalCustHealthCessDuty")),
								(row.get("Vessel")),
								(row.get("TranshipmentVessel")),
								(row.get("GoodsLandingDate")),
								(row.get("VoyageNumber")),
								(row.get("ETA")),
								(row.get("RotationNumber")),
								(row.get("RotationDate")),
								(row.get("LineNumber")),
								(row.get("Carrier")),
								(row.get("HAWBNumber")),
								(row.get("HAWBDate")),
								(row.get("MAWBNumber")),
								(row.get("MAWBDate")),
								(row.get("NoOfPkg")),
								(row.get("PkgUnit")),
								(row.get("SaidToContain")),
								(row.get("UnitOfSaidToContain")),
								(row.get("SaidToContain2")),
								(row.get("UnitOfSaidToContain2")),
								(row.get("GrossWeight")),
								(row.get("UnitOfGrossWeight")),
								(row.get("NetWeight")),
								(row.get("UnitOfNetWeight")),
								(row.get("PortOfReporting")),
								(row.get("GatewayIGMNo")),
								(row.get("GatewayIGMDate")),
								(row.get("GatewayInwardDate")),
								(row.get("ContainerNumber")),
								(row.get("SealNumber")),
								(row.get("ContainerSize")),
								(row.get("ContainerLoadType")),
								(row.get("ContainerType")),
								(row.get("TypeDesc")),
								(row.get("Truck_No")),
								(row.get("InvoiceNo")),
								(row.get("InvoiceDate")),
								(row.get("InvoiceCurrency")),
								(row.get("InvoiceBank")),
								(row.get("InvoiceBankCert")),
								(row.get("InvoiceBankCertDate")),
								(row.get("InvoiceCurncRate")),
								(row.get("InvoiceValue")),
								(row.get("ProductValue")),
								(row.get("TermsOfInvoice")),
								(row.get("Consignor")),
								(row.get("ConsignorCountry")),
								(row.get("Seller")),
								(row.get("SellerAddr")),
								(row.get("SellerCountry")),
								(row.get("Indentor")),
								(row.get("IndentorCountry")),
								(row.get("IndentorAddr")),
								(row.get("FreightCurrency2")),
								(row.get("FreightBank3")),
								(row.get("FreightBankCert4")),
								(row.get("FreightBankCertDate5")),
								(row.get("FreightCurncRate6")),
								(row.get("FreightRate7")),
								(row.get("FreightAmount8")),
								(row.get("InsuranceCurrency9")),
								(row.get("InsuranceBank10")),
								(row.get("InsuranceBankCert11")),
								(row.get("InsuranceBankCertDate12")),
								(row.get("InsuranceCurncRate13")),
								(row.get("InsuranceRate14")),
								(row.get("InsuranceBasis15")),
								(row.get("InsuranceAmount16")),
								(row.get("MiscCurrency17")),
								(row.get("MiscBank18")),
								(row.get("MiscBankCert19")),
								(row.get("MiscBankCertDate20")),
								(row.get("MiscCurncRate21")),
								(row.get("MiscRate22")),
								(row.get("MiscBasis23")),
								(row.get("MiscAmount24")),
								(row.get("AgencyCurrency25")),
								(row.get("AgencyBank26")),
								(row.get("AgencyBankCert27")),
								(row.get("AgencyBankCertDate28")),
								(row.get("AgencyCurncRate")),
								(row.get("AgencyRate29")),
								(row.get("AgencyBasis30")),
								(row.get("AgencyAmount31")),
								(row.get("LoadingCurrency32")),
								(row.get("LoadingBank33")),
								(row.get("LoadingBankCert34")),
								(row.get("LoadingBankCertDate35")),
								(row.get("LoadingCurncRate36")),
								(row.get("LoadingRate37")),
								(row.get("LoadingBasis38")),
								(row.get("LoadingAmount39")),
								(row.get("PaymentTerms")),
								(row.get("TransactionType")),
								(row.get("SaleCondition")),
								(row.get("LOCNumber")),
								(row.get("LOCDate")),
								(row.get("PurchaseOrdNo")),
								(row.get("PurchaseOrdDate")),
								(row.get("ContractNo")),
								(row.get("ContractDate")),
								(row.get("AppraiserRemark")),
								(row.get("SVBLoading")),
								(row.get("SVBRefNo")),
								(row.get("SVBRefDate")),
								(row.get("CustomsHouse")),
								(row.get("SVBLoadingBasis")),
								(row.get("SVBLoadingPerAssb")),
								(row.get("SVBLoadingPerDuty")),
								(row.get("SVBLoadingStatusAssb")),
								(row.get("SVBLoadingStatusDuty")),
								(row.get("Relation")),
								(row.get("RelationBase")),
								(row.get("RelationCondition")),
								(row.get("ValuationMethod")),
								(row.get("ThirdParty_Name")),
								(row.get("ThirdParty_Branch")),
								(row.get("ThirdParty_Address")),
								(row.get("ThirdParty_Cntry")),
								(row.get("ThirdParty_City")),
								(row.get("ThirdParty_State")),
								(row.get("ThirdParty_Pin")),
								(row.get("AEO_Cntry")),
								(row.get("AEO_Role")),
								(row.get("AEO_Code")),
								(row.get("TermsPlace")),
								(row.get("DiscountPer")),
								(row.get("DiscountAmt")),
								(row.get("DiscountType")),
								(row.get("HighSeaChrgPer")),
								(row.get("HighSeaChrgAmt")),
								(row.get("ContainerCostPer")),
								(row.get("ContainerCostAmt")),
								(row.get("OriginCountryPer")),
								(row.get("OriginCountryAmt")),
								(row.get("DocumentationPer")),
								(row.get("DocumentationAmt")),
								(row.get("HandlingCostPer")),
								(row.get("HandlingCostAmt")),
								(row.get("OtherChrgPer")),
								(row.get("OtherChrgAmt")),
								(row.get("PackingCostPer")),
								(row.get("PackingCostAmt")),
								(row.get("RoyaltyPer")),
								(row.get("RoyaltyAmt")),
								(row.get("BuyerServiceCostPer")),
								(row.get("BuyerServiceCostAmt")),
								(row.get("SellerObligationPer")),
								(row.get("SellerObligationAmt")))
/*								(row.get("ValueOfProceedsPer")),
								(row.get("ValueOfProceedsAmt")),
								(row.get("WarrantyServicePer")),
								(row.get("WarrantyServiceAmt")),
								(row.get("ProductDesc")),
								(row.get("ProductType")),
								(row.get("Quantity")),
								(row.get("Unit")),
								(row.get("UnitPrice")),
								(row.get("Amount")),
								(row.get("isFocItem")),
								(row.get("AltQuantity1")),
								(row.get("AltUnit1")),
								(row.get("AltQuantity2")),
								(row.get("AltUnit2")),
								(row.get("CTHNumber")),
								(row.get("RITCNumber")),
								(row.get("ITCLocation")),
								(row.get("BasicNotn")),
								(row.get("BasicNotnSNo")),
								(row.get("BasicDutyPer")),
								(row.get("BasicDutyFlag")),
								(row.get("BasicDutyQty")),
								(row.get("BasicDutyUnit")),
								(row.get("CustHealthCessNotn")),
								(row.get("CustHealthCessNotnSNo")),
								(row.get("CustHealthCessDutyPer")),
								(row.get("CustHealthCessDutyFlag")),
								(row.get("CustHealthCessDutyQty")),
								(row.get("CustHealthCessDutyUnit")),
								(row.get("AltBasicNotn")),
								(row.get("AltBasicNotnSNo")),
								(row.get("SurchargeNotn")),
								(row.get("SurchargeNotnSNo")),
								(row.get("SurchargeRate")),
								(row.get("AuxillaryNotn")),
								(row.get("AuxillaryDutyPer")),
								(row.get("AntiDumpRatePer")),
								(row.get("AntiDumpCurrency")),
								(row.get("AntiDumpBank")),
								(row.get("AntiDumpBankCert")),
								(row.get("AntiDumpBankCertDate")),
								(row.get("AntiDumpCurncRate")),
								(row.get("AntiDumpRateQty")),
								(row.get("AntiDumpUnit")),
								(row.get("AntiDumpNotn")),
								(row.get("AntiDumpSNo")),
								(row.get("AntiDump_CTH")),
								(row.get("AntiDump_Supplier_SNo")),
								(row.get("AntiDump_Qty")),
								(row.get("AntiDump_Tariff_Notn")),
								(row.get("AntiDump_Tariff_SNo")),
								(row.get("AntiDump_Tariff_Qty")),
								(row.get("AntiDump_CalcMethod")),
								(row.get("AntiDump_Tariff_Amt")),
								(row.get("AntiDump_Tariff_Cur")),
								(row.get("ManufCode")),
								(row.get("ManufAdd1")),
								(row.get("ManufAdd2")),
								(row.get("SourceCntry")),
								(row.get("TransitCntry")),
								(row.get("ManufCntry")),
								(row.get("ManufPostalCode")),
								(row.get("ManufState")),
								(row.get("ManufCodeType")),
								(row.get("AccessoryStatus")),
								(row.get("SWInfoReqd")),
								(row.get("RSP_Flag")),
								(row.get("CVDDutyExempFlag")),
								(row.get("AntiDump_Tariff_CRate")),
								(row.get("SAPTA_Notn")),
								(row.get("SAPTA_SNo")),
								(row.get("EDU_CESS_Notn")),
								(row.get("EDU_CESS_SNo")),
								(row.get("EDU_CESS_Rate")),
								(row.get("CEX_EDU_CESS_Notn")),
								(row.get("CEX_EDU_CESS_SNo")),
								(row.get("EDU_CESS_Rate_Excise")),
								(row.get("SHE_CESS_Notn")),
								(row.get("SHE_CESS_SNo")),
								(row.get("SHE_CESS_Rate")),
								(row.get("SHE_CESS_Rate_Excise")),
								(row.get("CETNumber")),
								(row.get("CVDNotn")),
								(row.get("CVDNotnSNo")),
								(row.get("CVDDutyPer")),
								(row.get("CVDDutyFlag")),
								(row.get("CVDDutyQty")),
								(row.get("CVDDutyUnit")),
								(row.get("ACVDNotn")),
								(row.get("ACVDNotnSNo")),
								(row.get("ACVDDutyPer")),
								(row.get("ACVDDutyFlag")),
								(row.get("ACVDDutyQty")),
								(row.get("ACVDDutyUnit")),
								(row.get("ACS2Notn")),
								(row.get("ACS2NotnSNo")),
								(row.get("ACS2DutyPer")),
								(row.get("ACS2DutyFlag")),
								(row.get("ACS2DutyQty")),
								(row.get("ACS2DutyUnit")),
								(row.get("SCVDNotn")),
								(row.get("SCVDNotnSNo")),
								(row.get("SCVDDutyPer")),
								(row.get("SCVDDutyFlag")),
								(row.get("SCVDDutyQty")),
								(row.get("SCVDDutyUnit")),
								(row.get("CESSNotn")),
								(row.get("CESSNotnSNo")),
								(row.get("CESSDutyPer")),
								(row.get("CESSDutyFlag")),
								(row.get("CESSDutyQty")),
								(row.get("CESSDutyUnit")),
								(row.get("NCDNotn")),
								(row.get("NCDNotnSNo")),
								(row.get("NCDDutyPer")),
								(row.get("NCDDutyFlag")),
								(row.get("NCDDutyQty")),
								(row.get("NCDDutyUnit")),
								(row.get("SADNotn")),
								(row.get("SADNotnSNo")),
								(row.get("SADDutyPer")),
								(row.get("HLTHNotn")),
								(row.get("HLTHNotnSNo")),
								(row.get("HLTHDutyPer")),
								(row.get("HLTHDutyFlag")),
								(row.get("HLTHDutyQty")),
								(row.get("HLTHDutyUnit")),
								(row.get("AddlDutyNotn")),
								(row.get("AddlDutyNotnSNo")),
								(row.get("AddlDutyPer")),
								(row.get("AggrDutyNotn")),
								(row.get("AggrDutyNotnSNo")),
								(row.get("AggrDutyPer")),
								(row.get("SGDutyNotn")),
								(row.get("SGDutyNotnSNo")),
								(row.get("SGDutyPer")),
								(row.get("IGSTNotnNo")),
								(row.get("IGSTNotnSrNo")),
								(row.get("IGSTNotnRatePer")),
								(row.get("IGSTNotnDutyFlag")),
								(row.get("IGSTNotnDutyQty")),
								(row.get("IGSTNotnDutyUnit")),
								(row.get("GSTCESSNotnNo")),
								(row.get("GSTCESSNotnSrNo")),
								(row.get("GSTCESSNotnRatePer")),
								(row.get("GSTCESSNotnDutyFlag")),
								(row.get("GSTCESSNotnDutyQty")),
								(row.get("GSTCESSNotnDutyUnit")),
								(row.get("IGSTExemptNotnNo")),
								(row.get("IGSTExemptNotnSrNo")),
								(row.get("IGSTExempNotnType")),
								(row.get("IGSTExempNotnRatePer")),
								(row.get("IGSTExemptNotnDutyFlag")),
								(row.get("IGSTExemptNotnDutyQty")),
								(row.get("IGSTExemptNotnDutyUnit")),
								(row.get("GSTCESSExemptNotnNo")),
								(row.get("GSTCESSExemptNotnSrNo")),
								(row.get("GSTCCESSExempNotnType")),
								(row.get("GSTCCESSExempNotnRatePer")),
								(row.get("GSTCCESSExemptNotnDutyFlag")),
								(row.get("GSTCCESSExemptNotnDutyQty")),
								(row.get("GSTCCESSExemptNotnDutyUnit")),
								(row.get("RD_INFRA_CESS_Notn")),
								(row.get("RD_INFRA_CESS_NotnSNo")),
								(row.get("RD_INFRA_CESS_DutyPer")),
								(row.get("RD_INFRA_CESS_DutyFlag")),
								(row.get("RD_INFRA_CESS_DutyQty")),
								(row.get("RD_INFRA_CESS_DutyUnit")),
								(row.get("SWSNotn")),
								(row.get("SWSNotnSNo")),
								(row.get("SWSDutyPer")),
								(row.get("ITCHSCode")),
								(row.get("PolicyPaara")),
								(row.get("PolicyYear")),
								(row.get("LoadingInPer")),
								(row.get("LoadingBasis40")),
								(row.get("LoadingInQty")),
								(row.get("LoadingAmount41")),
								(row.get("SVBRefNo42")),
								(row.get("SVBRefDate43")),
								(row.get("CustomsHouse44")),
								(row.get("SVBLoadingBasis45")),
								(row.get("SVBLoadingPerAssb46")),
								(row.get("SVBLoadingPerDuty47")),
								(row.get("SVBLoadingStatusAssb48")),
								(row.get("SVBLoadingStatusDuty49")),
								(row.get("GenericDesc")),
								(row.get("Accessory")),
								(row.get("Manufacturer")),
								(row.get("Brand")),
								(row.get("Model")),
								(row.get("EndUse")),
								(row.get("CountryOfOrigin50")),
								(row.get("MRPSNo")),
								(row.get("MRP")),
								(row.get("MRPUnit")),
								(row.get("Abatement")),
								(row.get("EXIMCode")),
								(row.get("SchemeNotn")),
								(row.get("SchemeNotnSNo")),
								(row.get("PrevImpBENo")),
								(row.get("PrevImpBEDate")),
								(row.get("PrevImpCurrency")),
								(row.get("PrevImpValue")),
								(row.get("PrevImpCustomHouse")),
								(row.get("MaterialCode")),
								(row.get("DutyRateType")),
								(row.get("RSPNotn")),
								(row.get("RSPNotnSNo")),
								(row.get("ReImportDtls")),
								(row.get("InfoType")),
								(row.get("InfoQualifier")),
								(row.get("InfoCode")),
								(row.get("InfoText")),
								(row.get("InfoMeasure")),
								(row.get("InfoMeasUnit")),
								(row.get("ImpProdConsts")),
								(row.get("ImpProdBatches")),
								(row.get("ImpProdControls")),
								(row.get("LicNo")),
								(row.get("LicDate")),
								(row.get("DebitValue")),
								(row.get("Quantity51")),
								(row.get("DocumentNo")),
								(row.get("ReleaseAdvNo")),
								(row.get("ReleaseAdvDate")),
								(row.get("RegisteredPort")),
								(row.get("ProdAmtRs")),
								(row.get("Freight")),
								(row.get("Insurance")),
								(row.get("Commission")),
								(row.get("Miscellaneous")),
								(row.get("CIFValue")),
								(row.get("AssessableValue")),
								(row.get("TotalBasicDutyAmt")),
								(row.get("TotalCVDAmt")),
								(row.get("TotalDutyAmt")))
*/;
			}
			Boes.add(boe);
		}
		return Boes;
	}
	
	private boolean isEmptyRow(Row row) {
		boolean isEmptyRow = true;
		if (row != null && row.getLastCellNum() > 0) {
			for (int cellNum = row.getFirstCellNum(); cellNum < row.getLastCellNum(); cellNum++) {
				Cell cell = row.getCell(cellNum);
				if (cell != null && cell.getCellType() != CellType.BLANK) {
					isEmptyRow = false;
					break;
				}
			}
		}
		return isEmptyRow;
	}

	private List<String> validateBoEData(List<BoE> boes, String username) {
		List<String> validationErrors = new ArrayList<String>();
		int rowCounter = 1;
		for (BoE boe : boes) {
			rowCounter++;
			List<String> errors = new ArrayList<String>();
			if (boe == null) {
				validationErrors.add("Row: " + rowCounter + " - No item data in file.");
				continue;
			}

			if (boe.getCompIec() == null || boe.getCompIec().equals("")) {
				errors.add("Row: " + rowCounter + " - IEC is required in BoE data.");
			} else {
				if (!Constants.validateByRegex(Constants.IEC_REGEX, boe.getCompIec())) {
					errors.add("Row: " + rowCounter
							+ " - Invalid IEC. IEC can contain alphanumeric characters and can be at max 20 characters in length.");
				}
			}

			if (boe.getUsername() == null || boe.getUsername().equals("")) {
				errors.add("Row: " + rowCounter + " - Username is required in BoE data.");
			} else {
				if (!Constants.validateByRegex(Constants.USERNAME_REGEX, boe.getUsername())) {
					errors.add("Row: " + rowCounter
							+ " - Invalid Username. Username can contain alphanumeric characters and can be at max 10 characters in length.");
				}
			}

			if (errors.isEmpty()) {
				String iec = companyRepository.getIecByUsername(boe.getUsername());
				if (iec == null || iec == "" || !iec.equalsIgnoreCase(boe.getCompIec())) {
					errors.add("Row: " + rowCounter
							+ " - Invalid IEC. Provided IEC is not registered against the company.");
				}
			}
			
			validationErrors.addAll(errors);	
		};
		return validationErrors;
	}

}

