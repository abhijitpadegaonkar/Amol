package com.ap.demo.respository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.ap.demo.model.Challan;
import com.ap.demo.controller.BillController;
import com.ap.demo.model.Bill;

@Repository
public class ChallanRepositoryImpl implements ChallanRepository {

	private static final Logger logger = LoggerFactory.getLogger(ChallanRepositoryImpl.class);
	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static String INSERT = "INSERT INTO challan_master (comp_iec,sales_batch_number,challan_number,challan_date,challan_amount,username,created_date,updated_date) "
			+ "VALUES (:comp_iec,:sales_batch_number,:challan_number,:challan_date,:challan_amount,:username,NOW(),NOW())";
	
	private static String UPDATE = "UPDATE challan_master SET " 
			+ "comp_iec = :comp_iec, "
			+ "sales_batch_number = :sales_batch_number, "
			+ "challan_number = :challan_number, "
			+ "challan_date = :challan_date, "
			+ "challan_amount = :challan_amount, "
			+ "updated_date = NOW() " 
			+ "WHERE id = :id";

	private static String SELECT = "SELECT * FROM challan_master";
	private static String DELETE = "DELETE FROM challan_master WHERE id = :id";
	private static String CHALLAN_ENTRIES = "SELECT * FROM challan_master WHERE comp_iec = :comp_iec AND sales_batch_number = :sales_batch_number";

	@Override
	public Challan findById(Long challanId) {
		return (Challan) namedParameterJdbcTemplate.queryForObject("select * from challan_master where id = :id",
				new MapSqlParameterSource("id", challanId), (rs, rowNum) -> challanMapper);

	}

	@Override
	public boolean delete(Long challanId) {
		SqlParameterSource namedParameters = new MapSqlParameterSource("id", challanId);
		int status = namedParameterJdbcTemplate.update(DELETE, namedParameters);
		return status != 0;
	}

	@Override
	public long save(Challan challan) {
		
		Map<String, Object> params = new HashMap<String, Object>();
		String delChallan = "delete from challan_master "
				+ "where username = :username AND "
				+ "comp_iec = :comp_iec AND "	
				+ "challan_number = :challan_number";

		params.put("comp_iec", challan.getCompIec());
		params.put("sales_batch_number", challan.getSalesBatchNumber());
		params.put("challan_number", challan.getChallanNumber());
		params.put("username", challan.getusername());
		params.put("challan_date", new Date());
		params.put("challan_amount", challan.getChallanAmount());
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource(params);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		
		 Double dutyPaid = Double.parseDouble(challan.getChallanAmount());
		boolean errStatus = updatePurchaseData(challan, dutyPaid);
		namedParameterJdbcTemplate.update(INSERT, sqlParameterSource, keyHolder);
		if (errStatus) {
			params.put("challan_number", challan.getChallanNumber());
			namedParameterJdbcTemplate.update(delChallan, params);
		}
		return keyHolder.getKey().longValue();
		
	}

	@Override
	public boolean update(Challan challan) {

		Map<String, Object> params = new HashMap<String, Object>();
		params.put("id", challan.getId());
		params.put("comp_iec", challan.getCompIec());
		params.put("pur_batch_number", challan.getSalesBatchNumber());
		params.put("challan_number", challan.getChallanNumber());
		params.put("challan_date", challan.getChallanDate());
		params.put("challan_amount", challan.getChallanAmount());

		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource(params);
		long updateCount = namedParameterJdbcTemplate.update(UPDATE, sqlParameterSource);
		return updateCount != 0;
	}

	@Override
	public List<Challan> findAll() {
		return namedParameterJdbcTemplate.query(SELECT, challanMapper);
	}

	@Override
	public List<Challan> findAllChallans(String companyIec, String purBatchNumber) {
		//return namedParameterJdbcTemplate.query(CHALLAN_ENTRIES, challanMapper);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("comp_iec", companyIec);
		params.put("pur_batch_number", purBatchNumber);
		
		return namedParameterJdbcTemplate.query(CHALLAN_ENTRIES,
				new MapSqlParameterSource(params), challanMapper);
	}
	
	private RowMapper<Challan> challanMapper = new RowMapper<Challan>() {

		@Override
		public Challan mapRow(ResultSet rs, int num) throws SQLException {
			Challan challan = new Challan();
			challan.setId(rs.getLong("id"));
			challan.setCompIec(rs.getString("comp_iec"));
			challan.setSalesBatchNumber(rs.getString("sales_batch_number"));
			challan.setusername(rs.getString("username"));
			challan.setChallanNumber(rs.getString("challan_number"));
			challan.setChallanDate(rs.getString("challan_date"));
			challan.setChallanAmount(rs.getString("challan_amount"));
			challan.setCreatedDate(rs.getString("created_date"));
			challan.setUpdateDate(rs.getString("updated_date"));
			
			return challan;
		}

	};
	private boolean updatePurchaseData (Challan challan, double dutyPaid){
	
		boolean errStatus = false;
		String selectProdBatch = "select prod_batch_number from sale_master "
				+ "where username = :username AND "
				+ "comp_iec = :comp_iec AND "
				+ "sales_batch_number = :sales_batch_number";
	
	String selectSaleDuty = "select sale_duty from sale_master "
			+ "where username = :username AND "
			+ "comp_iec = :comp_iec AND "
			+ "sales_batch_number = :sales_batch_number";
	
	String selectQuantity = "select quantity from sale_master "
			+ "where username = :username AND "
			+ "comp_iec = :comp_iec AND "
			+ "sales_batch_number = :sales_batch_number";
	
	String delChallan = "delete from challan_master "
			+ "where username = :username AND "
			+ "comp_iec = :comp_iec AND "	
			+ "challan_number = :challan_number";
	
	Map<String, Object> params1 = new HashMap<String, Object>();
	params1.put("username", challan.getusername());
	params1.put("comp_iec", challan.getCompIec());
	params1.put("sales_batch_number", challan.getSalesBatchNumber());
	String prodBatchNumber = namedParameterJdbcTemplate.queryForObject(selectProdBatch, params1, String.class);
	
	String saleDuty = namedParameterJdbcTemplate.queryForObject(selectSaleDuty, params1, String.class);
	double saledty = Double.parseDouble(saleDuty);
	if (dutyPaid != saledty) {
//		SqlParameterSource namedParameters = new MapSqlParameterSource("id", challan.getId());
		params1.put("challan_number", challan.getChallanNumber());
		namedParameterJdbcTemplate.update(delChallan, params1);
		logger.info("Unable to process Challan: {}", challan.getChallanNumber());
		logger.info("Duty to be paid and challan amount doesn't match");
		logger.info("duty to be paid = ", saledty);
		logger.info("Duty Paid = ", dutyPaid);
		errStatus = true;
		
	} else {
	String saleQuantity = namedParameterJdbcTemplate.queryForObject(selectQuantity, params1, String.class);
	Double saleQty = Double.parseDouble(saleQuantity); 

	List<Bill> challansBill = findAllBillsForChallan(challan.getusername(), challan.getCompIec(),prodBatchNumber);

	selectBillData(challansBill, saleQty,dutyPaid);
	}
	return errStatus;
	}
	
	public List<Bill> findAllBillsForChallan(String username1, String compIec1, String prodBatchNumber1) {
     System.out.println("entered into find bills for challan");
//		String selectBillData = "select pur_batch_number, part_number, anticipated_no_of_fgs "
		String selectBillData = "select * "
				+ "from bill_master "
				+ "where username = :username AND "
				+ "comp_iec = :comp_iec AND "
				+ "prod_batch_number = :prod_batch_number";

		Map<String, Object> params2 = new HashMap<String, Object>();
		params2.put("comp_iec", compIec1);
		params2.put("prod_batch_number", prodBatchNumber1);
		params2.put("username", username1);
		
		return namedParameterJdbcTemplate.query(selectBillData,
				new MapSqlParameterSource(params2), challanMapper1);
	
	};	
	private RowMapper<Bill> challanMapper1 = new RowMapper<Bill>() {

		@Override
		public Bill mapRow(ResultSet rs, int num) throws SQLException {
			Bill bill = new Bill();
//			challan.setSalesBatchNumber(rs.getString("sales_batch_number"));
//			challan.setCompIec(rs.getString("comp_iec"));
			bill.setPurBatchNumber(rs.getString("pur_batch_number"));
			bill.setPartNumber(rs.getString("part_number"));
			bill.setAnticipatedNoOfFGS(rs.getString("anticipated_no_of_fgs"));
			bill.setUsername(rs.getString("username"));
			bill.setCompIec(rs.getString("comp_iec"));
			bill.setTotalDutyPerFG(rs.getString("total_duty_per_FG"));
			return bill;
		}
};
	private void selectBillData (List<Bill> bills, double saleQty, double dutyPaid) {
		int rowCounter = 0;
		double calcTotalDutyPaid = 0;
		for (Bill bill : bills) {
			if (bill.getPartNumber() != null ) {
				double TotalDutyPerFG = Double.parseDouble(bill.getTotalDutyPerFG());
				double calcDutyByPartNumber = TotalDutyPerFG * saleQty;
				updatePurchaseMaster(bill, saleQty, dutyPaid, calcDutyByPartNumber);
				calcTotalDutyPaid = calcTotalDutyPaid + calcDutyByPartNumber;
				rowCounter++;
			}
		}
		System.out.println(calcTotalDutyPaid);
		System.out.println(dutyPaid);
	}
	private void updatePurchaseMaster(Bill bill, double saleQty, double dutyPaid, double calcDutyByPartNumber) {
		String dutyPaidAmt = "select duty_paid_amount from purchase_master "
				+ "where username = :username AND "
				+ "comp_iec = :comp_iec AND "
				+ "pur_batch_number = :pur_batch_number AND "
				+ "part_number = :part_number";

		String dutyBal = "select balance_duty from purchase_master "
				+ "where username = :username AND "
				+ "comp_iec = :comp_iec AND "
				+ "pur_batch_number = :pur_batch_number AND "
				+ "part_number = :part_number";
		
		String exBondDutyMemo = "select exbond_memo_duty from purchase_master "
				+ "where username = :username AND "
				+ "comp_iec = :comp_iec AND "
				+ "pur_batch_number = :pur_batch_number AND "
				+ "part_number = :part_number";
		
		String updatePM = "update purchase_master set "
				+ "exbond_memo_duty = :dtyMemoAmt, "
				+ "balance_duty = :dtyBalAmt, "
				+ "duty_paid_amount = :dtyPaidAmt "
				+ "where username = :username AND "
				+ "comp_iec = :comp_iec AND "
				+ "pur_batch_number = :pur_batch_number AND "
				+ "part_number = :part_number";
		Map<String, Object> params1 = new HashMap<String, Object>();
		params1.put("username", bill.getUsername());
		params1.put("comp_iec", bill.getCompIec());
		params1.put("pur_batch_number", bill.getPurBatchNumber());
		params1.put("part_number", bill.getPartNumber());
		String dutyPaidAmount = namedParameterJdbcTemplate.queryForObject(dutyPaidAmt, params1, String.class);
		String dutyBalAmount = namedParameterJdbcTemplate.queryForObject(dutyBal, params1, String.class);
		String dutyMemoAmount = namedParameterJdbcTemplate.queryForObject(exBondDutyMemo, params1, String.class);
		Double dtyPaidAmt = Double.parseDouble(dutyPaidAmount) + calcDutyByPartNumber;
		Double dtyBalAmt = Double.parseDouble(dutyBalAmount) - calcDutyByPartNumber;
		Double dtyMemoAmt = Double.parseDouble(dutyMemoAmount) - calcDutyByPartNumber;
		params1.put("dtyMemoAmt", dtyMemoAmt);
		params1.put("dtyBalAmt", dtyBalAmt);
		params1.put("dtyPaidAmt", dtyPaidAmt);
		namedParameterJdbcTemplate.update(updatePM, params1);
// write update query here	
	}
};
