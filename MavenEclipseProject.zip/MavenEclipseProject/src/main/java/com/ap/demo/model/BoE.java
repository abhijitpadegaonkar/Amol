package com.ap.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "bill_of_entry")
public class BoE {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "username")
	private String username;

	@Column(name = "comp_iec")
	private String compIec;

	 @Column(name = "Version") private String version;
	 @Column(name = "Sender") private String sender;
	 @Column(name = "Receiver") private String receiver;
	 @Column(name = "NoOfDocuments") private String noOfDocuments;
	 @Column(name = "GeneratedOn") private String generatedOn;
	 @Column(name = "Generator") private String generator;
	 @Column(name = "Doc_ID") private String doc_ID;
	 @Column(name = "Importer") private String importer;
	 @Column(name = "ImporterBranchID") private String importerBranchID;
	 @Column(name = "PartyBank") private String partyBank;
	 @Column(name = "DestPort") private String destPort;
	 @Column(name = "TransportMode") private String transportMode;
	 @Column(name = "TypeOfBE") private String typeOfBE;
	 @Column(name = "PortOfShipment") private String portOfShipment;
	 @Column(name = "FreightMode") private String freightMode;
	 @Column(name = "CountryOfOrigin") private String countryOfOrigin;
	 @Column(name = "AlternateCountryOfOrigin") private String alternateCountryOfOrigin;
	 @Column(name = "CountryOfShipment") private String countryOfShipment;
	 @Column(name = "BEHeading") private String bEHeading;
	 @Column(name = "BENo") private String bENo;
	 @Column(name = "BEDate") private String bEDate;
	 @Column(name = "Marks") private String marks;
	 @Column(name = "FreightCurrency") private String freightCurrency;
	 @Column(name = "FreightBank") private String freightBank;
	 @Column(name = "FreightBankCert") private String freightBankCert;
	 @Column(name = "FreightBankCertDate") private String freightBankCertDate;
	 @Column(name = "FreightCurncRate") private String freightCurncRate;
	 @Column(name = "FreightRate") private String freightRate;
	 @Column(name = "FreightAmount") private String freightAmount;
	 @Column(name = "InsuranceCurrency") private String insuranceCurrency;
	 @Column(name = "InsuranceBank") private String insuranceBank;
	 @Column(name = "InsuranceBankCert") private String insuranceBankCert;
	 @Column(name = "InsuranceBankCertDate") private String insuranceBankCertDate;
	 @Column(name = "InsuranceCurncRate") private String insuranceCurncRate;
	 @Column(name = "InsuranceRate") private String insuranceRate;
	 @Column(name = "InsuranceBasis") private String insuranceBasis;
	 @Column(name = "InsuranceAmount") private String insuranceAmount;
	 @Column(name = "MiscCurrency") private String miscCurrency;
	 @Column(name = "MiscBank") private String miscBank;
	 @Column(name = "MiscBankCert") private String miscBankCert;
	 @Column(name = "MiscBankCertDate") private String miscBankCertDate;
	 @Column(name = "MiscCurncRate") private String miscCurncRate;
	 @Column(name = "MiscRate") private String miscRate;
	 @Column(name = "MiscBasis") private String miscBasis;
	 @Column(name = "MiscAmount") private String miscAmount;
	 @Column(name = "AgencyCurrency") private String agencyCurrency;
	 @Column(name = "AgencyBank") private String agencyBank;
	 @Column(name = "AgencyBankCert") private String agencyBankCert;
	 @Column(name = "AgencyBankCertDate") private String agencyBankCertDate;
	 @Column(name = "AgencyRate") private String agencyRate;
	 @Column(name = "AgencyBasis") private String agencyBasis;
	 @Column(name = "AgencyAmount") private String agencyAmount;
	 @Column(name = "LoadingCurrency") private String loadingCurrency;
	 @Column(name = "LoadingBank") private String loadingBank;
	 @Column(name = "LoadingBankCert") private String loadingBankCert;
	 @Column(name = "LoadingBankCertDate") private String loadingBankCertDate;
	 @Column(name = "LoadingCurncRate") private String loadingCurncRate;
	 @Column(name = "LoadingRate") private String loadingRate;
	 @Column(name = "LoadingBasis") private String loadingBasis;
	 @Column(name = "LoadingAmount") private String loadingAmount;
	 @Column(name = "WareHouse") private String wareHouse;
	 @Column(name = "WareHouseCode") private String wareHouseCode;
	 @Column(name = "PartyRef") private String partyRef;
	 @Column(name = "RevenueDeposit") private String revenueDeposit;
	 @Column(name = "RevenueDepBasis") private String revenueDepBasis;
	 @Column(name = "BECategory") private String bECategory;
	 @Column(name = "FilingStatus") private String filingStatus;
	 @Column(name = "FirstCheck") private String firstCheck;
	 @Column(name = "FirstCheckRemarks") private String firstCheckRemarks;
	 @Column(name = "GreenChannel") private String greenChannel;
	 @Column(name = "GreenChannelRemarks") private String greenChannelRemarks;
	 @Column(name = "UnderSec46") private String underSec46;
	 @Column(name = "UnderSec46Remarks") private String underSec46Remarks;
	 @Column(name = "UnderSec48") private String underSec48;
	 @Column(name = "UnderSec48Remarks") private String underSec48Remarks;
	 @Column(name = "KachhaBE") private String kachhaBE;
	 @Column(name = "KachhaBERemarks") private String kachhaBERemarks;
	 @Column(name = "HighSeaSale") private String highSeaSale;
	 @Column(name = "HighSeaSellerIEC") private String highSeaSellerIEC;
	 @Column(name = "HighSeaSellerBranchSNo") private String highSeaSellerBranchSNo;
	 @Column(name = "HighSeaSeller") private String highSeaSeller;
	 @Column(name = "HighSeaSellerAddress") private String highSeaSellerAddress;
	 @Column(name = "HighSeaSellerCity") private String highSeaSellerCity;
	 @Column(name = "HighSeaSellerPinCode") private String highSeaSellerPinCode;
	 @Column(name = "StateCode") private String stateCode;
	 @Column(name = "StateName") private String stateName;
	 @Column(name = "CommTaxType") private String commTaxType;
//	 @Column(name = "CommTax_Type") private String commTax_Type;
	 @Column(name = "CommTaxRegnNo") private String commTaxRegnNo;
	 @Column(name = "ClearanceAgainstBond") private String clearanceAgainstBond;
	 @Column(name = "BondDetails") private String bondDetails;
	 @Column(name = "ProcurementCertNumber") private String procurementCertNumber;
	 @Column(name = "ProcurementCertDate") private String procurementCertDate;
	 @Column(name = "CertificateType") private String certificateType;
	 @Column(name = "Commissionerate") private String commissionerate;
	 @Column(name = "Division") private String division;
	 @Column(name = "Range") private String range;
	 @Column(name = "FinalDestination") private String finalDestination;
	 @Column(name = "Remarks") private String remarks;
	 @Column(name = "TotalDuty") private String totalDuty;
	 @Column(name = "TotalCIFValue") private String totalCIFValue;
	 @Column(name = "TotalAssessableValue") private String totalAssessableValue;
	 @Column(name = "TotalBasicDuty") private String totalBasicDuty;
	 @Column(name = "TotalSurchargeDuty") private String totalSurchargeDuty;
	 @Column(name = "TotalCVDDuty") private String totalCVDDuty;
	 @Column(name = "TotalCustHealthCessDuty") private String totalCustHealthCessDuty;
	 @Column(name = "Vessel") private String vessel;
	 @Column(name = "TranshipmentVessel") private String transhipmentVessel;
	 @Column(name = "GoodsLandingDate") private String goodsLandingDate;
	 @Column(name = "VoyageNumber") private String voyageNumber;
	 @Column(name = "ETA") private String eTA;
	 @Column(name = "RotationNumber") private String rotationNumber;
	 @Column(name = "RotationDate") private String rotationDate;
	 @Column(name = "LineNumber") private String lineNumber;
	 @Column(name = "Carrier") private String carrier;
	 @Column(name = "HAWBNumber") private String hAWBNumber;
	 @Column(name = "HAWBDate") private String hAWBDate;
	 @Column(name = "MAWBNumber") private String mAWBNumber;
	 @Column(name = "MAWBDate") private String mAWBDate;
	 @Column(name = "NoOfPkg") private String noOfPkg;
	 @Column(name = "PkgUnit") private String pkgUnit;
	 @Column(name = "SaidToContain") private String saidToContain;
	 @Column(name = "UnitOfSaidToContain") private String unitOfSaidToContain;
	 @Column(name = "SaidToContain2") private String saidToContain2;
	 @Column(name = "UnitOfSaidToContain2") private String unitOfSaidToContain2;
	 @Column(name = "GrossWeight") private String grossWeight;
	 @Column(name = "UnitOfGrossWeight") private String unitOfGrossWeight;
	 @Column(name = "NetWeight") private String netWeight;
	 @Column(name = "UnitOfNetWeight") private String unitOfNetWeight;
	 @Column(name = "PortOfReporting") private String portOfReporting;
	 @Column(name = "GatewayIGMNo") private String gatewayIGMNo;
	 @Column(name = "GatewayIGMDate") private String gatewayIGMDate;
	 @Column(name = "GatewayInwardDate") private String gatewayInwardDate;
	 @Column(name = "ContainerNumber") private String containerNumber;
	 @Column(name = "SealNumber") private String sealNumber;
	 @Column(name = "ContainerSize") private String containerSize;
	 @Column(name = "ContainerLoadType") private String containerLoadType;
	 @Column(name = "ContainerType") private String containerType;
	 @Column(name = "TypeDesc") private String typeDesc;
	 @Column(name = "Truck_No") private String truck_No;
	 @Column(name = "InvoiceNo") private String invoiceNo;
	 @Column(name = "InvoiceDate") private String invoiceDate;
	 @Column(name = "InvoiceCurrency") private String invoiceCurrency;
	 @Column(name = "InvoiceBank") private String invoiceBank;
	 @Column(name = "InvoiceBankCert") private String invoiceBankCert;
	 @Column(name = "InvoiceBankCertDate") private String invoiceBankCertDate;
	 @Column(name = "InvoiceCurncRate") private String invoiceCurncRate;
	 @Column(name = "InvoiceValue") private String invoiceValue;
	 @Column(name = "ProductValue") private String productValue;
	 @Column(name = "TermsOfInvoice") private String termsOfInvoice;
	 @Column(name = "Consignor") private String consignor;
	 @Column(name = "ConsignorCountry") private String consignorCountry;
	 @Column(name = "Seller") private String seller;
	 @Column(name = "SellerAddr") private String sellerAddr;
	 @Column(name = "SellerCountry") private String sellerCountry;
	 @Column(name = "Indentor") private String indentor;
	 @Column(name = "IndentorCountry") private String indentorCountry;
	 @Column(name = "IndentorAddr") private String indentorAddr;
	 @Column(name = "FreightCurrency2") private String freightCurrency2;
	 @Column(name = "FreightBank3") private String freightBank3;
	 @Column(name = "FreightBankCert4") private String freightBankCert4;
	 @Column(name = "FreightBankCertDate5") private String freightBankCertDate5;
	 @Column(name = "FreightCurncRate6") private String freightCurncRate6;
	 @Column(name = "FreightRate7") private String freightRate7;
	 @Column(name = "FreightAmount8") private String freightAmount8;
	 @Column(name = "InsuranceCurrency9") private String insuranceCurrency9;
	 @Column(name = "InsuranceBank10") private String insuranceBank10;
	 @Column(name = "InsuranceBankCert11") private String insuranceBankCert11;
	 @Column(name = "InsuranceBankCertDate12") private String insuranceBankCertDate12;
	 @Column(name = "InsuranceCurncRate13") private String insuranceCurncRate13;
	 @Column(name = "InsuranceRate14") private String insuranceRate14;
	 @Column(name = "InsuranceBasis15") private String insuranceBasis15;
	 @Column(name = "InsuranceAmount16") private String insuranceAmount16;
	 @Column(name = "MiscCurrency17") private String miscCurrency17;
	 @Column(name = "MiscBank18") private String miscBank18;
	 @Column(name = "MiscBankCert19") private String miscBankCert19;
	 @Column(name = "MiscBankCertDate20") private String miscBankCertDate20;
	 @Column(name = "MiscCurncRate21") private String miscCurncRate21;
	 @Column(name = "MiscRate22") private String miscRate22;
	 @Column(name = "MiscBasis23") private String miscBasis23;
	 @Column(name = "MiscAmount24") private String miscAmount24;
	 @Column(name = "AgencyCurrency25") private String agencyCurrency25;
	 @Column(name = "AgencyBank26") private String agencyBank26;
	 @Column(name = "AgencyBankCert27") private String agencyBankCert27;
	 @Column(name = "AgencyBankCertDate28") private String agencyBankCertDate28;
	 @Column(name = "AgencyCurncRate") private String agencyCurncRate;
	 @Column(name = "AgencyRate29") private String agencyRate29;
	 @Column(name = "AgencyBasis30") private String agencyBasis30;
	 @Column(name = "AgencyAmount31") private String agencyAmount31;
	 @Column(name = "LoadingCurrency32") private String loadingCurrency32;
	 @Column(name = "LoadingBank33") private String loadingBank33;
	 @Column(name = "LoadingBankCert34") private String loadingBankCert34;
	 @Column(name = "LoadingBankCertDate35") private String loadingBankCertDate35;
	 @Column(name = "LoadingCurncRate36") private String loadingCurncRate36;
	 @Column(name = "LoadingRate37") private String loadingRate37;
	 @Column(name = "LoadingBasis38") private String loadingBasis38;
	 @Column(name = "LoadingAmount39") private String loadingAmount39;
	 @Column(name = "PaymentTerms") private String paymentTerms;
	 @Column(name = "TransactionType") private String transactionType;
	 @Column(name = "SaleCondition") private String saleCondition;
	 @Column(name = "LOCNumber") private String lOCNumber;
	 @Column(name = "LOCDate") private String lOCDate;
	 @Column(name = "PurchaseOrdNo") private String purchaseOrdNo;
	 @Column(name = "PurchaseOrdDate") private String purchaseOrdDate;
	 @Column(name = "ContractNo") private String contractNo;
	 @Column(name = "ContractDate") private String contractDate;
	 @Column(name = "AppraiserRemark") private String appraiserRemark;
	 @Column(name = "SVBLoading") private String sVBLoading;
	 @Column(name = "SVBRefNo") private String sVBRefNo;
	 @Column(name = "SVBRefDate") private String sVBRefDate;
	 @Column(name = "CustomsHouse") private String customsHouse;
	 @Column(name = "SVBLoadingBasis") private String sVBLoadingBasis;
	 @Column(name = "SVBLoadingPerAssb") private String sVBLoadingPerAssb;
	 @Column(name = "SVBLoadingPerDuty") private String sVBLoadingPerDuty;
	 @Column(name = "SVBLoadingStatusAssb") private String sVBLoadingStatusAssb;
	 @Column(name = "SVBLoadingStatusDuty") private String sVBLoadingStatusDuty;
	 @Column(name = "Relation") private String relation;
	 @Column(name = "RelationBase") private String relationBase;
	 @Column(name = "RelationCondition") private String relationCondition;
	 @Column(name = "ValuationMethod") private String valuationMethod;
	 @Column(name = "ThirdParty_Name") private String thirdParty_Name;
	 @Column(name = "ThirdParty_Branch") private String thirdParty_Branch;
	 @Column(name = "ThirdParty_Address") private String thirdParty_Address;
	 @Column(name = "ThirdParty_Cntry") private String thirdParty_Cntry;
	 @Column(name = "ThirdParty_City") private String thirdParty_City;
	 @Column(name = "ThirdParty_State") private String thirdParty_State;
	 @Column(name = "ThirdParty_Pin") private String thirdParty_Pin;
	 @Column(name = "AEO_Cntry") private String aEO_Cntry;
	 @Column(name = "AEO_Role") private String aEO_Role;
	 @Column(name = "AEO_Code") private String aEO_Code;
	 @Column(name = "TermsPlace") private String termsPlace;
	 @Column(name = "DiscountPer") private String discountPer;
	 @Column(name = "DiscountAmt") private String discountAmt;
	 @Column(name = "DiscountType") private String discountType;
	 @Column(name = "HighSeaChrgPer") private String highSeaChrgPer;
	 @Column(name = "HighSeaChrgAmt") private String highSeaChrgAmt;
	 @Column(name = "ContainerCostPer") private String containerCostPer;
	 @Column(name = "ContainerCostAmt") private String containerCostAmt;
	 @Column(name = "OriginCountryPer") private String originCountryPer;
	 @Column(name = "OriginCountryAmt") private String originCountryAmt;
	 @Column(name = "DocumentationPer") private String documentationPer;
	 @Column(name = "DocumentationAmt") private String documentationAmt;
	 @Column(name = "HandlingCostPer") private String handlingCostPer;
	 @Column(name = "HandlingCostAmt") private String handlingCostAmt;
	 @Column(name = "OtherChrgPer") private String otherChrgPer;
	 @Column(name = "OtherChrgAmt") private String otherChrgAmt;
	 @Column(name = "PackingCostPer") private String packingCostPer;
	 @Column(name = "PackingCostAmt") private String packingCostAmt;
	 @Column(name = "RoyaltyPer") private String royaltyPer;
	 @Column(name = "RoyaltyAmt") private String royaltyAmt;
	 @Column(name = "BuyerServiceCostPer") private String buyerServiceCostPer;
	 @Column(name = "BuyerServiceCostAmt") private String buyerServiceCostAmt;
	 @Column(name = "SellerObligationPer") private String sellerObligationPer;
	 @Column(name = "SellerObligationAmt") private String sellerObligationAmt;
	 @Column(name = "ValueOfProceedsPer") private String valueOfProceedsPer;
	 @Column(name = "ValueOfProceedsAmt") private String valueOfProceedsAmt;
	 @Column(name = "WarrantyServicePer") private String warrantyServicePer;
	 @Column(name = "WarrantyServiceAmt") private String warrantyServiceAmt;
	 @Column(name = "ProductDesc") private String productDesc;
	 @Column(name = "ProductType") private String productType;
	 @Column(name = "Quantity") private String quantity;
	 @Column(name = "Unit") private String unit;
	 @Column(name = "UnitPrice") private String unitPrice;
	 @Column(name = "Amount") private String amount;
	 @Column(name = "isFocItem") private String isFocItem;
	 @Column(name = "AltQuantity1") private String altQuantity1;
	 @Column(name = "AltUnit1") private String altUnit1;
	 @Column(name = "AltQuantity2") private String altQuantity2;
	 @Column(name = "AltUnit2") private String altUnit2;
	 @Column(name = "CTHNumber") private String cTHNumber;
	 @Column(name = "RITCNumber") private String rITCNumber;
	 @Column(name = "ITCLocation") private String iTCLocation;
	 @Column(name = "BasicNotn") private String basicNotn;
	 @Column(name = "BasicNotnSNo") private String basicNotnSNo;
	 @Column(name = "BasicDutyPer") private String basicDutyPer;
	 @Column(name = "BasicDutyFlag") private String basicDutyFlag;
	 @Column(name = "BasicDutyQty") private String basicDutyQty;
	 @Column(name = "BasicDutyUnit") private String basicDutyUnit;
	 @Column(name = "CustHealthCessNotn") private String custHealthCessNotn;
	 @Column(name = "CustHealthCessNotnSNo") private String custHealthCessNotnSNo;
	 @Column(name = "CustHealthCessDutyPer") private String custHealthCessDutyPer;
	 @Column(name = "CustHealthCessDutyFlag") private String custHealthCessDutyFlag;
	 @Column(name = "CustHealthCessDutyQty") private String custHealthCessDutyQty;
	 @Column(name = "CustHealthCessDutyUnit") private String custHealthCessDutyUnit;
	 @Column(name = "AltBasicNotn") private String altBasicNotn;
	 @Column(name = "AltBasicNotnSNo") private String altBasicNotnSNo;
	 @Column(name = "SurchargeNotn") private String surchargeNotn;
	 @Column(name = "SurchargeNotnSNo") private String surchargeNotnSNo;
	 @Column(name = "SurchargeRate") private String surchargeRate;
	 @Column(name = "AuxillaryNotn") private String auxillaryNotn;
	 @Column(name = "AuxillaryDutyPer") private String auxillaryDutyPer;
	 @Column(name = "AntiDumpRatePer") private String antiDumpRatePer;
	 @Column(name = "AntiDumpCurrency") private String antiDumpCurrency;
	 @Column(name = "AntiDumpBank") private String antiDumpBank;
	 @Column(name = "AntiDumpBankCert") private String antiDumpBankCert;
	 @Column(name = "AntiDumpBankCertDate") private String antiDumpBankCertDate;
	 @Column(name = "AntiDumpCurncRate") private String antiDumpCurncRate;
	 @Column(name = "AntiDumpRateQty") private String antiDumpRateQty;
	 @Column(name = "AntiDumpUnit") private String antiDumpUnit;
	 @Column(name = "AntiDumpNotn") private String antiDumpNotn;
	 @Column(name = "AntiDumpSNo") private String antiDumpSNo;
	 @Column(name = "AntiDump_CTH") private String antiDump_CTH;
	 @Column(name = "AntiDump_Supplier_SNo") private String antiDump_Supplier_SNo;
	 @Column(name = "AntiDump_Qty") private String antiDump_Qty;
	 @Column(name = "AntiDump_Tariff_Notn") private String antiDump_Tariff_Notn;
	 @Column(name = "AntiDump_Tariff_SNo") private String antiDump_Tariff_SNo;
	 @Column(name = "AntiDump_Tariff_Qty") private String antiDump_Tariff_Qty;
	 @Column(name = "AntiDump_CalcMethod") private String antiDump_CalcMethod;
	 @Column(name = "AntiDump_Tariff_Amt") private String antiDump_Tariff_Amt;
	 @Column(name = "AntiDump_Tariff_Cur") private String antiDump_Tariff_Cur;
	 @Column(name = "ManufCode") private String manufCode;
	 @Column(name = "ManufAdd1") private String manufAdd1;
	 @Column(name = "ManufAdd2") private String manufAdd2;
	 @Column(name = "SourceCntry") private String sourceCntry;
	 @Column(name = "TransitCntry") private String transitCntry;
	 @Column(name = "ManufCntry") private String manufCntry;
	 @Column(name = "ManufPostalCode") private String manufPostalCode;
	 @Column(name = "ManufState") private String manufState;
	 @Column(name = "ManufCodeType") private String manufCodeType;
	 @Column(name = "AccessoryStatus") private String accessoryStatus;
	 @Column(name = "SWInfoReqd") private String sWInfoReqd;
	 @Column(name = "RSP_Flag") private String rSP_Flag;
	 @Column(name = "CVDDutyExempFlag") private String cVDDutyExempFlag;
	 @Column(name = "AntiDump_Tariff_CRate") private String antiDump_Tariff_CRate;
	 @Column(name = "SAPTA_Notn") private String sAPTA_Notn;
	 @Column(name = "SAPTA_SNo") private String sAPTA_SNo;
	 @Column(name = "EDU_CESS_Notn") private String eDU_CESS_Notn;
	 @Column(name = "EDU_CESS_SNo") private String eDU_CESS_SNo;
	 @Column(name = "EDU_CESS_Rate") private String eDU_CESS_Rate;
	 @Column(name = "CEX_EDU_CESS_Notn") private String cEX_EDU_CESS_Notn;
	 @Column(name = "CEX_EDU_CESS_SNo") private String cEX_EDU_CESS_SNo;
	 @Column(name = "EDU_CESS_Rate_Excise") private String eDU_CESS_Rate_Excise;
	 @Column(name = "SHE_CESS_Notn") private String sHE_CESS_Notn;
	 @Column(name = "SHE_CESS_SNo") private String sHE_CESS_SNo;
	 @Column(name = "SHE_CESS_Rate") private String sHE_CESS_Rate;
	 @Column(name = "SHE_CESS_Rate_Excise") private String sHE_CESS_Rate_Excise;
	 @Column(name = "CETNumber") private String cETNumber;
	 @Column(name = "CVDNotn") private String cVDNotn;
	 @Column(name = "CVDNotnSNo") private String cVDNotnSNo;
	 @Column(name = "CVDDutyPer") private String cVDDutyPer;
	 @Column(name = "CVDDutyFlag") private String cVDDutyFlag;
	 @Column(name = "CVDDutyQty") private String cVDDutyQty;
	 @Column(name = "CVDDutyUnit") private String cVDDutyUnit;
	 @Column(name = "ACVDNotn") private String aCVDNotn;
	 @Column(name = "ACVDNotnSNo") private String aCVDNotnSNo;
	 @Column(name = "ACVDDutyPer") private String aCVDDutyPer;
	 @Column(name = "ACVDDutyFlag") private String aCVDDutyFlag;
	 @Column(name = "ACVDDutyQty") private String aCVDDutyQty;
	 @Column(name = "ACVDDutyUnit") private String aCVDDutyUnit;
	 @Column(name = "ACS2Notn") private String aCS2Notn;
	 @Column(name = "ACS2NotnSNo") private String aCS2NotnSNo;
	 @Column(name = "ACS2DutyPer") private String aCS2DutyPer;
	 @Column(name = "ACS2DutyFlag") private String aCS2DutyFlag;
	 @Column(name = "ACS2DutyQty") private String aCS2DutyQty;
	 @Column(name = "ACS2DutyUnit") private String aCS2DutyUnit;
	 @Column(name = "SCVDNotn") private String sCVDNotn;
	 @Column(name = "SCVDNotnSNo") private String sCVDNotnSNo;
	 @Column(name = "SCVDDutyPer") private String sCVDDutyPer;
	 @Column(name = "SCVDDutyFlag") private String sCVDDutyFlag;
	 @Column(name = "SCVDDutyQty") private String sCVDDutyQty;
	 @Column(name = "SCVDDutyUnit") private String sCVDDutyUnit;
	 @Column(name = "CESSNotn") private String cESSNotn;
	 @Column(name = "CESSNotnSNo") private String cESSNotnSNo;
	 @Column(name = "CESSDutyPer") private String cESSDutyPer;
	 @Column(name = "CESSDutyFlag") private String cESSDutyFlag;
	 @Column(name = "CESSDutyQty") private String cESSDutyQty;
	 @Column(name = "CESSDutyUnit") private String cESSDutyUnit;
	 @Column(name = "NCDNotn") private String nCDNotn;
	 @Column(name = "NCDNotnSNo") private String nCDNotnSNo;
	 @Column(name = "NCDDutyPer") private String nCDDutyPer;
	 @Column(name = "NCDDutyFlag") private String nCDDutyFlag;
	 @Column(name = "NCDDutyQty") private String nCDDutyQty;
	 @Column(name = "NCDDutyUnit") private String nCDDutyUnit;
	 @Column(name = "SADNotn") private String sADNotn;
	 @Column(name = "SADNotnSNo") private String sADNotnSNo;
	 @Column(name = "SADDutyPer") private String sADDutyPer;
	 @Column(name = "HLTHNotn") private String hLTHNotn;
	 @Column(name = "HLTHNotnSNo") private String hLTHNotnSNo;
	 @Column(name = "HLTHDutyPer") private String hLTHDutyPer;
	 @Column(name = "HLTHDutyFlag") private String hLTHDutyFlag;
	 @Column(name = "HLTHDutyQty") private String hLTHDutyQty;
	 @Column(name = "HLTHDutyUnit") private String hLTHDutyUnit;
	 @Column(name = "AddlDutyNotn") private String addlDutyNotn;
	 @Column(name = "AddlDutyNotnSNo") private String addlDutyNotnSNo;
	 @Column(name = "AddlDutyPer") private String addlDutyPer;
	 @Column(name = "AggrDutyNotn") private String aggrDutyNotn;
	 @Column(name = "AggrDutyNotnSNo") private String aggrDutyNotnSNo;
	 @Column(name = "AggrDutyPer") private String aggrDutyPer;
	 @Column(name = "SGDutyNotn") private String sGDutyNotn;
	 @Column(name = "SGDutyNotnSNo") private String sGDutyNotnSNo;
	 @Column(name = "SGDutyPer") private String sGDutyPer;
	 @Column(name = "IGSTNotnNo") private String iGSTNotnNo;
	 @Column(name = "IGSTNotnSrNo") private String iGSTNotnSrNo;
	 @Column(name = "IGSTNotnRatePer") private String iGSTNotnRatePer;
	 @Column(name = "IGSTNotnDutyFlag") private String iGSTNotnDutyFlag;
	 @Column(name = "IGSTNotnDutyQty") private String iGSTNotnDutyQty;
	 @Column(name = "IGSTNotnDutyUnit") private String iGSTNotnDutyUnit;
	 @Column(name = "GSTCESSNotnNo") private String gSTCESSNotnNo;
	 @Column(name = "GSTCESSNotnSrNo") private String gSTCESSNotnSrNo;
	 @Column(name = "GSTCESSNotnRatePer") private String gSTCESSNotnRatePer;
	 @Column(name = "GSTCESSNotnDutyFlag") private String gSTCESSNotnDutyFlag;
	 @Column(name = "GSTCESSNotnDutyQty") private String gSTCESSNotnDutyQty;
	 @Column(name = "GSTCESSNotnDutyUnit") private String gSTCESSNotnDutyUnit;
	 @Column(name = "IGSTExemptNotnNo") private String iGSTExemptNotnNo;
	 @Column(name = "IGSTExemptNotnSrNo") private String iGSTExemptNotnSrNo;
	 @Column(name = "IGSTExempNotnType") private String iGSTExempNotnType;
	 @Column(name = "IGSTExempNotnRatePer") private String iGSTExempNotnRatePer;
	 @Column(name = "IGSTExemptNotnDutyFlag") private String iGSTExemptNotnDutyFlag;
	 @Column(name = "IGSTExemptNotnDutyQty") private String iGSTExemptNotnDutyQty;
	 @Column(name = "IGSTExemptNotnDutyUnit") private String iGSTExemptNotnDutyUnit;
	 @Column(name = "GSTCESSExemptNotnNo") private String gSTCESSExemptNotnNo;
	 @Column(name = "GSTCESSExemptNotnSrNo") private String gSTCESSExemptNotnSrNo;
	 @Column(name = "GSTCCESSExempNotnType") private String gSTCCESSExempNotnType;
	 @Column(name = "GSTCCESSExempNotnRatePer") private String gSTCCESSExempNotnRatePer;
	 @Column(name = "GSTCCESSExemptNotnDutyFlag") private String gSTCCESSExemptNotnDutyFlag;
	 @Column(name = "GSTCCESSExemptNotnDutyQty") private String gSTCCESSExemptNotnDutyQty;
	 @Column(name = "GSTCCESSExemptNotnDutyUnit") private String gSTCCESSExemptNotnDutyUnit;
	 @Column(name = "RD_INFRA_CESS_Notn") private String rD_INFRA_CESS_Notn;
	 @Column(name = "RD_INFRA_CESS_NotnSNo") private String rD_INFRA_CESS_NotnSNo;
	 @Column(name = "RD_INFRA_CESS_DutyPer") private String rD_INFRA_CESS_DutyPer;
	 @Column(name = "RD_INFRA_CESS_DutyFlag") private String rD_INFRA_CESS_DutyFlag;
	 @Column(name = "RD_INFRA_CESS_DutyQty") private String rD_INFRA_CESS_DutyQty;
	 @Column(name = "RD_INFRA_CESS_DutyUnit") private String rD_INFRA_CESS_DutyUnit;
	 @Column(name = "SWSNotn") private String sWSNotn;
	 @Column(name = "SWSNotnSNo") private String sWSNotnSNo;
	 @Column(name = "SWSDutyPer") private String sWSDutyPer;
	 @Column(name = "ITCHSCode") private String iTCHSCode;
	 @Column(name = "PolicyPaara") private String policyPaara;
	 @Column(name = "PolicyYear") private String policyYear;
	 @Column(name = "LoadingInPer") private String loadingInPer;
	 @Column(name = "LoadingBasis40") private String loadingBasis40;
	 @Column(name = "LoadingInQty") private String loadingInQty;
	 @Column(name = "LoadingAmount41") private String loadingAmount41;
	 @Column(name = "SVBRefNo42") private String sVBRefNo42;
	 @Column(name = "SVBRefDate43") private String sVBRefDate43;
	 @Column(name = "CustomsHouse44") private String customsHouse44;
	 @Column(name = "SVBLoadingBasis45") private String sVBLoadingBasis45;
	 @Column(name = "SVBLoadingPerAssb46") private String sVBLoadingPerAssb46;
	 @Column(name = "SVBLoadingPerDuty47") private String sVBLoadingPerDuty47;
	 @Column(name = "SVBLoadingStatusAssb48") private String sVBLoadingStatusAssb48;
	 @Column(name = "SVBLoadingStatusDuty49") private String sVBLoadingStatusDuty49;
	 @Column(name = "GenericDesc") private String genericDesc;
	 @Column(name = "Accessory") private String accessory;
	 @Column(name = "Manufacturer") private String manufacturer;
	 @Column(name = "Brand") private String brand;
	 @Column(name = "Model") private String model;
	 @Column(name = "EndUse") private String endUse;
	 @Column(name = "CountryOfOrigin50") private String countryOfOrigin50;
	 @Column(name = "MRPSNo") private String mRPSNo;
	 @Column(name = "MRP") private String mRP;
	 @Column(name = "MRPUnit") private String mRPUnit;
	 @Column(name = "Abatement") private String abatement;
	 @Column(name = "EXIMCode") private String eXIMCode;
	 @Column(name = "SchemeNotn") private String schemeNotn;
	 @Column(name = "SchemeNotnSNo") private String schemeNotnSNo;
	 @Column(name = "PrevImpBENo") private String prevImpBENo;
	 @Column(name = "PrevImpBEDate") private String prevImpBEDate;
	 @Column(name = "PrevImpCurrency") private String prevImpCurrency;
	 @Column(name = "PrevImpValue") private String prevImpValue;
	 @Column(name = "PrevImpCustomHouse") private String prevImpCustomHouse;
	 @Column(name = "MaterialCode") private String materialCode;
	 @Column(name = "DutyRateType") private String dutyRateType;
	 @Column(name = "RSPNotn") private String rSPNotn;
	 @Column(name = "RSPNotnSNo") private String rSPNotnSNo;
	 @Column(name = "ReImportDtls") private String reImportDtls;
	 @Column(name = "InfoType") private String infoType;
	 @Column(name = "InfoQualifier") private String infoQualifier;
	 @Column(name = "InfoCode") private String infoCode;
	 @Column(name = "InfoText") private String infoText;
	 @Column(name = "InfoMeasure") private String infoMeasure;
	 @Column(name = "InfoMeasUnit") private String infoMeasUnit;
	 @Column(name = "ImpProdConsts") private String impProdConsts;
	 @Column(name = "ImpProdBatches") private String impProdBatches;
	 @Column(name = "ImpProdControls") private String impProdControls;
	 @Column(name = "LicNo") private String licNo;
	 @Column(name = "LicDate") private String licDate;
	 @Column(name = "DebitValue") private String debitValue;
	 @Column(name = "Quantity51") private String quantity51;
	 @Column(name = "DocumentNo") private String documentNo;
	 @Column(name = "ReleaseAdvNo") private String releaseAdvNo;
	 @Column(name = "ReleaseAdvDate") private String releaseAdvDate;
	 @Column(name = "RegisteredPort") private String registeredPort;
	 @Column(name = "ProdAmtRs") private String prodAmtRs;
	 @Column(name = "Freight") private String freight;
	 @Column(name = "Insurance") private String insurance;
	 @Column(name = "Commission") private String commission;
	 @Column(name = "Miscellaneous") private String miscellaneous;
	 @Column(name = "CIFValue") private String cIFValue;
	 @Column(name = "AssessableValue") private String assessableValue;
	 @Column(name = "TotalBasicDutyAmt") private String totalBasicDutyAmt;
	 @Column(name = "TotalCVDAmt") private String totalCVDAmt;
	 @Column(name = "TotalDutyAmt") private String totalDutyAmt;


	public BoE() {
		super();
	}
	public BoE(String version,
			String sender,
			String receiver,
			String noOfDocuments,
			String generatedOn,
			String generator,
			String doc_ID,
			String importer,
			String importerBranchID,
			String partyBank,
			String destPort,
			String transportMode,
			String typeOfBE,
			String portOfShipment,
			String freightMode,
			String countryOfOrigin,
			String alternateCountryOfOrigin,
			String countryOfShipment,
			String bEHeading,
			String bENo,
			String bEDate,
			String marks,
			String freightCurrency,
			String freightBank,
			String freightBankCert,
			String freightBankCertDate,
			String freightCurncRate,
			String freightRate,
			String freightAmount,
			String insuranceCurrency,
			String insuranceBank,
			String insuranceBankCert,
			String insuranceBankCertDate,
			String insuranceCurncRate,
			String insuranceRate,
			String insuranceBasis,
			String insuranceAmount,
			String miscCurrency,
			String miscBank,
			String miscBankCert,
			String miscBankCertDate,
			String miscCurncRate,
			String miscRate,
			String miscBasis,
			String miscAmount,
			String agencyCurrency,
			String agencyBank,
			String agencyBankCert,
			String agencyBankCertDate,
			String agencyRate,
			String agencyBasis,
			String agencyAmount,
			String loadingCurrency,
			String loadingBank,
			String loadingBankCert,
			String loadingBankCertDate,
			String loadingCurncRate,
			String loadingRate,
			String loadingBasis,
			String loadingAmount,
			String wareHouse,
			String wareHouseCode,
			String partyRef,
			String revenueDeposit,
			String revenueDepBasis,
			String bECategory,
			String filingStatus,
			String firstCheck,
			String firstCheckRemarks,
			String greenChannel,
			String greenChannelRemarks,
			String underSec46,
			String underSec46Remarks,
			String underSec48,
			String underSec48Remarks,
			String kachhaBE,
			String kachhaBERemarks,
			String highSeaSale,
			String highSeaSellerIEC,
			String highSeaSellerBranchSNo,
			String highSeaSeller,
			String highSeaSellerAddress,
			String highSeaSellerCity,
			String highSeaSellerPinCode,
			String stateCode,
			String stateName,
			String commTaxType,
//			String commTax_Type,
			String commTaxRegnNo,
			String clearanceAgainstBond,
			String bondDetails,
			String procurementCertNumber,
			String procurementCertDate,
			String certificateType,
			String commissionerate,
			String division,
			String range,
			String finalDestination,
			String remarks,
			String totalDuty,
			String totalCIFValue,
			String totalAssessableValue,
			String totalBasicDuty,
			String totalSurchargeDuty,
			String totalCVDDuty,
			String totalCustHealthCessDuty,
			String vessel,
			String transhipmentVessel,
			String goodsLandingDate,
			String voyageNumber,
			String eTA,
			String rotationNumber,
			String rotationDate,
			String lineNumber,
			String carrier,
			String hAWBNumber,
			String hAWBDate,
			String mAWBNumber,
			String mAWBDate,
			String noOfPkg,
			String pkgUnit,
			String saidToContain,
			String unitOfSaidToContain,
			String saidToContain2,
			String unitOfSaidToContain2,
			String grossWeight,
			String unitOfGrossWeight,
			String netWeight,
			String unitOfNetWeight,
			String portOfReporting,
			String gatewayIGMNo,
			String gatewayIGMDate,
			String gatewayInwardDate,
			String containerNumber,
			String sealNumber,
			String containerSize,
			String containerLoadType,
			String containerType,
			String typeDesc,
			String truck_No,
			String invoiceNo,
			String invoiceDate,
			String invoiceCurrency,
			String invoiceBank,
			String invoiceBankCert,
			String invoiceBankCertDate,
			String invoiceCurncRate,
			String invoiceValue,
			String productValue,
			String termsOfInvoice,
			String consignor,
			String consignorCountry,
			String seller,
			String sellerAddr,
			String sellerCountry,
			String indentor,
			String indentorCountry,
			String indentorAddr,
			String freightCurrency2,
			String freightBank3,
			String freightBankCert4,
			String freightBankCertDate5,
			String freightCurncRate6,
			String freightRate7,
			String freightAmount8,
			String insuranceCurrency9,
			String insuranceBank10,
			String insuranceBankCert11,
			String insuranceBankCertDate12,
			String insuranceCurncRate13,
			String insuranceRate14,
			String insuranceBasis15,
			String insuranceAmount16,
			String miscCurrency17,
			String miscBank18,
			String miscBankCert19,
			String miscBankCertDate20,
			String miscCurncRate21,
			String miscRate22,
			String miscBasis23,
			String miscAmount24,
			String agencyCurrency25,
			String agencyBank26,
			String agencyBankCert27,
			String agencyBankCertDate28,
			String agencyCurncRate,
			String agencyRate29,
			String agencyBasis30,
			String agencyAmount31,
			String loadingCurrency32,
			String loadingBank33,
			String loadingBankCert34,
			String loadingBankCertDate35,
			String loadingCurncRate36,
			String loadingRate37,
			String loadingBasis38,
			String loadingAmount39,
			String paymentTerms,
			String transactionType,
			String saleCondition,
			String lOCNumber,
			String lOCDate,
			String purchaseOrdNo,
			String purchaseOrdDate,
			String contractNo,
			String contractDate,
			String appraiserRemark,
			String sVBLoading,
			String sVBRefNo,
			String sVBRefDate,
			String customsHouse,
			String sVBLoadingBasis,
			String sVBLoadingPerAssb,
			String sVBLoadingPerDuty,
			String sVBLoadingStatusAssb,
			String sVBLoadingStatusDuty,
			String relation,
			String relationBase,
			String relationCondition,
			String valuationMethod,
			String thirdParty_Name,
			String thirdParty_Branch,
			String thirdParty_Address,
			String thirdParty_Cntry,
			String thirdParty_City,
			String thirdParty_State,
			String thirdParty_Pin,
			String aEO_Cntry,
			String aEO_Role,
			String aEO_Code,
			String termsPlace,
			String discountPer,
			String discountAmt,
			String discountType,
			String highSeaChrgPer,
			String highSeaChrgAmt,
			String containerCostPer,
			String containerCostAmt,
			String originCountryPer,
			String originCountryAmt,
			String documentationPer,
			String documentationAmt,
			String handlingCostPer,
			String handlingCostAmt,
			String otherChrgPer,
			String otherChrgAmt,
			String packingCostPer,
			String packingCostAmt,
			String royaltyPer,
			String royaltyAmt,
			String buyerServiceCostPer,
			String buyerServiceCostAmt,
			String sellerObligationPer,
			String sellerObligationAmt
/*			String valueOfProceedsPer,
			String valueOfProceedsAmt,
			String warrantyServicePer,
			String warrantyServiceAmt,
			String productDesc,
			String productType,
			String quantity,
			String unit,
			String unitPrice,
			String amount,
			String isFocItem,
			String altQuantity1,
			String altUnit1,
			String altQuantity2,
			String altUnit2,
			String cTHNumber,
			String rITCNumber,
			String iTCLocation,
			String basicNotn,
			String basicNotnSNo,
			String basicDutyPer,
			String basicDutyFlag,
			String basicDutyQty,
			String basicDutyUnit,
			String custHealthCessNotn,
			String custHealthCessNotnSNo,
			String custHealthCessDutyPer,
			String custHealthCessDutyFlag,
			String custHealthCessDutyQty,
			String custHealthCessDutyUnit,
			String altBasicNotn,
			String altBasicNotnSNo,
			String surchargeNotn,
			String surchargeNotnSNo,
			String surchargeRate,
			String auxillaryNotn,
			String auxillaryDutyPer,
			String antiDumpRatePer,
			String antiDumpCurrency,
			String antiDumpBank,
			String antiDumpBankCert,
			String antiDumpBankCertDate,
			String antiDumpCurncRate,
			String antiDumpRateQty,
			String antiDumpUnit,
			String antiDumpNotn,
			String antiDumpSNo,
			String antiDump_CTH,
			String antiDump_Supplier_SNo,
			String antiDump_Qty,
			String antiDump_Tariff_Notn,
			String antiDump_Tariff_SNo,
			String antiDump_Tariff_Qty,
			String antiDump_CalcMethod,
			String antiDump_Tariff_Amt,
			String antiDump_Tariff_Cur,
			String manufCode,
			String manufAdd1,
			String manufAdd2,
			String sourceCntry,
			String transitCntry,
			String manufCntry,
			String manufPostalCode,
			String manufState,
			String manufCodeType,
			String accessoryStatus,
			String sWInfoReqd,
			String rSP_Flag,
			String cVDDutyExempFlag,
			String antiDump_Tariff_CRate,
			String sAPTA_Notn,
			String sAPTA_SNo,
			String eDU_CESS_Notn,
			String eDU_CESS_SNo,
			String eDU_CESS_Rate,
			String cEX_EDU_CESS_Notn,
			String cEX_EDU_CESS_SNo,
			String eDU_CESS_Rate_Excise,
			String sHE_CESS_Notn,
			String sHE_CESS_SNo,
			String sHE_CESS_Rate,
			String sHE_CESS_Rate_Excise,
			String cETNumber,
			String cVDNotn,
			String cVDNotnSNo,
			String cVDDutyPer,
			String cVDDutyFlag,
			String cVDDutyQty,
			String cVDDutyUnit,
			String aCVDNotn,
			String aCVDNotnSNo,
			String aCVDDutyPer,
			String aCVDDutyFlag,
			String aCVDDutyQty,
			String aCVDDutyUnit,
			String aCS2Notn,
			String aCS2NotnSNo,
			String aCS2DutyPer,
			String aCS2DutyFlag,
			String aCS2DutyQty,
			String aCS2DutyUnit,
			String sCVDNotn,
			String sCVDNotnSNo,
			String sCVDDutyPer,
			String sCVDDutyFlag,
			String sCVDDutyQty,
			String sCVDDutyUnit,
			String cESSNotn,
			String cESSNotnSNo,
			String cESSDutyPer,
			String cESSDutyFlag,
			String cESSDutyQty,
			String cESSDutyUnit,
			String nCDNotn,
			String nCDNotnSNo,
			String nCDDutyPer,
			String nCDDutyFlag,
			String nCDDutyQty,
			String nCDDutyUnit,
			String sADNotn,
			String sADNotnSNo,
			String sADDutyPer,
			String hLTHNotn,
			String hLTHNotnSNo,
			String hLTHDutyPer,
			String hLTHDutyFlag,
			String hLTHDutyQty,
			String hLTHDutyUnit,
			String addlDutyNotn,
			String addlDutyNotnSNo,
			String addlDutyPer,
			String aggrDutyNotn,
			String aggrDutyNotnSNo,
			String aggrDutyPer,
			String sGDutyNotn,
			String sGDutyNotnSNo,
			String sGDutyPer,
			String iGSTNotnNo,
			String iGSTNotnSrNo,
			String iGSTNotnRatePer,
			String iGSTNotnDutyFlag,
			String iGSTNotnDutyQty,
			String iGSTNotnDutyUnit,
			String gSTCESSNotnNo,
			String gSTCESSNotnSrNo,
			String gSTCESSNotnRatePer,
			String gSTCESSNotnDutyFlag,
			String gSTCESSNotnDutyQty,
			String gSTCESSNotnDutyUnit,
			String iGSTExemptNotnNo,
			String iGSTExemptNotnSrNo,
			String iGSTExempNotnType,
			String iGSTExempNotnRatePer,
			String iGSTExemptNotnDutyFlag,
			String iGSTExemptNotnDutyQty,
			String iGSTExemptNotnDutyUnit,
			String gSTCESSExemptNotnNo,
			String gSTCESSExemptNotnSrNo,
			String gSTCCESSExempNotnType,
			String gSTCCESSExempNotnRatePer,
			String gSTCCESSExemptNotnDutyFlag,
			String gSTCCESSExemptNotnDutyQty,
			String gSTCCESSExemptNotnDutyUnit,
			String rD_INFRA_CESS_Notn,
			String rD_INFRA_CESS_NotnSNo,
			String rD_INFRA_CESS_DutyPer,
			String rD_INFRA_CESS_DutyFlag,
			String rD_INFRA_CESS_DutyQty,
			String rD_INFRA_CESS_DutyUnit,
			String sWSNotn,
			String sWSNotnSNo,
			String sWSDutyPer,
			String iTCHSCode,
			String policyPaara,
			String policyYear,
			String loadingInPer,
			String loadingBasis40,
			String loadingInQty,
			String loadingAmount41,
			String sVBRefNo42,
			String sVBRefDate43,
			String customsHouse44,
			String sVBLoadingBasis45,
			String sVBLoadingPerAssb46,
			String sVBLoadingPerDuty47,
			String sVBLoadingStatusAssb48,
			String sVBLoadingStatusDuty49,
			String genericDesc,
			String accessory,
			String manufacturer,
			String brand,
			String model,
			String endUse,
			String countryOfOrigin50,
			String mRPSNo,
			String mRP,
			String mRPUnit,
			String abatement,
			String eXIMCode,
			String schemeNotn,
			String schemeNotnSNo,
			String prevImpBENo,
			String prevImpBEDate,
			String prevImpCurrency,
			String prevImpValue,
			String prevImpCustomHouse,
			String materialCode,
			String dutyRateType,
			String rSPNotn,
			String rSPNotnSNo,
			String reImportDtls,
			String infoType,
			String infoQualifier,
			String infoCode,
			String infoText,
			String infoMeasure,
			String infoMeasUnit,
			String impProdConsts,
			String impProdBatches,
			String impProdControls,
			String licNo,
			String licDate,
			String debitValue,
			String quantity51,
			String documentNo,
			String releaseAdvNo,
			String releaseAdvDate,
			String registeredPort,
			String prodAmtRs,
			String freight,
			String insurance,
			String commission,
			String miscellaneous,
			String cIFValue,
			String assessableValue,
			String totalBasicDutyAmt,
			String totalCVDAmt,
			String totalDutyAmt
*///*
) {
		super();
		this.username = username;
		this.compIec = compIec;
		this.version = version;
		this.sender = sender;
		this.receiver = receiver;
		this.noOfDocuments = noOfDocuments;
		this.generatedOn = generatedOn;
		this.generator = generator;
		this.doc_ID = doc_ID;
		this.importer = importer;
		this.importerBranchID = importerBranchID;
		this.partyBank = partyBank;
		this.destPort = destPort;
		this.transportMode = transportMode;
		this.typeOfBE = typeOfBE;
		this.portOfShipment = portOfShipment;
		this.freightMode = freightMode;
		this.countryOfOrigin = countryOfOrigin;
		this.alternateCountryOfOrigin = alternateCountryOfOrigin;
		this.countryOfShipment = countryOfShipment;
		this.bEHeading = bEHeading;
		this.bENo = bENo;
		this.bEDate = bEDate;
		this.marks = marks;
		this.freightCurrency = freightCurrency;
		this.freightBank = freightBank;
		this.freightBankCert = freightBankCert;
		this.freightBankCertDate = freightBankCertDate;
		this.freightCurncRate = freightCurncRate;
		this.freightRate = freightRate;
		this.freightAmount = freightAmount;
		this.insuranceCurrency = insuranceCurrency;
		this.insuranceBank = insuranceBank;
		this.insuranceBankCert = insuranceBankCert;
		this.insuranceBankCertDate = insuranceBankCertDate;
		this.insuranceCurncRate = insuranceCurncRate;
		this.insuranceRate = insuranceRate;
		this.insuranceBasis = insuranceBasis;
		this.insuranceAmount = insuranceAmount;
		this.miscCurrency = miscCurrency;
		this.miscBank = miscBank;
		this.miscBankCert = miscBankCert;
		this.miscBankCertDate = miscBankCertDate;
		this.miscCurncRate = miscCurncRate;
		this.miscRate = miscRate;
		this.miscBasis = miscBasis;
		this.miscAmount = miscAmount;
		this.agencyCurrency = agencyCurrency;
		this.agencyBank = agencyBank;
		this.agencyBankCert = agencyBankCert;
		this.agencyBankCertDate = agencyBankCertDate;
		this.agencyRate = agencyRate;
		this.agencyBasis = agencyBasis;
		this.agencyAmount = agencyAmount;
		this.loadingCurrency = loadingCurrency;
		this.loadingBank = loadingBank;
		this.loadingBankCert = loadingBankCert;
		this.loadingBankCertDate = loadingBankCertDate;
		this.loadingCurncRate = loadingCurncRate;
		this.loadingRate = loadingRate;
		this.loadingBasis = loadingBasis;
		this.loadingAmount = loadingAmount;
		this.wareHouse = wareHouse;
		this.wareHouseCode = wareHouseCode;
		this.partyRef = partyRef;
		this.revenueDeposit = revenueDeposit;
		this.revenueDepBasis = revenueDepBasis;
		this.bECategory = bECategory;
		this.filingStatus = filingStatus;
		this.firstCheck = firstCheck;
		this.firstCheckRemarks = firstCheckRemarks;
		this.greenChannel = greenChannel;
		this.greenChannelRemarks = greenChannelRemarks;
		this.underSec46 = underSec46;
		this.underSec46Remarks = underSec46Remarks;
		this.underSec48 = underSec48;
		this.underSec48Remarks = underSec48Remarks;
		this.kachhaBE = kachhaBE;
		this.kachhaBERemarks = kachhaBERemarks;
		this.highSeaSale = highSeaSale;
		this.highSeaSellerIEC = highSeaSellerIEC;
		this.highSeaSellerBranchSNo = highSeaSellerBranchSNo;
		this.highSeaSeller = highSeaSeller;
		this.highSeaSellerAddress = highSeaSellerAddress;
		this.highSeaSellerCity = highSeaSellerCity;
		this.highSeaSellerPinCode = highSeaSellerPinCode;
		this.stateCode = stateCode;
		this.stateName = stateName;
		this.commTaxType = commTaxType;
//		this.commTax_Type = commTax_Type;
		this.commTaxRegnNo = commTaxRegnNo;
		this.clearanceAgainstBond = clearanceAgainstBond;
		this.bondDetails = bondDetails;
		this.procurementCertNumber = procurementCertNumber;
		this.procurementCertDate = procurementCertDate;
		this.certificateType = certificateType;
		this.commissionerate = commissionerate;
		this.division = division;
		this.range = range;
		this.finalDestination = finalDestination;
		this.remarks = remarks;
		this.totalDuty = totalDuty;
		this.totalCIFValue = totalCIFValue;
		this.totalAssessableValue = totalAssessableValue;
		this.totalBasicDuty = totalBasicDuty;
		this.totalSurchargeDuty = totalSurchargeDuty;
		this.totalCVDDuty = totalCVDDuty;
		this.totalCustHealthCessDuty = totalCustHealthCessDuty;
		this.vessel = vessel;
		this.transhipmentVessel = transhipmentVessel;
		this.goodsLandingDate = goodsLandingDate;
		this.voyageNumber = voyageNumber;
		this.eTA = eTA;
		this.rotationNumber = rotationNumber;
		this.rotationDate = rotationDate;
		this.lineNumber = lineNumber;
		this.carrier = carrier;
		this.hAWBNumber = hAWBNumber;
		this.hAWBDate = hAWBDate;
		this.mAWBNumber = mAWBNumber;
		this.mAWBDate = mAWBDate;
		this.noOfPkg = noOfPkg;
		this.pkgUnit = pkgUnit;
		this.saidToContain = saidToContain;
		this.unitOfSaidToContain = unitOfSaidToContain;
		this.saidToContain2 = saidToContain2;
		this.unitOfSaidToContain2 = unitOfSaidToContain2;
		this.grossWeight = grossWeight;
		this.unitOfGrossWeight = unitOfGrossWeight;
		this.netWeight = netWeight;
		this.unitOfNetWeight = unitOfNetWeight;
		this.portOfReporting = portOfReporting;
		this.gatewayIGMNo = gatewayIGMNo;
		this.gatewayIGMDate = gatewayIGMDate;
		this.gatewayInwardDate = gatewayInwardDate;
		this.containerNumber = containerNumber;
		this.sealNumber = sealNumber;
		this.containerSize = containerSize;
		this.containerLoadType = containerLoadType;
		this.containerType = containerType;
		this.typeDesc = typeDesc;
		this.truck_No = truck_No;
		this.invoiceNo = invoiceNo;
		this.invoiceDate = invoiceDate;
		this.invoiceCurrency = invoiceCurrency;
		this.invoiceBank = invoiceBank;
		this.invoiceBankCert = invoiceBankCert;
		this.invoiceBankCertDate = invoiceBankCertDate;
		this.invoiceCurncRate = invoiceCurncRate;
		this.invoiceValue = invoiceValue;
		this.productValue = productValue;
		this.termsOfInvoice = termsOfInvoice;
		this.consignor = consignor;
		this.consignorCountry = consignorCountry;
		this.seller = seller;
		this.sellerAddr = sellerAddr;
		this.sellerCountry = sellerCountry;
		this.indentor = indentor;
		this.indentorCountry = indentorCountry;
		this.indentorAddr = indentorAddr;
		this.freightCurrency2 = freightCurrency2;
		this.freightBank3 = freightBank3;
		this.freightBankCert4 = freightBankCert4;
		this.freightBankCertDate5 = freightBankCertDate5;
		this.freightCurncRate6 = freightCurncRate6;
		this.freightRate7 = freightRate7;
		this.freightAmount8 = freightAmount8;
		this.insuranceCurrency9 = insuranceCurrency9;
		this.insuranceBank10 = insuranceBank10;
		this.insuranceBankCert11 = insuranceBankCert11;
		this.insuranceBankCertDate12 = insuranceBankCertDate12;
		this.insuranceCurncRate13 = insuranceCurncRate13;
		this.insuranceRate14 = insuranceRate14;
		this.insuranceBasis15 = insuranceBasis15;
		this.insuranceAmount16 = insuranceAmount16;
		this.miscCurrency17 = miscCurrency17;
		this.miscBank18 = miscBank18;
		this.miscBankCert19 = miscBankCert19;
		this.miscBankCertDate20 = miscBankCertDate20;
		this.miscCurncRate21 = miscCurncRate21;
		this.miscRate22 = miscRate22;
		this.miscBasis23 = miscBasis23;
		this.miscAmount24 = miscAmount24;
		this.agencyCurrency25 = agencyCurrency25;
		this.agencyBank26 = agencyBank26;
		this.agencyBankCert27 = agencyBankCert27;
		this.agencyBankCertDate28 = agencyBankCertDate28;
		this.agencyCurncRate = agencyCurncRate;
		this.agencyRate29 = agencyRate29;
		this.agencyBasis30 = agencyBasis30;
		this.agencyAmount31 = agencyAmount31;
		this.loadingCurrency32 = loadingCurrency32;
		this.loadingBank33 = loadingBank33;
		this.loadingBankCert34 = loadingBankCert34;
		this.loadingBankCertDate35 = loadingBankCertDate35;
		this.loadingCurncRate36 = loadingCurncRate36;
		this.loadingRate37 = loadingRate37;
		this.loadingBasis38 = loadingBasis38;
		this.loadingAmount39 = loadingAmount39;
		this.paymentTerms = paymentTerms;
		this.transactionType = transactionType;
		this.saleCondition = saleCondition;
		this.lOCNumber = lOCNumber;
		this.lOCDate = lOCDate;
		this.purchaseOrdNo = purchaseOrdNo;
		this.purchaseOrdDate = purchaseOrdDate;
		this.contractNo = contractNo;
		this.contractDate = contractDate;
		this.appraiserRemark = appraiserRemark;
		this.sVBLoading = sVBLoading;
		this.sVBRefNo = sVBRefNo;
		this.sVBRefDate = sVBRefDate;
		this.customsHouse = customsHouse;
		this.sVBLoadingBasis = sVBLoadingBasis;
		this.sVBLoadingPerAssb = sVBLoadingPerAssb;
		this.sVBLoadingPerDuty = sVBLoadingPerDuty;
		this.sVBLoadingStatusAssb = sVBLoadingStatusAssb;
		this.sVBLoadingStatusDuty = sVBLoadingStatusDuty;
		this.relation = relation;
		this.relationBase = relationBase;
		this.relationCondition = relationCondition;
		this.valuationMethod = valuationMethod;
		this.thirdParty_Name = thirdParty_Name;
		this.thirdParty_Branch = thirdParty_Branch;
		this.thirdParty_Address = thirdParty_Address;
		this.thirdParty_Cntry = thirdParty_Cntry;
		this.thirdParty_City = thirdParty_City;
		this.thirdParty_State = thirdParty_State;
		this.thirdParty_Pin = thirdParty_Pin;
		this.aEO_Cntry = aEO_Cntry;
		this.aEO_Role = aEO_Role;
		this.aEO_Code = aEO_Code;
		this.termsPlace = termsPlace;
		this.discountPer = discountPer;
		this.discountAmt = discountAmt;
		this.discountType = discountType;
		this.highSeaChrgPer = highSeaChrgPer;
		this.highSeaChrgAmt = highSeaChrgAmt;
		this.containerCostPer = containerCostPer;
		this.containerCostAmt = containerCostAmt;
		this.originCountryPer = originCountryPer;
		this.originCountryAmt = originCountryAmt;
		this.documentationPer = documentationPer;
		this.documentationAmt = documentationAmt;
		this.handlingCostPer = handlingCostPer;
		this.handlingCostAmt = handlingCostAmt;
		this.otherChrgPer = otherChrgPer;
		this.otherChrgAmt = otherChrgAmt;
		this.packingCostPer = packingCostPer;
		this.packingCostAmt = packingCostAmt;
		this.royaltyPer = royaltyPer;
		this.royaltyAmt = royaltyAmt;
		this.buyerServiceCostPer = buyerServiceCostPer;
		this.buyerServiceCostAmt = buyerServiceCostAmt;
		this.sellerObligationPer = sellerObligationPer;
		this.sellerObligationAmt = sellerObligationAmt;
		this.valueOfProceedsPer = valueOfProceedsPer;
		this.valueOfProceedsAmt = valueOfProceedsAmt;
		this.warrantyServicePer = warrantyServicePer;
		this.warrantyServiceAmt = warrantyServiceAmt;
		this.productDesc = productDesc;
		this.productType = productType;
		this.quantity = quantity;
		this.unit = unit;
		this.unitPrice = unitPrice;
		this.amount = amount;
		this.isFocItem = isFocItem;
		this.altQuantity1 = altQuantity1;
		this.altUnit1 = altUnit1;
		this.altQuantity2 = altQuantity2;
		this.altUnit2 = altUnit2;
		this.cTHNumber = cTHNumber;
		this.rITCNumber = rITCNumber;
		this.iTCLocation = iTCLocation;
		this.basicNotn = basicNotn;
		this.basicNotnSNo = basicNotnSNo;
		this.basicDutyPer = basicDutyPer;
		this.basicDutyFlag = basicDutyFlag;
		this.basicDutyQty = basicDutyQty;
		this.basicDutyUnit = basicDutyUnit;
		this.custHealthCessNotn = custHealthCessNotn;
		this.custHealthCessNotnSNo = custHealthCessNotnSNo;
		this.custHealthCessDutyPer = custHealthCessDutyPer;
		this.custHealthCessDutyFlag = custHealthCessDutyFlag;
		this.custHealthCessDutyQty = custHealthCessDutyQty;
		this.custHealthCessDutyUnit = custHealthCessDutyUnit;
		this.altBasicNotn = altBasicNotn;
		this.altBasicNotnSNo = altBasicNotnSNo;
		this.surchargeNotn = surchargeNotn;
		this.surchargeNotnSNo = surchargeNotnSNo;
		this.surchargeRate = surchargeRate;
		this.auxillaryNotn = auxillaryNotn;
		this.auxillaryDutyPer = auxillaryDutyPer;
		this.antiDumpRatePer = antiDumpRatePer;
		this.antiDumpCurrency = antiDumpCurrency;
		this.antiDumpBank = antiDumpBank;
		this.antiDumpBankCert = antiDumpBankCert;
		this.antiDumpBankCertDate = antiDumpBankCertDate;
		this.antiDumpCurncRate = antiDumpCurncRate;
		this.antiDumpRateQty = antiDumpRateQty;
		this.antiDumpUnit = antiDumpUnit;
		this.antiDumpNotn = antiDumpNotn;
		this.antiDumpSNo = antiDumpSNo;
		this.antiDump_CTH = antiDump_CTH;
		this.antiDump_Supplier_SNo = antiDump_Supplier_SNo;
		this.antiDump_Qty = antiDump_Qty;
		this.antiDump_Tariff_Notn = antiDump_Tariff_Notn;
		this.antiDump_Tariff_SNo = antiDump_Tariff_SNo;
		this.antiDump_Tariff_Qty = antiDump_Tariff_Qty;
		this.antiDump_CalcMethod = antiDump_CalcMethod;
		this.antiDump_Tariff_Amt = antiDump_Tariff_Amt;
		this.antiDump_Tariff_Cur = antiDump_Tariff_Cur;
		this.manufCode = manufCode;
		this.manufAdd1 = manufAdd1;
		this.manufAdd2 = manufAdd2;
		this.sourceCntry = sourceCntry;
		this.transitCntry = transitCntry;
		this.manufCntry = manufCntry;
		this.manufPostalCode = manufPostalCode;
		this.manufState = manufState;
		this.manufCodeType = manufCodeType;
		this.accessoryStatus = accessoryStatus;
		this.sWInfoReqd = sWInfoReqd;
		this.rSP_Flag = rSP_Flag;
		this.cVDDutyExempFlag = cVDDutyExempFlag;
		this.antiDump_Tariff_CRate = antiDump_Tariff_CRate;
		this.sAPTA_Notn = sAPTA_Notn;
		this.sAPTA_SNo = sAPTA_SNo;
		this.eDU_CESS_Notn = eDU_CESS_Notn;
		this.eDU_CESS_SNo = eDU_CESS_SNo;
		this.eDU_CESS_Rate = eDU_CESS_Rate;
		this.cEX_EDU_CESS_Notn = cEX_EDU_CESS_Notn;
		this.cEX_EDU_CESS_SNo = cEX_EDU_CESS_SNo;
		this.eDU_CESS_Rate_Excise = eDU_CESS_Rate_Excise;
		this.sHE_CESS_Notn = sHE_CESS_Notn;
		this.sHE_CESS_SNo = sHE_CESS_SNo;
		this.sHE_CESS_Rate = sHE_CESS_Rate;
		this.sHE_CESS_Rate_Excise = sHE_CESS_Rate_Excise;
		this.cETNumber = cETNumber;
		this.cVDNotn = cVDNotn;
		this.cVDNotnSNo = cVDNotnSNo;
		this.cVDDutyPer = cVDDutyPer;
		this.cVDDutyFlag = cVDDutyFlag;
		this.cVDDutyQty = cVDDutyQty;
		this.cVDDutyUnit = cVDDutyUnit;
		this.aCVDNotn = aCVDNotn;
		this.aCVDNotnSNo = aCVDNotnSNo;
		this.aCVDDutyPer = aCVDDutyPer;
		this.aCVDDutyFlag = aCVDDutyFlag;
		this.aCVDDutyQty = aCVDDutyQty;
		this.aCVDDutyUnit = aCVDDutyUnit;
		this.aCS2Notn = aCS2Notn;
		this.aCS2NotnSNo = aCS2NotnSNo;
		this.aCS2DutyPer = aCS2DutyPer;
		this.aCS2DutyFlag = aCS2DutyFlag;
		this.aCS2DutyQty = aCS2DutyQty;
		this.aCS2DutyUnit = aCS2DutyUnit;
		this.sCVDNotn = sCVDNotn;
		this.sCVDNotnSNo = sCVDNotnSNo;
		this.sCVDDutyPer = sCVDDutyPer;
		this.sCVDDutyFlag = sCVDDutyFlag;
		this.sCVDDutyQty = sCVDDutyQty;
		this.sCVDDutyUnit = sCVDDutyUnit;
		this.cESSNotn = cESSNotn;
		this.cESSNotnSNo = cESSNotnSNo;
		this.cESSDutyPer = cESSDutyPer;
		this.cESSDutyFlag = cESSDutyFlag;
		this.cESSDutyQty = cESSDutyQty;
		this.cESSDutyUnit = cESSDutyUnit;
		this.nCDNotn = nCDNotn;
		this.nCDNotnSNo = nCDNotnSNo;
		this.nCDDutyPer = nCDDutyPer;
		this.nCDDutyFlag = nCDDutyFlag;
		this.nCDDutyQty = nCDDutyQty;
		this.nCDDutyUnit = nCDDutyUnit;
		this.sADNotn = sADNotn;
		this.sADNotnSNo = sADNotnSNo;
		this.sADDutyPer = sADDutyPer;
		this.hLTHNotn = hLTHNotn;
		this.hLTHNotnSNo = hLTHNotnSNo;
		this.hLTHDutyPer = hLTHDutyPer;
		this.hLTHDutyFlag = hLTHDutyFlag;
		this.hLTHDutyQty = hLTHDutyQty;
		this.hLTHDutyUnit = hLTHDutyUnit;
		this.addlDutyNotn = addlDutyNotn;
		this.addlDutyNotnSNo = addlDutyNotnSNo;
		this.addlDutyPer = addlDutyPer;
		this.aggrDutyNotn = aggrDutyNotn;
		this.aggrDutyNotnSNo = aggrDutyNotnSNo;
		this.aggrDutyPer = aggrDutyPer;
		this.sGDutyNotn = sGDutyNotn;
		this.sGDutyNotnSNo = sGDutyNotnSNo;
		this.sGDutyPer = sGDutyPer;
		this.iGSTNotnNo = iGSTNotnNo;
		this.iGSTNotnSrNo = iGSTNotnSrNo;
		this.iGSTNotnRatePer = iGSTNotnRatePer;
		this.iGSTNotnDutyFlag = iGSTNotnDutyFlag;
		this.iGSTNotnDutyQty = iGSTNotnDutyQty;
		this.iGSTNotnDutyUnit = iGSTNotnDutyUnit;
		this.gSTCESSNotnNo = gSTCESSNotnNo;
		this.gSTCESSNotnSrNo = gSTCESSNotnSrNo;
		this.gSTCESSNotnRatePer = gSTCESSNotnRatePer;
		this.gSTCESSNotnDutyFlag = gSTCESSNotnDutyFlag;
		this.gSTCESSNotnDutyQty = gSTCESSNotnDutyQty;
		this.gSTCESSNotnDutyUnit = gSTCESSNotnDutyUnit;
		this.iGSTExemptNotnNo = iGSTExemptNotnNo;
		this.iGSTExemptNotnSrNo = iGSTExemptNotnSrNo;
		this.iGSTExempNotnType = iGSTExempNotnType;
		this.iGSTExempNotnRatePer = iGSTExempNotnRatePer;
		this.iGSTExemptNotnDutyFlag = iGSTExemptNotnDutyFlag;
		this.iGSTExemptNotnDutyQty = iGSTExemptNotnDutyQty;
		this.iGSTExemptNotnDutyUnit = iGSTExemptNotnDutyUnit;
		this.gSTCESSExemptNotnNo = gSTCESSExemptNotnNo;
		this.gSTCESSExemptNotnSrNo = gSTCESSExemptNotnSrNo;
		this.gSTCCESSExempNotnType = gSTCCESSExempNotnType;
		this.gSTCCESSExempNotnRatePer = gSTCCESSExempNotnRatePer;
		this.gSTCCESSExemptNotnDutyFlag = gSTCCESSExemptNotnDutyFlag;
		this.gSTCCESSExemptNotnDutyQty = gSTCCESSExemptNotnDutyQty;
		this.gSTCCESSExemptNotnDutyUnit = gSTCCESSExemptNotnDutyUnit;
		this.rD_INFRA_CESS_Notn = rD_INFRA_CESS_Notn;
		this.rD_INFRA_CESS_NotnSNo = rD_INFRA_CESS_NotnSNo;
		this.rD_INFRA_CESS_DutyPer = rD_INFRA_CESS_DutyPer;
		this.rD_INFRA_CESS_DutyFlag = rD_INFRA_CESS_DutyFlag;
		this.rD_INFRA_CESS_DutyQty = rD_INFRA_CESS_DutyQty;
		this.rD_INFRA_CESS_DutyUnit = rD_INFRA_CESS_DutyUnit;
		this.sWSNotn = sWSNotn;
		this.sWSNotnSNo = sWSNotnSNo;
		this.sWSDutyPer = sWSDutyPer;
		this.iTCHSCode = iTCHSCode;
		this.policyPaara = policyPaara;
		this.policyYear = policyYear;
		this.loadingInPer = loadingInPer;
		this.loadingBasis40 = loadingBasis40;
		this.loadingInQty = loadingInQty;
		this.loadingAmount41 = loadingAmount41;
		this.sVBRefNo42 = sVBRefNo42;
		this.sVBRefDate43 = sVBRefDate43;
		this.customsHouse44 = customsHouse44;
		this.sVBLoadingBasis45 = sVBLoadingBasis45;
		this.sVBLoadingPerAssb46 = sVBLoadingPerAssb46;
		this.sVBLoadingPerDuty47 = sVBLoadingPerDuty47;
		this.sVBLoadingStatusAssb48 = sVBLoadingStatusAssb48;
		this.sVBLoadingStatusDuty49 = sVBLoadingStatusDuty49;
		this.genericDesc = genericDesc;
		this.accessory = accessory;
		this.manufacturer = manufacturer;
		this.brand = brand;
		this.model = model;
		this.endUse = endUse;
		this.countryOfOrigin50 = countryOfOrigin50;
		this.mRPSNo = mRPSNo;
		this.mRP = mRP;
		this.mRPUnit = mRPUnit;
		this.abatement = abatement;
		this.eXIMCode = eXIMCode;
		this.schemeNotn = schemeNotn;
		this.schemeNotnSNo = schemeNotnSNo;
		this.prevImpBENo = prevImpBENo;
		this.prevImpBEDate = prevImpBEDate;
		this.prevImpCurrency = prevImpCurrency;
		this.prevImpValue = prevImpValue;
		this.prevImpCustomHouse = prevImpCustomHouse;
		this.materialCode = materialCode;
		this.dutyRateType = dutyRateType;
		this.rSPNotn = rSPNotn;
		this.rSPNotnSNo = rSPNotnSNo;
		this.reImportDtls = reImportDtls;
		this.infoType = infoType;
		this.infoQualifier = infoQualifier;
		this.infoCode = infoCode;
		this.infoText = infoText;
		this.infoMeasure = infoMeasure;
		this.infoMeasUnit = infoMeasUnit;
		this.impProdConsts = impProdConsts;
		this.impProdBatches = impProdBatches;
		this.impProdControls = impProdControls;
		this.licNo = licNo;
		this.licDate = licDate;
		this.debitValue = debitValue;
		this.quantity51 = quantity51;
		this.documentNo = documentNo;
		this.releaseAdvNo = releaseAdvNo;
		this.releaseAdvDate = releaseAdvDate;
		this.registeredPort = registeredPort;
		this.prodAmtRs = prodAmtRs;
		this.freight = freight;
		this.insurance = insurance;
		this.commission = commission;
		this.miscellaneous = miscellaneous;
		this.cIFValue = cIFValue;
		this.assessableValue = assessableValue;
		this.totalBasicDutyAmt = totalBasicDutyAmt;
		this.totalCVDAmt = totalCVDAmt;
		this.totalDutyAmt = totalDutyAmt;

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCompIec() {
		return compIec;
	}

	public void setCompIec(String compIec) {
		this.compIec = compIec;
	}

		public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}


	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getNoOfDocuments() {
		return noOfDocuments;
	}

	public void setNoOfDocuments(String noOfDocuments) {
		this.noOfDocuments = noOfDocuments;
	}

	public String getGeneratedOn() {
		return generatedOn;
	}

	public void setGeneratedOn(String generatedOn) {
		this.generatedOn = generatedOn;
	}

	public String getGenerator() {
		return generator;
	}

	public void setGenerator(String generator) {
		this.generator = generator;
	}

	public String getDoc_ID() {
		return doc_ID;
	}

	public void setDoc_ID(String doc_ID) {
		this.doc_ID = doc_ID;
	}

	public String getImporter() {
		return importer;
	}

	public void setImporter(String importer) {
		this.importer = importer;
	}

	public String getImporterBranchID() {
		return importerBranchID;
	}

	public void setImporterBranchID(String importerBranchID) {
		this.importerBranchID = importerBranchID;
	}

	public String getPartyBank() {
		return partyBank;
	}

	public void setPartyBank(String partyBank) {
		this.partyBank = partyBank;
	}

	public String getDestPort() {
		return destPort;
	}

	public void setDestPort(String destPort) {
		this.destPort = destPort;
	}

	public String getTransportMode() {
		return transportMode;
	}

	public void setTransportMode(String transportMode) {
		this.transportMode = transportMode;
	}

	public String getTypeOfBE() {
		return typeOfBE;
	}

	public void setTypeOfBE(String typeOfBE) {
		this.typeOfBE = typeOfBE;
	}

	public String getPortOfShipment() {
		return portOfShipment;
	}

	public void setPortOfShipment(String portOfShipment) {
		this.portOfShipment = portOfShipment;
	}

	public String getFreightMode() {
		return freightMode;
	}

	public void setFreightMode(String freightMode) {
		this.freightMode = freightMode;
	}

	public String getCountryOfOrigin() {
		return countryOfOrigin;
	}

	public void setCountryOfOrigin(String countryOfOrigin) {
		this.countryOfOrigin = countryOfOrigin;
	}

	public String getAlternateCountryOfOrigin() {
		return alternateCountryOfOrigin;
	}

	public void setAlternateCountryOfOrigin(String alternateCountryOfOrigin) {
		this.alternateCountryOfOrigin = alternateCountryOfOrigin;
	}

	public String getCountryOfShipment() {
		return countryOfShipment;
	}

	public void setCountryOfShipment(String countryOfShipment) {
		this.countryOfShipment = countryOfShipment;
	}

	public String getbEHeading() {
		return bEHeading;
	}

	public void setbEHeading(String bEHeading) {
		this.bEHeading = bEHeading;
	}

	public String getbENo() {
		return bENo;
	}

	public void setbENo(String bENo) {
		this.bENo = bENo;
	}

	public String getbEDate() {
		return bEDate;
	}

	public void setbEDate(String bEDate) {
		this.bEDate = bEDate;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getFreightCurrency() {
		return freightCurrency;
	}

	public void setFreightCurrency(String freightCurrency) {
		this.freightCurrency = freightCurrency;
	}

	public String getFreightBank() {
		return freightBank;
	}

	public void setFreightBank(String freightBank) {
		this.freightBank = freightBank;
	}

	public String getFreightBankCert() {
		return freightBankCert;
	}

	public void setFreightBankCert(String freightBankCert) {
		this.freightBankCert = freightBankCert;
	}

	public String getFreightBankCertDate() {
		return freightBankCertDate;
	}

	public void setFreightBankCertDate(String freightBankCertDate) {
		this.freightBankCertDate = freightBankCertDate;
	}

	public String getFreightCurncRate() {
		return freightCurncRate;
	}

	public void setFreightCurncRate(String freightCurncRate) {
		this.freightCurncRate = freightCurncRate;
	}

	public String getFreightRate() {
		return freightRate;
	}

	public void setFreightRate(String freightRate) {
		this.freightRate = freightRate;
	}

	public String getFreightAmount() {
		return freightAmount;
	}

	public void setFreightAmount(String freightAmount) {
		this.freightAmount = freightAmount;
	}

	public String getInsuranceCurrency() {
		return insuranceCurrency;
	}

	public void setInsuranceCurrency(String insuranceCurrency) {
		this.insuranceCurrency = insuranceCurrency;
	}

	public String getInsuranceBank() {
		return insuranceBank;
	}

	public void setInsuranceBank(String insuranceBank) {
		this.insuranceBank = insuranceBank;
	}

	public String getInsuranceBankCert() {
		return insuranceBankCert;
	}

	public void setInsuranceBankCert(String insuranceBankCert) {
		this.insuranceBankCert = insuranceBankCert;
	}

	public String getInsuranceBankCertDate() {
		return insuranceBankCertDate;
	}

	public void setInsuranceBankCertDate(String insuranceBankCertDate) {
		this.insuranceBankCertDate = insuranceBankCertDate;
	}

	public String getInsuranceCurncRate() {
		return insuranceCurncRate;
	}

	public void setInsuranceCurncRate(String insuranceCurncRate) {
		this.insuranceCurncRate = insuranceCurncRate;
	}

	public String getInsuranceRate() {
		return insuranceRate;
	}

	public void setInsuranceRate(String insuranceRate) {
		this.insuranceRate = insuranceRate;
	}

	public String getInsuranceBasis() {
		return insuranceBasis;
	}

	public void setInsuranceBasis(String insuranceBasis) {
		this.insuranceBasis = insuranceBasis;
	}

	public String getInsuranceAmount() {
		return insuranceAmount;
	}

	public void setInsuranceAmount(String insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}

	public String getMiscCurrency() {
		return miscCurrency;
	}

	public void setMiscCurrency(String miscCurrency) {
		this.miscCurrency = miscCurrency;
	}

	public String getMiscBank() {
		return miscBank;
	}

	public void setMiscBank(String miscBank) {
		this.miscBank = miscBank;
	}

	public String getMiscBankCert() {
		return miscBankCert;
	}

	public void setMiscBankCert(String miscBankCert) {
		this.miscBankCert = miscBankCert;
	}

	public String getMiscBankCertDate() {
		return miscBankCertDate;
	}

	public void setMiscBankCertDate(String miscBankCertDate) {
		this.miscBankCertDate = miscBankCertDate;
	}

	public String getMiscCurncRate() {
		return miscCurncRate;
	}

	public void setMiscCurncRate(String miscCurncRate) {
		this.miscCurncRate = miscCurncRate;
	}

	public String getMiscRate() {
		return miscRate;
	}

	public void setMiscRate(String miscRate) {
		this.miscRate = miscRate;
	}

	public String getMiscBasis() {
		return miscBasis;
	}

	public void setMiscBasis(String miscBasis) {
		this.miscBasis = miscBasis;
	}

	public String getMiscAmount() {
		return miscAmount;
	}

	public void setMiscAmount(String miscAmount) {
		this.miscAmount = miscAmount;
	}

	public String getAgencyCurrency() {
		return agencyCurrency;
	}

	public void setAgencyCurrency(String agencyCurrency) {
		this.agencyCurrency = agencyCurrency;
	}

	public String getAgencyBank() {
		return agencyBank;
	}

	public void setAgencyBank(String agencyBank) {
		this.agencyBank = agencyBank;
	}

	public String getAgencyBankCert() {
		return agencyBankCert;
	}

	public void setAgencyBankCert(String agencyBankCert) {
		this.agencyBankCert = agencyBankCert;
	}

	public String getAgencyBankCertDate() {
		return agencyBankCertDate;
	}

	public void setAgencyBankCertDate(String agencyBankCertDate) {
		this.agencyBankCertDate = agencyBankCertDate;
	}

	public String getAgencyRate() {
		return agencyRate;
	}

	public void setAgencyRate(String agencyRate) {
		this.agencyRate = agencyRate;
	}

	public String getAgencyBasis() {
		return agencyBasis;
	}

	public void setAgencyBasis(String agencyBasis) {
		this.agencyBasis = agencyBasis;
	}

	public String getAgencyAmount() {
		return agencyAmount;
	}

	public void setAgencyAmount(String agencyAmount) {
		this.agencyAmount = agencyAmount;
	}

	public String getLoadingCurrency() {
		return loadingCurrency;
	}

	public void setLoadingCurrency(String loadingCurrency) {
		this.loadingCurrency = loadingCurrency;
	}

	public String getLoadingBank() {
		return loadingBank;
	}

	public void setLoadingBank(String loadingBank) {
		this.loadingBank = loadingBank;
	}

	public String getLoadingBankCert() {
		return loadingBankCert;
	}

	public void setLoadingBankCert(String loadingBankCert) {
		this.loadingBankCert = loadingBankCert;
	}

	public String getLoadingBankCertDate() {
		return loadingBankCertDate;
	}

	public void setLoadingBankCertDate(String loadingBankCertDate) {
		this.loadingBankCertDate = loadingBankCertDate;
	}

	public String getLoadingCurncRate() {
		return loadingCurncRate;
	}

	public void setLoadingCurncRate(String loadingCurncRate) {
		this.loadingCurncRate = loadingCurncRate;
	}

	public String getLoadingRate() {
		return loadingRate;
	}

	public void setLoadingRate(String loadingRate) {
		this.loadingRate = loadingRate;
	}

	public String getLoadingBasis() {
		return loadingBasis;
	}

	public void setLoadingBasis(String loadingBasis) {
		this.loadingBasis = loadingBasis;
	}

	public String getLoadingAmount() {
		return loadingAmount;
	}

	public void setLoadingAmount(String loadingAmount) {
		this.loadingAmount = loadingAmount;
	}

	public String getWareHouse() {
		return wareHouse;
	}

	public void setWareHouse(String wareHouse) {
		this.wareHouse = wareHouse;
	}

	public String getWareHouseCode() {
		return wareHouseCode;
	}

	public void setWareHouseCode(String wareHouseCode) {
		this.wareHouseCode = wareHouseCode;
	}

	public String getPartyRef() {
		return partyRef;
	}

	public void setPartyRef(String partyRef) {
		this.partyRef = partyRef;
	}

	public String getRevenueDeposit() {
		return revenueDeposit;
	}

	public void setRevenueDeposit(String revenueDeposit) {
		this.revenueDeposit = revenueDeposit;
	}

	public String getRevenueDepBasis() {
		return revenueDepBasis;
	}

	public void setRevenueDepBasis(String revenueDepBasis) {
		this.revenueDepBasis = revenueDepBasis;
	}

	public String getbECategory() {
		return bECategory;
	}

	public void setbECategory(String bECategory) {
		this.bECategory = bECategory;
	}

	public String getFilingStatus() {
		return filingStatus;
	}

	public void setFilingStatus(String filingStatus) {
		this.filingStatus = filingStatus;
	}

	public String getFirstCheck() {
		return firstCheck;
	}

	public void setFirstCheck(String firstCheck) {
		this.firstCheck = firstCheck;
	}

	public String getFirstCheckRemarks() {
		return firstCheckRemarks;
	}

	public void setFirstCheckRemarks(String firstCheckRemarks) {
		this.firstCheckRemarks = firstCheckRemarks;
	}

	public String getGreenChannel() {
		return greenChannel;
	}

	public void setGreenChannel(String greenChannel) {
		this.greenChannel = greenChannel;
	}

	public String getGreenChannelRemarks() {
		return greenChannelRemarks;
	}

	public void setGreenChannelRemarks(String greenChannelRemarks) {
		this.greenChannelRemarks = greenChannelRemarks;
	}

	public String getUnderSec46() {
		return underSec46;
	}

	public void setUnderSec46(String underSec46) {
		this.underSec46 = underSec46;
	}

	public String getUnderSec46Remarks() {
		return underSec46Remarks;
	}

	public void setUnderSec46Remarks(String underSec46Remarks) {
		this.underSec46Remarks = underSec46Remarks;
	}

	public String getUnderSec48() {
		return underSec48;
	}

	public void setUnderSec48(String underSec48) {
		this.underSec48 = underSec48;
	}

	public String getUnderSec48Remarks() {
		return underSec48Remarks;
	}

	public void setUnderSec48Remarks(String underSec48Remarks) {
		this.underSec48Remarks = underSec48Remarks;
	}

	public String getKachhaBE() {
		return kachhaBE;
	}

	public void setKachhaBE(String kachhaBE) {
		this.kachhaBE = kachhaBE;
	}

	public String getKachhaBERemarks() {
		return kachhaBERemarks;
	}

	public void setKachhaBERemarks(String kachhaBERemarks) {
		this.kachhaBERemarks = kachhaBERemarks;
	}

	public String getHighSeaSale() {
		return highSeaSale;
	}

	public void setHighSeaSale(String highSeaSale) {
		this.highSeaSale = highSeaSale;
	}

	public String getHighSeaSellerIEC() {
		return highSeaSellerIEC;
	}

	public void setHighSeaSellerIEC(String highSeaSellerIEC) {
		this.highSeaSellerIEC = highSeaSellerIEC;
	}

	public String getHighSeaSellerBranchSNo() {
		return highSeaSellerBranchSNo;
	}

	public void setHighSeaSellerBranchSNo(String highSeaSellerBranchSNo) {
		this.highSeaSellerBranchSNo = highSeaSellerBranchSNo;
	}

	public String getHighSeaSeller() {
		return highSeaSeller;
	}

	public void setHighSeaSeller(String highSeaSeller) {
		this.highSeaSeller = highSeaSeller;
	}

	public String getHighSeaSellerAddress() {
		return highSeaSellerAddress;
	}

	public void setHighSeaSellerAddress(String highSeaSellerAddress) {
		this.highSeaSellerAddress = highSeaSellerAddress;
	}

	public String getHighSeaSellerCity() {
		return highSeaSellerCity;
	}

	public void setHighSeaSellerCity(String highSeaSellerCity) {
		this.highSeaSellerCity = highSeaSellerCity;
	}

	public String getHighSeaSellerPinCode() {
		return highSeaSellerPinCode;
	}

	public void setHighSeaSellerPinCode(String highSeaSellerPinCode) {
		this.highSeaSellerPinCode = highSeaSellerPinCode;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getCommTaxType() {
		return commTaxType;
	}

	public void setCommTaxType(String commTaxType) {
		this.commTaxType = commTaxType;
	}

//	public String getCommTax_Type() {
//		return commTax_Type;
//	}

//	public void setCommTax_Type(String commTax_Type) {
//		this.commTax_Type = commTax_Type;
//	}

	public String getCommTaxRegnNo() {
		return commTaxRegnNo;
	}

	public void setCommTaxRegnNo(String commTaxRegnNo) {
		this.commTaxRegnNo = commTaxRegnNo;
	}

	public String getClearanceAgainstBond() {
		return clearanceAgainstBond;
	}

	public void setClearanceAgainstBond(String clearanceAgainstBond) {
		this.clearanceAgainstBond = clearanceAgainstBond;
	}

	public String getBondDetails() {
		return bondDetails;
	}

	public void setBondDetails(String bondDetails) {
		this.bondDetails = bondDetails;
	}

	public String getProcurementCertNumber() {
		return procurementCertNumber;
	}

	public void setProcurementCertNumber(String procurementCertNumber) {
		this.procurementCertNumber = procurementCertNumber;
	}

	public String getProcurementCertDate() {
		return procurementCertDate;
	}

	public void setProcurementCertDate(String procurementCertDate) {
		this.procurementCertDate = procurementCertDate;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getCommissionerate() {
		return commissionerate;
	}

	public void setCommissionerate(String commissionerate) {
		this.commissionerate = commissionerate;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}

	public String getFinalDestination() {
		return finalDestination;
	}

	public void setFinalDestination(String finalDestination) {
		this.finalDestination = finalDestination;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getTotalDuty() {
		return totalDuty;
	}

	public void setTotalDuty(String totalDuty) {
		this.totalDuty = totalDuty;
	}

	public String getTotalCIFValue() {
		return totalCIFValue;
	}

	public void setTotalCIFValue(String totalCIFValue) {
		this.totalCIFValue = totalCIFValue;
	}

	public String getTotalAssessableValue() {
		return totalAssessableValue;
	}

	public void setTotalAssessableValue(String totalAssessableValue) {
		this.totalAssessableValue = totalAssessableValue;
	}

	public String getTotalBasicDuty() {
		return totalBasicDuty;
	}

	public void setTotalBasicDuty(String totalBasicDuty) {
		this.totalBasicDuty = totalBasicDuty;
	}

	public String getTotalSurchargeDuty() {
		return totalSurchargeDuty;
	}

	public void setTotalSurchargeDuty(String totalSurchargeDuty) {
		this.totalSurchargeDuty = totalSurchargeDuty;
	}

	public String getTotalCVDDuty() {
		return totalCVDDuty;
	}

	public void setTotalCVDDuty(String totalCVDDuty) {
		this.totalCVDDuty = totalCVDDuty;
	}

	public String getTotalCustHealthCessDuty() {
		return totalCustHealthCessDuty;
	}

	public void setTotalCustHealthCessDuty(String totalCustHealthCessDuty) {
		this.totalCustHealthCessDuty = totalCustHealthCessDuty;
	}

	public String getVessel() {
		return vessel;
	}

	public void setVessel(String vessel) {
		this.vessel = vessel;
	}

	public String getTranshipmentVessel() {
		return transhipmentVessel;
	}

	public void setTranshipmentVessel(String transhipmentVessel) {
		this.transhipmentVessel = transhipmentVessel;
	}

	public String getGoodsLandingDate() {
		return goodsLandingDate;
	}

	public void setGoodsLandingDate(String goodsLandingDate) {
		this.goodsLandingDate = goodsLandingDate;
	}

	public String getVoyageNumber() {
		return voyageNumber;
	}

	public void setVoyageNumber(String voyageNumber) {
		this.voyageNumber = voyageNumber;
	}

	public String geteTA() {
		return eTA;
	}

	public void seteTA(String eTA) {
		this.eTA = eTA;
	}

	public String getRotationNumber() {
		return rotationNumber;
	}

	public void setRotationNumber(String rotationNumber) {
		this.rotationNumber = rotationNumber;
	}

	public String getRotationDate() {
		return rotationDate;
	}

	public void setRotationDate(String rotationDate) {
		this.rotationDate = rotationDate;
	}

	public String getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getCarrier() {
		return carrier;
	}

	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	public String gethAWBNumber() {
		return hAWBNumber;
	}

	public void sethAWBNumber(String hAWBNumber) {
		this.hAWBNumber = hAWBNumber;
	}

	public String gethAWBDate() {
		return hAWBDate;
	}

	public void sethAWBDate(String hAWBDate) {
		this.hAWBDate = hAWBDate;
	}

	public String getmAWBNumber() {
		return mAWBNumber;
	}

	public void setmAWBNumber(String mAWBNumber) {
		this.mAWBNumber = mAWBNumber;
	}

	public String getmAWBDate() {
		return mAWBDate;
	}

	public void setmAWBDate(String mAWBDate) {
		this.mAWBDate = mAWBDate;
	}

	public String getNoOfPkg() {
		return noOfPkg;
	}

	public void setNoOfPkg(String noOfPkg) {
		this.noOfPkg = noOfPkg;
	}

	public String getPkgUnit() {
		return pkgUnit;
	}

	public void setPkgUnit(String pkgUnit) {
		this.pkgUnit = pkgUnit;
	}

	public String getSaidToContain() {
		return saidToContain;
	}

	public void setSaidToContain(String saidToContain) {
		this.saidToContain = saidToContain;
	}

	public String getUnitOfSaidToContain() {
		return unitOfSaidToContain;
	}

	public void setUnitOfSaidToContain(String unitOfSaidToContain) {
		this.unitOfSaidToContain = unitOfSaidToContain;
	}

	public String getSaidToContain2() {
		return saidToContain2;
	}

	public void setSaidToContain2(String saidToContain2) {
		this.saidToContain2 = saidToContain2;
	}

	public String getUnitOfSaidToContain2() {
		return unitOfSaidToContain2;
	}

	public void setUnitOfSaidToContain2(String unitOfSaidToContain2) {
		this.unitOfSaidToContain2 = unitOfSaidToContain2;
	}

	public String getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(String grossWeight) {
		this.grossWeight = grossWeight;
	}

	public String getUnitOfGrossWeight() {
		return unitOfGrossWeight;
	}

	public void setUnitOfGrossWeight(String unitOfGrossWeight) {
		this.unitOfGrossWeight = unitOfGrossWeight;
	}

	public String getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(String netWeight) {
		this.netWeight = netWeight;
	}

	public String getUnitOfNetWeight() {
		return unitOfNetWeight;
	}

	public void setUnitOfNetWeight(String unitOfNetWeight) {
		this.unitOfNetWeight = unitOfNetWeight;
	}

	public String getPortOfReporting() {
		return portOfReporting;
	}

	public void setPortOfReporting(String portOfReporting) {
		this.portOfReporting = portOfReporting;
	}

	public String getGatewayIGMNo() {
		return gatewayIGMNo;
	}

	public void setGatewayIGMNo(String gatewayIGMNo) {
		this.gatewayIGMNo = gatewayIGMNo;
	}

	public String getGatewayIGMDate() {
		return gatewayIGMDate;
	}

	public void setGatewayIGMDate(String gatewayIGMDate) {
		this.gatewayIGMDate = gatewayIGMDate;
	}

	public String getGatewayInwardDate() {
		return gatewayInwardDate;
	}

	public void setGatewayInwardDate(String gatewayInwardDate) {
		this.gatewayInwardDate = gatewayInwardDate;
	}

	public String getContainerNumber() {
		return containerNumber;
	}

	public void setContainerNumber(String containerNumber) {
		this.containerNumber = containerNumber;
	}

	public String getSealNumber() {
		return sealNumber;
	}

	public void setSealNumber(String sealNumber) {
		this.sealNumber = sealNumber;
	}

	public String getContainerSize() {
		return containerSize;
	}

	public void setContainerSize(String containerSize) {
		this.containerSize = containerSize;
	}

	public String getContainerLoadType() {
		return containerLoadType;
	}

	public void setContainerLoadType(String containerLoadType) {
		this.containerLoadType = containerLoadType;
	}

	public String getContainerType() {
		return containerType;
	}

	public void setContainerType(String containerType) {
		this.containerType = containerType;
	}

	public String getTypeDesc() {
		return typeDesc;
	}

	public void setTypeDesc(String typeDesc) {
		this.typeDesc = typeDesc;
	}

	public String getTruck_No() {
		return truck_No;
	}

	public void setTruck_No(String truck_No) {
		this.truck_No = truck_No;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getInvoiceCurrency() {
		return invoiceCurrency;
	}

	public void setInvoiceCurrency(String invoiceCurrency) {
		this.invoiceCurrency = invoiceCurrency;
	}

	public String getInvoiceBank() {
		return invoiceBank;
	}

	public void setInvoiceBank(String invoiceBank) {
		this.invoiceBank = invoiceBank;
	}

	public String getInvoiceBankCert() {
		return invoiceBankCert;
	}

	public void setInvoiceBankCert(String invoiceBankCert) {
		this.invoiceBankCert = invoiceBankCert;
	}

	public String getInvoiceBankCertDate() {
		return invoiceBankCertDate;
	}

	public void setInvoiceBankCertDate(String invoiceBankCertDate) {
		this.invoiceBankCertDate = invoiceBankCertDate;
	}

	public String getInvoiceCurncRate() {
		return invoiceCurncRate;
	}

	public void setInvoiceCurncRate(String invoiceCurncRate) {
		this.invoiceCurncRate = invoiceCurncRate;
	}

	public String getInvoiceValue() {
		return invoiceValue;
	}

	public void setInvoiceValue(String invoiceValue) {
		this.invoiceValue = invoiceValue;
	}

	public String getProductValue() {
		return productValue;
	}

	public void setProductValue(String productValue) {
		this.productValue = productValue;
	}

	public String getTermsOfInvoice() {
		return termsOfInvoice;
	}

	public void setTermsOfInvoice(String termsOfInvoice) {
		this.termsOfInvoice = termsOfInvoice;
	}

	public String getConsignor() {
		return consignor;
	}

	public void setConsignor(String consignor) {
		this.consignor = consignor;
	}

	public String getConsignorCountry() {
		return consignorCountry;
	}

	public void setConsignorCountry(String consignorCountry) {
		this.consignorCountry = consignorCountry;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	public String getSellerAddr() {
		return sellerAddr;
	}

	public void setSellerAddr(String sellerAddr) {
		this.sellerAddr = sellerAddr;
	}

	public String getSellerCountry() {
		return sellerCountry;
	}

	public void setSellerCountry(String sellerCountry) {
		this.sellerCountry = sellerCountry;
	}

	public String getIndentor() {
		return indentor;
	}

	public void setIndentor(String indentor) {
		this.indentor = indentor;
	}

	public String getIndentorCountry() {
		return indentorCountry;
	}

	public void setIndentorCountry(String indentorCountry) {
		this.indentorCountry = indentorCountry;
	}

	public String getIndentorAddr() {
		return indentorAddr;
	}

	public void setIndentorAddr(String indentorAddr) {
		this.indentorAddr = indentorAddr;
	}

	public String getFreightCurrency2() {
		return freightCurrency2;
	}

	public void setFreightCurrency2(String freightCurrency2) {
		this.freightCurrency2 = freightCurrency2;
	}

	public String getFreightBank3() {
		return freightBank3;
	}

	public void setFreightBank3(String freightBank3) {
		this.freightBank3 = freightBank3;
	}

	public String getFreightBankCert4() {
		return freightBankCert4;
	}

	public void setFreightBankCert4(String freightBankCert4) {
		this.freightBankCert4 = freightBankCert4;
	}

	public String getFreightBankCertDate5() {
		return freightBankCertDate5;
	}

	public void setFreightBankCertDate5(String freightBankCertDate5) {
		this.freightBankCertDate5 = freightBankCertDate5;
	}

	public String getFreightCurncRate6() {
		return freightCurncRate6;
	}

	public void setFreightCurncRate6(String freightCurncRate6) {
		this.freightCurncRate6 = freightCurncRate6;
	}

	public String getFreightRate7() {
		return freightRate7;
	}

	public void setFreightRate7(String freightRate7) {
		this.freightRate7 = freightRate7;
	}

	public String getFreightAmount8() {
		return freightAmount8;
	}

	public void setFreightAmount8(String freightAmount8) {
		this.freightAmount8 = freightAmount8;
	}

	public String getInsuranceCurrency9() {
		return insuranceCurrency9;
	}

	public void setInsuranceCurrency9(String insuranceCurrency9) {
		this.insuranceCurrency9 = insuranceCurrency9;
	}

	public String getInsuranceBank10() {
		return insuranceBank10;
	}

	public void setInsuranceBank10(String insuranceBank10) {
		this.insuranceBank10 = insuranceBank10;
	}

	public String getInsuranceBankCert11() {
		return insuranceBankCert11;
	}

	public void setInsuranceBankCert11(String insuranceBankCert11) {
		this.insuranceBankCert11 = insuranceBankCert11;
	}

	public String getInsuranceBankCertDate12() {
		return insuranceBankCertDate12;
	}

	public void setInsuranceBankCertDate12(String insuranceBankCertDate12) {
		this.insuranceBankCertDate12 = insuranceBankCertDate12;
	}

	public String getInsuranceCurncRate13() {
		return insuranceCurncRate13;
	}

	public void setInsuranceCurncRate13(String insuranceCurncRate13) {
		this.insuranceCurncRate13 = insuranceCurncRate13;
	}

	public String getInsuranceRate14() {
		return insuranceRate14;
	}

	public void setInsuranceRate14(String insuranceRate14) {
		this.insuranceRate14 = insuranceRate14;
	}

	public String getInsuranceBasis15() {
		return insuranceBasis15;
	}

	public void setInsuranceBasis15(String insuranceBasis15) {
		this.insuranceBasis15 = insuranceBasis15;
	}

	public String getInsuranceAmount16() {
		return insuranceAmount16;
	}

	public void setInsuranceAmount16(String insuranceAmount16) {
		this.insuranceAmount16 = insuranceAmount16;
	}

	public String getMiscCurrency17() {
		return miscCurrency17;
	}

	public void setMiscCurrency17(String miscCurrency17) {
		this.miscCurrency17 = miscCurrency17;
	}

	public String getMiscBank18() {
		return miscBank18;
	}

	public void setMiscBank18(String miscBank18) {
		this.miscBank18 = miscBank18;
	}

	public String getMiscBankCert19() {
		return miscBankCert19;
	}

	public void setMiscBankCert19(String miscBankCert19) {
		this.miscBankCert19 = miscBankCert19;
	}

	public String getMiscBankCertDate20() {
		return miscBankCertDate20;
	}

	public void setMiscBankCertDate20(String miscBankCertDate20) {
		this.miscBankCertDate20 = miscBankCertDate20;
	}

	public String getMiscCurncRate21() {
		return miscCurncRate21;
	}

	public void setMiscCurncRate21(String miscCurncRate21) {
		this.miscCurncRate21 = miscCurncRate21;
	}

	public String getMiscRate22() {
		return miscRate22;
	}

	public void setMiscRate22(String miscRate22) {
		this.miscRate22 = miscRate22;
	}

	public String getMiscBasis23() {
		return miscBasis23;
	}

	public void setMiscBasis23(String miscBasis23) {
		this.miscBasis23 = miscBasis23;
	}

	public String getMiscAmount24() {
		return miscAmount24;
	}

	public void setMiscAmount24(String miscAmount24) {
		this.miscAmount24 = miscAmount24;
	}

	public String getAgencyCurrency25() {
		return agencyCurrency25;
	}

	public void setAgencyCurrency25(String agencyCurrency25) {
		this.agencyCurrency25 = agencyCurrency25;
	}

	public String getAgencyBank26() {
		return agencyBank26;
	}

	public void setAgencyBank26(String agencyBank26) {
		this.agencyBank26 = agencyBank26;
	}

	public String getAgencyBankCert27() {
		return agencyBankCert27;
	}

	public void setAgencyBankCert27(String agencyBankCert27) {
		this.agencyBankCert27 = agencyBankCert27;
	}

	public String getAgencyBankCertDate28() {
		return agencyBankCertDate28;
	}

	public void setAgencyBankCertDate28(String agencyBankCertDate28) {
		this.agencyBankCertDate28 = agencyBankCertDate28;
	}

	public String getAgencyCurncRate() {
		return agencyCurncRate;
	}

	public void setAgencyCurncRate(String agencyCurncRate) {
		this.agencyCurncRate = agencyCurncRate;
	}

	public String getAgencyRate29() {
		return agencyRate29;
	}

	public void setAgencyRate29(String agencyRate29) {
		this.agencyRate29 = agencyRate29;
	}

	public String getAgencyBasis30() {
		return agencyBasis30;
	}

	public void setAgencyBasis30(String agencyBasis30) {
		this.agencyBasis30 = agencyBasis30;
	}

	public String getAgencyAmount31() {
		return agencyAmount31;
	}

	public void setAgencyAmount31(String agencyAmount31) {
		this.agencyAmount31 = agencyAmount31;
	}

	public String getLoadingCurrency32() {
		return loadingCurrency32;
	}

	public void setLoadingCurrency32(String loadingCurrency32) {
		this.loadingCurrency32 = loadingCurrency32;
	}

	public String getLoadingBank33() {
		return loadingBank33;
	}

	public void setLoadingBank33(String loadingBank33) {
		this.loadingBank33 = loadingBank33;
	}

	public String getLoadingBankCert34() {
		return loadingBankCert34;
	}

	public void setLoadingBankCert34(String loadingBankCert34) {
		this.loadingBankCert34 = loadingBankCert34;
	}

	public String getLoadingBankCertDate35() {
		return loadingBankCertDate35;
	}

	public void setLoadingBankCertDate35(String loadingBankCertDate35) {
		this.loadingBankCertDate35 = loadingBankCertDate35;
	}

	public String getLoadingCurncRate36() {
		return loadingCurncRate36;
	}

	public void setLoadingCurncRate36(String loadingCurncRate36) {
		this.loadingCurncRate36 = loadingCurncRate36;
	}

	public String getLoadingRate37() {
		return loadingRate37;
	}

	public void setLoadingRate37(String loadingRate37) {
		this.loadingRate37 = loadingRate37;
	}

	public String getLoadingBasis38() {
		return loadingBasis38;
	}

	public void setLoadingBasis38(String loadingBasis38) {
		this.loadingBasis38 = loadingBasis38;
	}

	public String getLoadingAmount39() {
		return loadingAmount39;
	}

	public void setLoadingAmount39(String loadingAmount39) {
		this.loadingAmount39 = loadingAmount39;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getSaleCondition() {
		return saleCondition;
	}

	public void setSaleCondition(String saleCondition) {
		this.saleCondition = saleCondition;
	}

	public String getlOCNumber() {
		return lOCNumber;
	}

	public void setlOCNumber(String lOCNumber) {
		this.lOCNumber = lOCNumber;
	}

	public String getlOCDate() {
		return lOCDate;
	}

	public void setlOCDate(String lOCDate) {
		this.lOCDate = lOCDate;
	}

	public String getPurchaseOrdNo() {
		return purchaseOrdNo;
	}

	public void setPurchaseOrdNo(String purchaseOrdNo) {
		this.purchaseOrdNo = purchaseOrdNo;
	}

	public String getPurchaseOrdDate() {
		return purchaseOrdDate;
	}

	public void setPurchaseOrdDate(String purchaseOrdDate) {
		this.purchaseOrdDate = purchaseOrdDate;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getContractDate() {
		return contractDate;
	}

	public void setContractDate(String contractDate) {
		this.contractDate = contractDate;
	}

	public String getAppraiserRemark() {
		return appraiserRemark;
	}

	public void setAppraiserRemark(String appraiserRemark) {
		this.appraiserRemark = appraiserRemark;
	}

	public String getsVBLoading() {
		return sVBLoading;
	}

	public void setsVBLoading(String sVBLoading) {
		this.sVBLoading = sVBLoading;
	}

	public String getsVBRefNo() {
		return sVBRefNo;
	}

	public void setsVBRefNo(String sVBRefNo) {
		this.sVBRefNo = sVBRefNo;
	}

	public String getsVBRefDate() {
		return sVBRefDate;
	}

	public void setsVBRefDate(String sVBRefDate) {
		this.sVBRefDate = sVBRefDate;
	}

	public String getCustomsHouse() {
		return customsHouse;
	}

	public void setCustomsHouse(String customsHouse) {
		this.customsHouse = customsHouse;
	}

	public String getsVBLoadingBasis() {
		return sVBLoadingBasis;
	}

	public void setsVBLoadingBasis(String sVBLoadingBasis) {
		this.sVBLoadingBasis = sVBLoadingBasis;
	}

	public String getsVBLoadingPerAssb() {
		return sVBLoadingPerAssb;
	}

	public void setsVBLoadingPerAssb(String sVBLoadingPerAssb) {
		this.sVBLoadingPerAssb = sVBLoadingPerAssb;
	}

	public String getsVBLoadingPerDuty() {
		return sVBLoadingPerDuty;
	}

	public void setsVBLoadingPerDuty(String sVBLoadingPerDuty) {
		this.sVBLoadingPerDuty = sVBLoadingPerDuty;
	}

	public String getsVBLoadingStatusAssb() {
		return sVBLoadingStatusAssb;
	}

	public void setsVBLoadingStatusAssb(String sVBLoadingStatusAssb) {
		this.sVBLoadingStatusAssb = sVBLoadingStatusAssb;
	}

	public String getsVBLoadingStatusDuty() {
		return sVBLoadingStatusDuty;
	}

	public void setsVBLoadingStatusDuty(String sVBLoadingStatusDuty) {
		this.sVBLoadingStatusDuty = sVBLoadingStatusDuty;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getRelationBase() {
		return relationBase;
	}

	public void setRelationBase(String relationBase) {
		this.relationBase = relationBase;
	}

	public String getRelationCondition() {
		return relationCondition;
	}

	public void setRelationCondition(String relationCondition) {
		this.relationCondition = relationCondition;
	}

	public String getValuationMethod() {
		return valuationMethod;
	}

	public void setValuationMethod(String valuationMethod) {
		this.valuationMethod = valuationMethod;
	}

	public String getThirdParty_Name() {
		return thirdParty_Name;
	}

	public void setThirdParty_Name(String thirdParty_Name) {
		this.thirdParty_Name = thirdParty_Name;
	}

	public String getThirdParty_Branch() {
		return thirdParty_Branch;
	}

	public void setThirdParty_Branch(String thirdParty_Branch) {
		this.thirdParty_Branch = thirdParty_Branch;
	}

	public String getThirdParty_Address() {
		return thirdParty_Address;
	}

	public void setThirdParty_Address(String thirdParty_Address) {
		this.thirdParty_Address = thirdParty_Address;
	}

	public String getThirdParty_Cntry() {
		return thirdParty_Cntry;
	}

	public void setThirdParty_Cntry(String thirdParty_Cntry) {
		this.thirdParty_Cntry = thirdParty_Cntry;
	}

	public String getThirdParty_City() {
		return thirdParty_City;
	}

	public void setThirdParty_City(String thirdParty_City) {
		this.thirdParty_City = thirdParty_City;
	}

	public String getThirdParty_State() {
		return thirdParty_State;
	}

	public void setThirdParty_State(String thirdParty_State) {
		this.thirdParty_State = thirdParty_State;
	}

	public String getThirdParty_Pin() {
		return thirdParty_Pin;
	}

	public void setThirdParty_Pin(String thirdParty_Pin) {
		this.thirdParty_Pin = thirdParty_Pin;
	}

	public String getaEO_Cntry() {
		return aEO_Cntry;
	}

	public void setaEO_Cntry(String aEO_Cntry) {
		this.aEO_Cntry = aEO_Cntry;
	}

	public String getaEO_Role() {
		return aEO_Role;
	}

	public void setaEO_Role(String aEO_Role) {
		this.aEO_Role = aEO_Role;
	}

	public String getaEO_Code() {
		return aEO_Code;
	}

	public void setaEO_Code(String aEO_Code) {
		this.aEO_Code = aEO_Code;
	}

	public String getTermsPlace() {
		return termsPlace;
	}

	public void setTermsPlace(String termsPlace) {
		this.termsPlace = termsPlace;
	}

	public String getDiscountPer() {
		return discountPer;
	}

	public void setDiscountPer(String discountPer) {
		this.discountPer = discountPer;
	}

	public String getDiscountAmt() {
		return discountAmt;
	}

	public void setDiscountAmt(String discountAmt) {
		this.discountAmt = discountAmt;
	}

	public String getDiscountType() {
		return discountType;
	}

	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}

	public String getHighSeaChrgPer() {
		return highSeaChrgPer;
	}

	public void setHighSeaChrgPer(String highSeaChrgPer) {
		this.highSeaChrgPer = highSeaChrgPer;
	}

	public String getHighSeaChrgAmt() {
		return highSeaChrgAmt;
	}

	public void setHighSeaChrgAmt(String highSeaChrgAmt) {
		this.highSeaChrgAmt = highSeaChrgAmt;
	}

	public String getContainerCostPer() {
		return containerCostPer;
	}

	public void setContainerCostPer(String containerCostPer) {
		this.containerCostPer = containerCostPer;
	}

	public String getContainerCostAmt() {
		return containerCostAmt;
	}

	public void setContainerCostAmt(String containerCostAmt) {
		this.containerCostAmt = containerCostAmt;
	}

	public String getOriginCountryPer() {
		return originCountryPer;
	}

	public void setOriginCountryPer(String originCountryPer) {
		this.originCountryPer = originCountryPer;
	}

	public String getOriginCountryAmt() {
		return originCountryAmt;
	}

	public void setOriginCountryAmt(String originCountryAmt) {
		this.originCountryAmt = originCountryAmt;
	}

	public String getDocumentationPer() {
		return documentationPer;
	}

	public void setDocumentationPer(String documentationPer) {
		this.documentationPer = documentationPer;
	}

	public String getDocumentationAmt() {
		return documentationAmt;
	}

	public void setDocumentationAmt(String documentationAmt) {
		this.documentationAmt = documentationAmt;
	}

	public String getHandlingCostPer() {
		return handlingCostPer;
	}

	public void setHandlingCostPer(String handlingCostPer) {
		this.handlingCostPer = handlingCostPer;
	}

	public String getHandlingCostAmt() {
		return handlingCostAmt;
	}

	public void setHandlingCostAmt(String handlingCostAmt) {
		this.handlingCostAmt = handlingCostAmt;
	}

	public String getOtherChrgPer() {
		return otherChrgPer;
	}

	public void setOtherChrgPer(String otherChrgPer) {
		this.otherChrgPer = otherChrgPer;
	}

	public String getOtherChrgAmt() {
		return otherChrgAmt;
	}

	public void setOtherChrgAmt(String otherChrgAmt) {
		this.otherChrgAmt = otherChrgAmt;
	}

	public String getPackingCostPer() {
		return packingCostPer;
	}

	public void setPackingCostPer(String packingCostPer) {
		this.packingCostPer = packingCostPer;
	}

	public String getPackingCostAmt() {
		return packingCostAmt;
	}

	public void setPackingCostAmt(String packingCostAmt) {
		this.packingCostAmt = packingCostAmt;
	}

	public String getRoyaltyPer() {
		return royaltyPer;
	}

	public void setRoyaltyPer(String royaltyPer) {
		this.royaltyPer = royaltyPer;
	}

	public String getRoyaltyAmt() {
		return royaltyAmt;
	}

	public void setRoyaltyAmt(String royaltyAmt) {
		this.royaltyAmt = royaltyAmt;
	}

	public String getBuyerServiceCostPer() {
		return buyerServiceCostPer;
	}

	public void setBuyerServiceCostPer(String buyerServiceCostPer) {
		this.buyerServiceCostPer = buyerServiceCostPer;
	}

	public String getBuyerServiceCostAmt() {
		return buyerServiceCostAmt;
	}

	public void setBuyerServiceCostAmt(String buyerServiceCostAmt) {
		this.buyerServiceCostAmt = buyerServiceCostAmt;
	}

	public String getSellerObligationPer() {
		return sellerObligationPer;
	}

	public void setSellerObligationPer(String sellerObligationPer) {
		this.sellerObligationPer = sellerObligationPer;
	}

	public String getSellerObligationAmt() {
		return sellerObligationAmt;
	}

	public void setSellerObligationAmt(String sellerObligationAmt) {
		this.sellerObligationAmt = sellerObligationAmt;
	}

	public String getValueOfProceedsPer() {
		return valueOfProceedsPer;
	}

	public void setValueOfProceedsPer(String valueOfProceedsPer) {
		this.valueOfProceedsPer = valueOfProceedsPer;
	}

	public String getValueOfProceedsAmt() {
		return valueOfProceedsAmt;
	}

	public void setValueOfProceedsAmt(String valueOfProceedsAmt) {
		this.valueOfProceedsAmt = valueOfProceedsAmt;
	}

	public String getWarrantyServicePer() {
		return warrantyServicePer;
	}

	public void setWarrantyServicePer(String warrantyServicePer) {
		this.warrantyServicePer = warrantyServicePer;
	}

	public String getWarrantyServiceAmt() {
		return warrantyServiceAmt;
	}

	public void setWarrantyServiceAmt(String warrantyServiceAmt) {
		this.warrantyServiceAmt = warrantyServiceAmt;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getIsFocItem() {
		return isFocItem;
	}

	public void setIsFocItem(String isFocItem) {
		this.isFocItem = isFocItem;
	}

	public String getAltQuantity1() {
		return altQuantity1;
	}

	public void setAltQuantity1(String altQuantity1) {
		this.altQuantity1 = altQuantity1;
	}

	public String getAltUnit1() {
		return altUnit1;
	}

	public void setAltUnit1(String altUnit1) {
		this.altUnit1 = altUnit1;
	}

	public String getAltQuantity2() {
		return altQuantity2;
	}

	public void setAltQuantity2(String altQuantity2) {
		this.altQuantity2 = altQuantity2;
	}

	public String getAltUnit2() {
		return altUnit2;
	}

	public void setAltUnit2(String altUnit2) {
		this.altUnit2 = altUnit2;
	}

	public String getcTHNumber() {
		return cTHNumber;
	}

	public void setcTHNumber(String cTHNumber) {
		this.cTHNumber = cTHNumber;
	}

	public String getrITCNumber() {
		return rITCNumber;
	}

	public void setrITCNumber(String rITCNumber) {
		this.rITCNumber = rITCNumber;
	}

	public String getiTCLocation() {
		return iTCLocation;
	}

	public void setiTCLocation(String iTCLocation) {
		this.iTCLocation = iTCLocation;
	}

	public String getBasicNotn() {
		return basicNotn;
	}

	public void setBasicNotn(String basicNotn) {
		this.basicNotn = basicNotn;
	}

	public String getBasicNotnSNo() {
		return basicNotnSNo;
	}

	public void setBasicNotnSNo(String basicNotnSNo) {
		this.basicNotnSNo = basicNotnSNo;
	}

	public String getBasicDutyPer() {
		return basicDutyPer;
	}

	public void setBasicDutyPer(String basicDutyPer) {
		this.basicDutyPer = basicDutyPer;
	}

	public String getBasicDutyFlag() {
		return basicDutyFlag;
	}

	public void setBasicDutyFlag(String basicDutyFlag) {
		this.basicDutyFlag = basicDutyFlag;
	}

	public String getBasicDutyQty() {
		return basicDutyQty;
	}

	public void setBasicDutyQty(String basicDutyQty) {
		this.basicDutyQty = basicDutyQty;
	}

	public String getBasicDutyUnit() {
		return basicDutyUnit;
	}

	public void setBasicDutyUnit(String basicDutyUnit) {
		this.basicDutyUnit = basicDutyUnit;
	}

	public String getCustHealthCessNotn() {
		return custHealthCessNotn;
	}

	public void setCustHealthCessNotn(String custHealthCessNotn) {
		this.custHealthCessNotn = custHealthCessNotn;
	}

	public String getCustHealthCessNotnSNo() {
		return custHealthCessNotnSNo;
	}

	public void setCustHealthCessNotnSNo(String custHealthCessNotnSNo) {
		this.custHealthCessNotnSNo = custHealthCessNotnSNo;
	}

	public String getCustHealthCessDutyPer() {
		return custHealthCessDutyPer;
	}

	public void setCustHealthCessDutyPer(String custHealthCessDutyPer) {
		this.custHealthCessDutyPer = custHealthCessDutyPer;
	}

	public String getCustHealthCessDutyFlag() {
		return custHealthCessDutyFlag;
	}

	public void setCustHealthCessDutyFlag(String custHealthCessDutyFlag) {
		this.custHealthCessDutyFlag = custHealthCessDutyFlag;
	}

	public String getCustHealthCessDutyQty() {
		return custHealthCessDutyQty;
	}

	public void setCustHealthCessDutyQty(String custHealthCessDutyQty) {
		this.custHealthCessDutyQty = custHealthCessDutyQty;
	}

	public String getCustHealthCessDutyUnit() {
		return custHealthCessDutyUnit;
	}

	public void setCustHealthCessDutyUnit(String custHealthCessDutyUnit) {
		this.custHealthCessDutyUnit = custHealthCessDutyUnit;
	}

	public String getAltBasicNotn() {
		return altBasicNotn;
	}

	public void setAltBasicNotn(String altBasicNotn) {
		this.altBasicNotn = altBasicNotn;
	}

	public String getAltBasicNotnSNo() {
		return altBasicNotnSNo;
	}

	public void setAltBasicNotnSNo(String altBasicNotnSNo) {
		this.altBasicNotnSNo = altBasicNotnSNo;
	}

	public String getSurchargeNotn() {
		return surchargeNotn;
	}

	public void setSurchargeNotn(String surchargeNotn) {
		this.surchargeNotn = surchargeNotn;
	}

	public String getSurchargeNotnSNo() {
		return surchargeNotnSNo;
	}

	public void setSurchargeNotnSNo(String surchargeNotnSNo) {
		this.surchargeNotnSNo = surchargeNotnSNo;
	}

	public String getSurchargeRate() {
		return surchargeRate;
	}

	public void setSurchargeRate(String surchargeRate) {
		this.surchargeRate = surchargeRate;
	}

	public String getAuxillaryNotn() {
		return auxillaryNotn;
	}

	public void setAuxillaryNotn(String auxillaryNotn) {
		this.auxillaryNotn = auxillaryNotn;
	}

	public String getAuxillaryDutyPer() {
		return auxillaryDutyPer;
	}

	public void setAuxillaryDutyPer(String auxillaryDutyPer) {
		this.auxillaryDutyPer = auxillaryDutyPer;
	}

	public String getAntiDumpRatePer() {
		return antiDumpRatePer;
	}

	public void setAntiDumpRatePer(String antiDumpRatePer) {
		this.antiDumpRatePer = antiDumpRatePer;
	}

	public String getAntiDumpCurrency() {
		return antiDumpCurrency;
	}

	public void setAntiDumpCurrency(String antiDumpCurrency) {
		this.antiDumpCurrency = antiDumpCurrency;
	}

	public String getAntiDumpBank() {
		return antiDumpBank;
	}

	public void setAntiDumpBank(String antiDumpBank) {
		this.antiDumpBank = antiDumpBank;
	}

	public String getAntiDumpBankCert() {
		return antiDumpBankCert;
	}

	public void setAntiDumpBankCert(String antiDumpBankCert) {
		this.antiDumpBankCert = antiDumpBankCert;
	}

	public String getAntiDumpBankCertDate() {
		return antiDumpBankCertDate;
	}

	public void setAntiDumpBankCertDate(String antiDumpBankCertDate) {
		this.antiDumpBankCertDate = antiDumpBankCertDate;
	}

	public String getAntiDumpCurncRate() {
		return antiDumpCurncRate;
	}

	public void setAntiDumpCurncRate(String antiDumpCurncRate) {
		this.antiDumpCurncRate = antiDumpCurncRate;
	}

	public String getAntiDumpRateQty() {
		return antiDumpRateQty;
	}

	public void setAntiDumpRateQty(String antiDumpRateQty) {
		this.antiDumpRateQty = antiDumpRateQty;
	}

	public String getAntiDumpUnit() {
		return antiDumpUnit;
	}

	public void setAntiDumpUnit(String antiDumpUnit) {
		this.antiDumpUnit = antiDumpUnit;
	}

	public String getAntiDumpNotn() {
		return antiDumpNotn;
	}

	public void setAntiDumpNotn(String antiDumpNotn) {
		this.antiDumpNotn = antiDumpNotn;
	}

	public String getAntiDumpSNo() {
		return antiDumpSNo;
	}

	public void setAntiDumpSNo(String antiDumpSNo) {
		this.antiDumpSNo = antiDumpSNo;
	}

	public String getAntiDump_CTH() {
		return antiDump_CTH;
	}

	public void setAntiDump_CTH(String antiDump_CTH) {
		this.antiDump_CTH = antiDump_CTH;
	}

	public String getAntiDump_Supplier_SNo() {
		return antiDump_Supplier_SNo;
	}

	public void setAntiDump_Supplier_SNo(String antiDump_Supplier_SNo) {
		this.antiDump_Supplier_SNo = antiDump_Supplier_SNo;
	}

	public String getAntiDump_Qty() {
		return antiDump_Qty;
	}

	public void setAntiDump_Qty(String antiDump_Qty) {
		this.antiDump_Qty = antiDump_Qty;
	}

	public String getAntiDump_Tariff_Notn() {
		return antiDump_Tariff_Notn;
	}

	public void setAntiDump_Tariff_Notn(String antiDump_Tariff_Notn) {
		this.antiDump_Tariff_Notn = antiDump_Tariff_Notn;
	}

	public String getAntiDump_Tariff_SNo() {
		return antiDump_Tariff_SNo;
	}

	public void setAntiDump_Tariff_SNo(String antiDump_Tariff_SNo) {
		this.antiDump_Tariff_SNo = antiDump_Tariff_SNo;
	}

	public String getAntiDump_Tariff_Qty() {
		return antiDump_Tariff_Qty;
	}

	public void setAntiDump_Tariff_Qty(String antiDump_Tariff_Qty) {
		this.antiDump_Tariff_Qty = antiDump_Tariff_Qty;
	}

	public String getAntiDump_CalcMethod() {
		return antiDump_CalcMethod;
	}

	public void setAntiDump_CalcMethod(String antiDump_CalcMethod) {
		this.antiDump_CalcMethod = antiDump_CalcMethod;
	}

	public String getAntiDump_Tariff_Amt() {
		return antiDump_Tariff_Amt;
	}

	public void setAntiDump_Tariff_Amt(String antiDump_Tariff_Amt) {
		this.antiDump_Tariff_Amt = antiDump_Tariff_Amt;
	}

	public String getAntiDump_Tariff_Cur() {
		return antiDump_Tariff_Cur;
	}

	public void setAntiDump_Tariff_Cur(String antiDump_Tariff_Cur) {
		this.antiDump_Tariff_Cur = antiDump_Tariff_Cur;
	}

	public String getManufCode() {
		return manufCode;
	}

	public void setManufCode(String manufCode) {
		this.manufCode = manufCode;
	}

	public String getManufAdd1() {
		return manufAdd1;
	}

	public void setManufAdd1(String manufAdd1) {
		this.manufAdd1 = manufAdd1;
	}

	public String getManufAdd2() {
		return manufAdd2;
	}

	public void setManufAdd2(String manufAdd2) {
		this.manufAdd2 = manufAdd2;
	}

	public String getSourceCntry() {
		return sourceCntry;
	}

	public void setSourceCntry(String sourceCntry) {
		this.sourceCntry = sourceCntry;
	}

	public String getTransitCntry() {
		return transitCntry;
	}

	public void setTransitCntry(String transitCntry) {
		this.transitCntry = transitCntry;
	}

	public String getManufCntry() {
		return manufCntry;
	}

	public void setManufCntry(String manufCntry) {
		this.manufCntry = manufCntry;
	}

	public String getManufPostalCode() {
		return manufPostalCode;
	}

	public void setManufPostalCode(String manufPostalCode) {
		this.manufPostalCode = manufPostalCode;
	}

	public String getManufState() {
		return manufState;
	}

	public void setManufState(String manufState) {
		this.manufState = manufState;
	}

	public String getManufCodeType() {
		return manufCodeType;
	}

	public void setManufCodeType(String manufCodeType) {
		this.manufCodeType = manufCodeType;
	}

	public String getAccessoryStatus() {
		return accessoryStatus;
	}

	public void setAccessoryStatus(String accessoryStatus) {
		this.accessoryStatus = accessoryStatus;
	}

	public String getsWInfoReqd() {
		return sWInfoReqd;
	}

	public void setsWInfoReqd(String sWInfoReqd) {
		this.sWInfoReqd = sWInfoReqd;
	}

	public String getrSP_Flag() {
		return rSP_Flag;
	}

	public void setrSP_Flag(String rSP_Flag) {
		this.rSP_Flag = rSP_Flag;
	}

	public String getcVDDutyExempFlag() {
		return cVDDutyExempFlag;
	}

	public void setcVDDutyExempFlag(String cVDDutyExempFlag) {
		this.cVDDutyExempFlag = cVDDutyExempFlag;
	}

	public String getAntiDump_Tariff_CRate() {
		return antiDump_Tariff_CRate;
	}

	public void setAntiDump_Tariff_CRate(String antiDump_Tariff_CRate) {
		this.antiDump_Tariff_CRate = antiDump_Tariff_CRate;
	}

	public String getsAPTA_Notn() {
		return sAPTA_Notn;
	}

	public void setsAPTA_Notn(String sAPTA_Notn) {
		this.sAPTA_Notn = sAPTA_Notn;
	}

	public String getsAPTA_SNo() {
		return sAPTA_SNo;
	}

	public void setsAPTA_SNo(String sAPTA_SNo) {
		this.sAPTA_SNo = sAPTA_SNo;
	}

	public String geteDU_CESS_Notn() {
		return eDU_CESS_Notn;
	}

	public void seteDU_CESS_Notn(String eDU_CESS_Notn) {
		this.eDU_CESS_Notn = eDU_CESS_Notn;
	}

	public String geteDU_CESS_SNo() {
		return eDU_CESS_SNo;
	}

	public void seteDU_CESS_SNo(String eDU_CESS_SNo) {
		this.eDU_CESS_SNo = eDU_CESS_SNo;
	}

	public String geteDU_CESS_Rate() {
		return eDU_CESS_Rate;
	}

	public void seteDU_CESS_Rate(String eDU_CESS_Rate) {
		this.eDU_CESS_Rate = eDU_CESS_Rate;
	}

	public String getcEX_EDU_CESS_Notn() {
		return cEX_EDU_CESS_Notn;
	}

	public void setcEX_EDU_CESS_Notn(String cEX_EDU_CESS_Notn) {
		this.cEX_EDU_CESS_Notn = cEX_EDU_CESS_Notn;
	}

	public String getcEX_EDU_CESS_SNo() {
		return cEX_EDU_CESS_SNo;
	}

	public void setcEX_EDU_CESS_SNo(String cEX_EDU_CESS_SNo) {
		this.cEX_EDU_CESS_SNo = cEX_EDU_CESS_SNo;
	}

	public String geteDU_CESS_Rate_Excise() {
		return eDU_CESS_Rate_Excise;
	}

	public void seteDU_CESS_Rate_Excise(String eDU_CESS_Rate_Excise) {
		this.eDU_CESS_Rate_Excise = eDU_CESS_Rate_Excise;
	}

	public String getsHE_CESS_Notn() {
		return sHE_CESS_Notn;
	}

	public void setsHE_CESS_Notn(String sHE_CESS_Notn) {
		this.sHE_CESS_Notn = sHE_CESS_Notn;
	}

	public String getsHE_CESS_SNo() {
		return sHE_CESS_SNo;
	}

	public void setsHE_CESS_SNo(String sHE_CESS_SNo) {
		this.sHE_CESS_SNo = sHE_CESS_SNo;
	}

	public String getsHE_CESS_Rate() {
		return sHE_CESS_Rate;
	}

	public void setsHE_CESS_Rate(String sHE_CESS_Rate) {
		this.sHE_CESS_Rate = sHE_CESS_Rate;
	}

	public String getsHE_CESS_Rate_Excise() {
		return sHE_CESS_Rate_Excise;
	}

	public void setsHE_CESS_Rate_Excise(String sHE_CESS_Rate_Excise) {
		this.sHE_CESS_Rate_Excise = sHE_CESS_Rate_Excise;
	}

	public String getcETNumber() {
		return cETNumber;
	}

	public void setcETNumber(String cETNumber) {
		this.cETNumber = cETNumber;
	}

	public String getcVDNotn() {
		return cVDNotn;
	}

	public void setcVDNotn(String cVDNotn) {
		this.cVDNotn = cVDNotn;
	}

	public String getcVDNotnSNo() {
		return cVDNotnSNo;
	}

	public void setcVDNotnSNo(String cVDNotnSNo) {
		this.cVDNotnSNo = cVDNotnSNo;
	}

	public String getcVDDutyPer() {
		return cVDDutyPer;
	}

	public void setcVDDutyPer(String cVDDutyPer) {
		this.cVDDutyPer = cVDDutyPer;
	}

	public String getcVDDutyFlag() {
		return cVDDutyFlag;
	}

	public void setcVDDutyFlag(String cVDDutyFlag) {
		this.cVDDutyFlag = cVDDutyFlag;
	}

	public String getcVDDutyQty() {
		return cVDDutyQty;
	}

	public void setcVDDutyQty(String cVDDutyQty) {
		this.cVDDutyQty = cVDDutyQty;
	}

	public String getcVDDutyUnit() {
		return cVDDutyUnit;
	}

	public void setcVDDutyUnit(String cVDDutyUnit) {
		this.cVDDutyUnit = cVDDutyUnit;
	}

	public String getaCVDNotn() {
		return aCVDNotn;
	}

	public void setaCVDNotn(String aCVDNotn) {
		this.aCVDNotn = aCVDNotn;
	}

	public String getaCVDNotnSNo() {
		return aCVDNotnSNo;
	}

	public void setaCVDNotnSNo(String aCVDNotnSNo) {
		this.aCVDNotnSNo = aCVDNotnSNo;
	}

	public String getaCVDDutyPer() {
		return aCVDDutyPer;
	}

	public void setaCVDDutyPer(String aCVDDutyPer) {
		this.aCVDDutyPer = aCVDDutyPer;
	}

	public String getaCVDDutyFlag() {
		return aCVDDutyFlag;
	}

	public void setaCVDDutyFlag(String aCVDDutyFlag) {
		this.aCVDDutyFlag = aCVDDutyFlag;
	}

	public String getaCVDDutyQty() {
		return aCVDDutyQty;
	}

	public void setaCVDDutyQty(String aCVDDutyQty) {
		this.aCVDDutyQty = aCVDDutyQty;
	}

	public String getaCVDDutyUnit() {
		return aCVDDutyUnit;
	}

	public void setaCVDDutyUnit(String aCVDDutyUnit) {
		this.aCVDDutyUnit = aCVDDutyUnit;
	}

	public String getaCS2Notn() {
		return aCS2Notn;
	}

	public void setaCS2Notn(String aCS2Notn) {
		this.aCS2Notn = aCS2Notn;
	}

	public String getaCS2NotnSNo() {
		return aCS2NotnSNo;
	}

	public void setaCS2NotnSNo(String aCS2NotnSNo) {
		this.aCS2NotnSNo = aCS2NotnSNo;
	}

	public String getaCS2DutyPer() {
		return aCS2DutyPer;
	}

	public void setaCS2DutyPer(String aCS2DutyPer) {
		this.aCS2DutyPer = aCS2DutyPer;
	}

	public String getaCS2DutyFlag() {
		return aCS2DutyFlag;
	}

	public void setaCS2DutyFlag(String aCS2DutyFlag) {
		this.aCS2DutyFlag = aCS2DutyFlag;
	}

	public String getaCS2DutyQty() {
		return aCS2DutyQty;
	}

	public void setaCS2DutyQty(String aCS2DutyQty) {
		this.aCS2DutyQty = aCS2DutyQty;
	}

	public String getaCS2DutyUnit() {
		return aCS2DutyUnit;
	}

	public void setaCS2DutyUnit(String aCS2DutyUnit) {
		this.aCS2DutyUnit = aCS2DutyUnit;
	}

	public String getsCVDNotn() {
		return sCVDNotn;
	}

	public void setsCVDNotn(String sCVDNotn) {
		this.sCVDNotn = sCVDNotn;
	}

	public String getsCVDNotnSNo() {
		return sCVDNotnSNo;
	}

	public void setsCVDNotnSNo(String sCVDNotnSNo) {
		this.sCVDNotnSNo = sCVDNotnSNo;
	}

	public String getsCVDDutyPer() {
		return sCVDDutyPer;
	}

	public void setsCVDDutyPer(String sCVDDutyPer) {
		this.sCVDDutyPer = sCVDDutyPer;
	}

	public String getsCVDDutyFlag() {
		return sCVDDutyFlag;
	}

	public void setsCVDDutyFlag(String sCVDDutyFlag) {
		this.sCVDDutyFlag = sCVDDutyFlag;
	}

	public String getsCVDDutyQty() {
		return sCVDDutyQty;
	}

	public void setsCVDDutyQty(String sCVDDutyQty) {
		this.sCVDDutyQty = sCVDDutyQty;
	}

	public String getsCVDDutyUnit() {
		return sCVDDutyUnit;
	}

	public void setsCVDDutyUnit(String sCVDDutyUnit) {
		this.sCVDDutyUnit = sCVDDutyUnit;
	}

	public String getcESSNotn() {
		return cESSNotn;
	}

	public void setcESSNotn(String cESSNotn) {
		this.cESSNotn = cESSNotn;
	}

	public String getcESSNotnSNo() {
		return cESSNotnSNo;
	}

	public void setcESSNotnSNo(String cESSNotnSNo) {
		this.cESSNotnSNo = cESSNotnSNo;
	}

	public String getcESSDutyPer() {
		return cESSDutyPer;
	}

	public void setcESSDutyPer(String cESSDutyPer) {
		this.cESSDutyPer = cESSDutyPer;
	}

	public String getcESSDutyFlag() {
		return cESSDutyFlag;
	}

	public void setcESSDutyFlag(String cESSDutyFlag) {
		this.cESSDutyFlag = cESSDutyFlag;
	}

	public String getcESSDutyQty() {
		return cESSDutyQty;
	}

	public void setcESSDutyQty(String cESSDutyQty) {
		this.cESSDutyQty = cESSDutyQty;
	}

	public String getcESSDutyUnit() {
		return cESSDutyUnit;
	}

	public void setcESSDutyUnit(String cESSDutyUnit) {
		this.cESSDutyUnit = cESSDutyUnit;
	}

	public String getnCDNotn() {
		return nCDNotn;
	}

	public void setnCDNotn(String nCDNotn) {
		this.nCDNotn = nCDNotn;
	}

	public String getnCDNotnSNo() {
		return nCDNotnSNo;
	}

	public void setnCDNotnSNo(String nCDNotnSNo) {
		this.nCDNotnSNo = nCDNotnSNo;
	}

	public String getnCDDutyPer() {
		return nCDDutyPer;
	}

	public void setnCDDutyPer(String nCDDutyPer) {
		this.nCDDutyPer = nCDDutyPer;
	}

	public String getnCDDutyFlag() {
		return nCDDutyFlag;
	}

	public void setnCDDutyFlag(String nCDDutyFlag) {
		this.nCDDutyFlag = nCDDutyFlag;
	}

	public String getnCDDutyQty() {
		return nCDDutyQty;
	}

	public void setnCDDutyQty(String nCDDutyQty) {
		this.nCDDutyQty = nCDDutyQty;
	}

	public String getnCDDutyUnit() {
		return nCDDutyUnit;
	}

	public void setnCDDutyUnit(String nCDDutyUnit) {
		this.nCDDutyUnit = nCDDutyUnit;
	}

	public String getsADNotn() {
		return sADNotn;
	}

	public void setsADNotn(String sADNotn) {
		this.sADNotn = sADNotn;
	}

	public String getsADNotnSNo() {
		return sADNotnSNo;
	}

	public void setsADNotnSNo(String sADNotnSNo) {
		this.sADNotnSNo = sADNotnSNo;
	}

	public String getsADDutyPer() {
		return sADDutyPer;
	}

	public void setsADDutyPer(String sADDutyPer) {
		this.sADDutyPer = sADDutyPer;
	}

	public String gethLTHNotn() {
		return hLTHNotn;
	}

	public void sethLTHNotn(String hLTHNotn) {
		this.hLTHNotn = hLTHNotn;
	}

	public String gethLTHNotnSNo() {
		return hLTHNotnSNo;
	}

	public void sethLTHNotnSNo(String hLTHNotnSNo) {
		this.hLTHNotnSNo = hLTHNotnSNo;
	}

	public String gethLTHDutyPer() {
		return hLTHDutyPer;
	}

	public void sethLTHDutyPer(String hLTHDutyPer) {
		this.hLTHDutyPer = hLTHDutyPer;
	}

	public String gethLTHDutyFlag() {
		return hLTHDutyFlag;
	}

	public void sethLTHDutyFlag(String hLTHDutyFlag) {
		this.hLTHDutyFlag = hLTHDutyFlag;
	}

	public String gethLTHDutyQty() {
		return hLTHDutyQty;
	}

	public void sethLTHDutyQty(String hLTHDutyQty) {
		this.hLTHDutyQty = hLTHDutyQty;
	}

	public String gethLTHDutyUnit() {
		return hLTHDutyUnit;
	}

	public void sethLTHDutyUnit(String hLTHDutyUnit) {
		this.hLTHDutyUnit = hLTHDutyUnit;
	}

	public String getAddlDutyNotn() {
		return addlDutyNotn;
	}

	public void setAddlDutyNotn(String addlDutyNotn) {
		this.addlDutyNotn = addlDutyNotn;
	}

	public String getAddlDutyNotnSNo() {
		return addlDutyNotnSNo;
	}

	public void setAddlDutyNotnSNo(String addlDutyNotnSNo) {
		this.addlDutyNotnSNo = addlDutyNotnSNo;
	}

	public String getAddlDutyPer() {
		return addlDutyPer;
	}

	public void setAddlDutyPer(String addlDutyPer) {
		this.addlDutyPer = addlDutyPer;
	}

	public String getAggrDutyNotn() {
		return aggrDutyNotn;
	}

	public void setAggrDutyNotn(String aggrDutyNotn) {
		this.aggrDutyNotn = aggrDutyNotn;
	}

	public String getAggrDutyNotnSNo() {
		return aggrDutyNotnSNo;
	}

	public void setAggrDutyNotnSNo(String aggrDutyNotnSNo) {
		this.aggrDutyNotnSNo = aggrDutyNotnSNo;
	}

	public String getAggrDutyPer() {
		return aggrDutyPer;
	}

	public void setAggrDutyPer(String aggrDutyPer) {
		this.aggrDutyPer = aggrDutyPer;
	}

	public String getsGDutyNotn() {
		return sGDutyNotn;
	}

	public void setsGDutyNotn(String sGDutyNotn) {
		this.sGDutyNotn = sGDutyNotn;
	}

	public String getsGDutyNotnSNo() {
		return sGDutyNotnSNo;
	}

	public void setsGDutyNotnSNo(String sGDutyNotnSNo) {
		this.sGDutyNotnSNo = sGDutyNotnSNo;
	}

	public String getsGDutyPer() {
		return sGDutyPer;
	}

	public void setsGDutyPer(String sGDutyPer) {
		this.sGDutyPer = sGDutyPer;
	}

	public String getiGSTNotnNo() {
		return iGSTNotnNo;
	}

	public void setiGSTNotnNo(String iGSTNotnNo) {
		this.iGSTNotnNo = iGSTNotnNo;
	}

	public String getiGSTNotnSrNo() {
		return iGSTNotnSrNo;
	}

	public void setiGSTNotnSrNo(String iGSTNotnSrNo) {
		this.iGSTNotnSrNo = iGSTNotnSrNo;
	}

	public String getiGSTNotnRatePer() {
		return iGSTNotnRatePer;
	}

	public void setiGSTNotnRatePer(String iGSTNotnRatePer) {
		this.iGSTNotnRatePer = iGSTNotnRatePer;
	}

	public String getiGSTNotnDutyFlag() {
		return iGSTNotnDutyFlag;
	}

	public void setiGSTNotnDutyFlag(String iGSTNotnDutyFlag) {
		this.iGSTNotnDutyFlag = iGSTNotnDutyFlag;
	}

	public String getiGSTNotnDutyQty() {
		return iGSTNotnDutyQty;
	}

	public void setiGSTNotnDutyQty(String iGSTNotnDutyQty) {
		this.iGSTNotnDutyQty = iGSTNotnDutyQty;
	}

	public String getiGSTNotnDutyUnit() {
		return iGSTNotnDutyUnit;
	}

	public void setiGSTNotnDutyUnit(String iGSTNotnDutyUnit) {
		this.iGSTNotnDutyUnit = iGSTNotnDutyUnit;
	}

	public String getgSTCESSNotnNo() {
		return gSTCESSNotnNo;
	}

	public void setgSTCESSNotnNo(String gSTCESSNotnNo) {
		this.gSTCESSNotnNo = gSTCESSNotnNo;
	}

	public String getgSTCESSNotnSrNo() {
		return gSTCESSNotnSrNo;
	}

	public void setgSTCESSNotnSrNo(String gSTCESSNotnSrNo) {
		this.gSTCESSNotnSrNo = gSTCESSNotnSrNo;
	}

	public String getgSTCESSNotnRatePer() {
		return gSTCESSNotnRatePer;
	}

	public void setgSTCESSNotnRatePer(String gSTCESSNotnRatePer) {
		this.gSTCESSNotnRatePer = gSTCESSNotnRatePer;
	}

	public String getgSTCESSNotnDutyFlag() {
		return gSTCESSNotnDutyFlag;
	}

	public void setgSTCESSNotnDutyFlag(String gSTCESSNotnDutyFlag) {
		this.gSTCESSNotnDutyFlag = gSTCESSNotnDutyFlag;
	}

	public String getgSTCESSNotnDutyQty() {
		return gSTCESSNotnDutyQty;
	}

	public void setgSTCESSNotnDutyQty(String gSTCESSNotnDutyQty) {
		this.gSTCESSNotnDutyQty = gSTCESSNotnDutyQty;
	}

	public String getgSTCESSNotnDutyUnit() {
		return gSTCESSNotnDutyUnit;
	}

	public void setgSTCESSNotnDutyUnit(String gSTCESSNotnDutyUnit) {
		this.gSTCESSNotnDutyUnit = gSTCESSNotnDutyUnit;
	}

	public String getiGSTExemptNotnNo() {
		return iGSTExemptNotnNo;
	}

	public void setiGSTExemptNotnNo(String iGSTExemptNotnNo) {
		this.iGSTExemptNotnNo = iGSTExemptNotnNo;
	}

	public String getiGSTExemptNotnSrNo() {
		return iGSTExemptNotnSrNo;
	}

	public void setiGSTExemptNotnSrNo(String iGSTExemptNotnSrNo) {
		this.iGSTExemptNotnSrNo = iGSTExemptNotnSrNo;
	}

	public String getiGSTExempNotnType() {
		return iGSTExempNotnType;
	}

	public void setiGSTExempNotnType(String iGSTExempNotnType) {
		this.iGSTExempNotnType = iGSTExempNotnType;
	}

	public String getiGSTExempNotnRatePer() {
		return iGSTExempNotnRatePer;
	}

	public void setiGSTExempNotnRatePer(String iGSTExempNotnRatePer) {
		this.iGSTExempNotnRatePer = iGSTExempNotnRatePer;
	}

	public String getiGSTExemptNotnDutyFlag() {
		return iGSTExemptNotnDutyFlag;
	}

	public void setiGSTExemptNotnDutyFlag(String iGSTExemptNotnDutyFlag) {
		this.iGSTExemptNotnDutyFlag = iGSTExemptNotnDutyFlag;
	}

	public String getiGSTExemptNotnDutyQty() {
		return iGSTExemptNotnDutyQty;
	}

	public void setiGSTExemptNotnDutyQty(String iGSTExemptNotnDutyQty) {
		this.iGSTExemptNotnDutyQty = iGSTExemptNotnDutyQty;
	}

	public String getiGSTExemptNotnDutyUnit() {
		return iGSTExemptNotnDutyUnit;
	}

	public void setiGSTExemptNotnDutyUnit(String iGSTExemptNotnDutyUnit) {
		this.iGSTExemptNotnDutyUnit = iGSTExemptNotnDutyUnit;
	}

	public String getgSTCESSExemptNotnNo() {
		return gSTCESSExemptNotnNo;
	}

	public void setgSTCESSExemptNotnNo(String gSTCESSExemptNotnNo) {
		this.gSTCESSExemptNotnNo = gSTCESSExemptNotnNo;
	}

	public String getgSTCESSExemptNotnSrNo() {
		return gSTCESSExemptNotnSrNo;
	}

	public void setgSTCESSExemptNotnSrNo(String gSTCESSExemptNotnSrNo) {
		this.gSTCESSExemptNotnSrNo = gSTCESSExemptNotnSrNo;
	}

	public String getgSTCCESSExempNotnType() {
		return gSTCCESSExempNotnType;
	}

	public void setgSTCCESSExempNotnType(String gSTCCESSExempNotnType) {
		this.gSTCCESSExempNotnType = gSTCCESSExempNotnType;
	}

	public String getgSTCCESSExempNotnRatePer() {
		return gSTCCESSExempNotnRatePer;
	}

	public void setgSTCCESSExempNotnRatePer(String gSTCCESSExempNotnRatePer) {
		this.gSTCCESSExempNotnRatePer = gSTCCESSExempNotnRatePer;
	}

	public String getgSTCCESSExemptNotnDutyFlag() {
		return gSTCCESSExemptNotnDutyFlag;
	}

	public void setgSTCCESSExemptNotnDutyFlag(String gSTCCESSExemptNotnDutyFlag) {
		this.gSTCCESSExemptNotnDutyFlag = gSTCCESSExemptNotnDutyFlag;
	}

	public String getgSTCCESSExemptNotnDutyQty() {
		return gSTCCESSExemptNotnDutyQty;
	}

	public void setgSTCCESSExemptNotnDutyQty(String gSTCCESSExemptNotnDutyQty) {
		this.gSTCCESSExemptNotnDutyQty = gSTCCESSExemptNotnDutyQty;
	}

	public String getgSTCCESSExemptNotnDutyUnit() {
		return gSTCCESSExemptNotnDutyUnit;
	}

	public void setgSTCCESSExemptNotnDutyUnit(String gSTCCESSExemptNotnDutyUnit) {
		this.gSTCCESSExemptNotnDutyUnit = gSTCCESSExemptNotnDutyUnit;
	}

	public String getrD_INFRA_CESS_Notn() {
		return rD_INFRA_CESS_Notn;
	}

	public void setrD_INFRA_CESS_Notn(String rD_INFRA_CESS_Notn) {
		this.rD_INFRA_CESS_Notn = rD_INFRA_CESS_Notn;
	}

	public String getrD_INFRA_CESS_NotnSNo() {
		return rD_INFRA_CESS_NotnSNo;
	}

	public void setrD_INFRA_CESS_NotnSNo(String rD_INFRA_CESS_NotnSNo) {
		this.rD_INFRA_CESS_NotnSNo = rD_INFRA_CESS_NotnSNo;
	}

	public String getrD_INFRA_CESS_DutyPer() {
		return rD_INFRA_CESS_DutyPer;
	}

	public void setrD_INFRA_CESS_DutyPer(String rD_INFRA_CESS_DutyPer) {
		this.rD_INFRA_CESS_DutyPer = rD_INFRA_CESS_DutyPer;
	}

	public String getrD_INFRA_CESS_DutyFlag() {
		return rD_INFRA_CESS_DutyFlag;
	}

	public void setrD_INFRA_CESS_DutyFlag(String rD_INFRA_CESS_DutyFlag) {
		this.rD_INFRA_CESS_DutyFlag = rD_INFRA_CESS_DutyFlag;
	}

	public String getrD_INFRA_CESS_DutyQty() {
		return rD_INFRA_CESS_DutyQty;
	}

	public void setrD_INFRA_CESS_DutyQty(String rD_INFRA_CESS_DutyQty) {
		this.rD_INFRA_CESS_DutyQty = rD_INFRA_CESS_DutyQty;
	}

	public String getrD_INFRA_CESS_DutyUnit() {
		return rD_INFRA_CESS_DutyUnit;
	}

	public void setrD_INFRA_CESS_DutyUnit(String rD_INFRA_CESS_DutyUnit) {
		this.rD_INFRA_CESS_DutyUnit = rD_INFRA_CESS_DutyUnit;
	}

	public String getsWSNotn() {
		return sWSNotn;
	}

	public void setsWSNotn(String sWSNotn) {
		this.sWSNotn = sWSNotn;
	}

	public String getsWSNotnSNo() {
		return sWSNotnSNo;
	}

	public void setsWSNotnSNo(String sWSNotnSNo) {
		this.sWSNotnSNo = sWSNotnSNo;
	}

	public String getsWSDutyPer() {
		return sWSDutyPer;
	}

	public void setsWSDutyPer(String sWSDutyPer) {
		this.sWSDutyPer = sWSDutyPer;
	}

	public String getiTCHSCode() {
		return iTCHSCode;
	}

	public void setiTCHSCode(String iTCHSCode) {
		this.iTCHSCode = iTCHSCode;
	}

	public String getPolicyPaara() {
		return policyPaara;
	}

	public void setPolicyPaara(String policyPaara) {
		this.policyPaara = policyPaara;
	}

	public String getPolicyYear() {
		return policyYear;
	}

	public void setPolicyYear(String policyYear) {
		this.policyYear = policyYear;
	}

	public String getLoadingInPer() {
		return loadingInPer;
	}

	public void setLoadingInPer(String loadingInPer) {
		this.loadingInPer = loadingInPer;
	}

	public String getLoadingBasis40() {
		return loadingBasis40;
	}

	public void setLoadingBasis40(String loadingBasis40) {
		this.loadingBasis40 = loadingBasis40;
	}

	public String getLoadingInQty() {
		return loadingInQty;
	}

	public void setLoadingInQty(String loadingInQty) {
		this.loadingInQty = loadingInQty;
	}

	public String getLoadingAmount41() {
		return loadingAmount41;
	}

	public void setLoadingAmount41(String loadingAmount41) {
		this.loadingAmount41 = loadingAmount41;
	}

	public String getsVBRefNo42() {
		return sVBRefNo42;
	}

	public void setsVBRefNo42(String sVBRefNo42) {
		this.sVBRefNo42 = sVBRefNo42;
	}

	public String getsVBRefDate43() {
		return sVBRefDate43;
	}

	public void setsVBRefDate43(String sVBRefDate43) {
		this.sVBRefDate43 = sVBRefDate43;
	}

	public String getCustomsHouse44() {
		return customsHouse44;
	}

	public void setCustomsHouse44(String customsHouse44) {
		this.customsHouse44 = customsHouse44;
	}

	public String getsVBLoadingBasis45() {
		return sVBLoadingBasis45;
	}

	public void setsVBLoadingBasis45(String sVBLoadingBasis45) {
		this.sVBLoadingBasis45 = sVBLoadingBasis45;
	}

	public String getsVBLoadingPerAssb46() {
		return sVBLoadingPerAssb46;
	}

	public void setsVBLoadingPerAssb46(String sVBLoadingPerAssb46) {
		this.sVBLoadingPerAssb46 = sVBLoadingPerAssb46;
	}

	public String getsVBLoadingPerDuty47() {
		return sVBLoadingPerDuty47;
	}

	public void setsVBLoadingPerDuty47(String sVBLoadingPerDuty47) {
		this.sVBLoadingPerDuty47 = sVBLoadingPerDuty47;
	}

	public String getsVBLoadingStatusAssb48() {
		return sVBLoadingStatusAssb48;
	}

	public void setsVBLoadingStatusAssb48(String sVBLoadingStatusAssb48) {
		this.sVBLoadingStatusAssb48 = sVBLoadingStatusAssb48;
	}

	public String getsVBLoadingStatusDuty49() {
		return sVBLoadingStatusDuty49;
	}

	public void setsVBLoadingStatusDuty49(String sVBLoadingStatusDuty49) {
		this.sVBLoadingStatusDuty49 = sVBLoadingStatusDuty49;
	}

	public String getGenericDesc() {
		return genericDesc;
	}

	public void setGenericDesc(String genericDesc) {
		this.genericDesc = genericDesc;
	}

	public String getAccessory() {
		return accessory;
	}

	public void setAccessory(String accessory) {
		this.accessory = accessory;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getEndUse() {
		return endUse;
	}

	public void setEndUse(String endUse) {
		this.endUse = endUse;
	}

	public String getCountryOfOrigin50() {
		return countryOfOrigin50;
	}

	public void setCountryOfOrigin50(String countryOfOrigin50) {
		this.countryOfOrigin50 = countryOfOrigin50;
	}

	public String getmRPSNo() {
		return mRPSNo;
	}

	public void setmRPSNo(String mRPSNo) {
		this.mRPSNo = mRPSNo;
	}

	public String getmRP() {
		return mRP;
	}

	public void setmRP(String mRP) {
		this.mRP = mRP;
	}

	public String getmRPUnit() {
		return mRPUnit;
	}

	public void setmRPUnit(String mRPUnit) {
		this.mRPUnit = mRPUnit;
	}

	public String getAbatement() {
		return abatement;
	}

	public void setAbatement(String abatement) {
		this.abatement = abatement;
	}

	public String geteXIMCode() {
		return eXIMCode;
	}

	public void seteXIMCode(String eXIMCode) {
		this.eXIMCode = eXIMCode;
	}

	public String getSchemeNotn() {
		return schemeNotn;
	}

	public void setSchemeNotn(String schemeNotn) {
		this.schemeNotn = schemeNotn;
	}

	public String getSchemeNotnSNo() {
		return schemeNotnSNo;
	}

	public void setSchemeNotnSNo(String schemeNotnSNo) {
		this.schemeNotnSNo = schemeNotnSNo;
	}

	public String getPrevImpBENo() {
		return prevImpBENo;
	}

	public void setPrevImpBENo(String prevImpBENo) {
		this.prevImpBENo = prevImpBENo;
	}

	public String getPrevImpBEDate() {
		return prevImpBEDate;
	}

	public void setPrevImpBEDate(String prevImpBEDate) {
		this.prevImpBEDate = prevImpBEDate;
	}

	public String getPrevImpCurrency() {
		return prevImpCurrency;
	}

	public void setPrevImpCurrency(String prevImpCurrency) {
		this.prevImpCurrency = prevImpCurrency;
	}

	public String getPrevImpValue() {
		return prevImpValue;
	}

	public void setPrevImpValue(String prevImpValue) {
		this.prevImpValue = prevImpValue;
	}

	public String getPrevImpCustomHouse() {
		return prevImpCustomHouse;
	}

	public void setPrevImpCustomHouse(String prevImpCustomHouse) {
		this.prevImpCustomHouse = prevImpCustomHouse;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getDutyRateType() {
		return dutyRateType;
	}

	public void setDutyRateType(String dutyRateType) {
		this.dutyRateType = dutyRateType;
	}

	public String getrSPNotn() {
		return rSPNotn;
	}

	public void setrSPNotn(String rSPNotn) {
		this.rSPNotn = rSPNotn;
	}

	public String getrSPNotnSNo() {
		return rSPNotnSNo;
	}

	public void setrSPNotnSNo(String rSPNotnSNo) {
		this.rSPNotnSNo = rSPNotnSNo;
	}

	public String getReImportDtls() {
		return reImportDtls;
	}

	public void setReImportDtls(String reImportDtls) {
		this.reImportDtls = reImportDtls;
	}

	public String getInfoType() {
		return infoType;
	}

	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}

	public String getInfoQualifier() {
		return infoQualifier;
	}

	public void setInfoQualifier(String infoQualifier) {
		this.infoQualifier = infoQualifier;
	}

	public String getInfoCode() {
		return infoCode;
	}

	public void setInfoCode(String infoCode) {
		this.infoCode = infoCode;
	}

	public String getInfoText() {
		return infoText;
	}

	public void setInfoText(String infoText) {
		this.infoText = infoText;
	}

	public String getInfoMeasure() {
		return infoMeasure;
	}

	public void setInfoMeasure(String infoMeasure) {
		this.infoMeasure = infoMeasure;
	}

	public String getInfoMeasUnit() {
		return infoMeasUnit;
	}

	public void setInfoMeasUnit(String infoMeasUnit) {
		this.infoMeasUnit = infoMeasUnit;
	}

	public String getImpProdConsts() {
		return impProdConsts;
	}

	public void setImpProdConsts(String impProdConsts) {
		this.impProdConsts = impProdConsts;
	}

	public String getImpProdBatches() {
		return impProdBatches;
	}

	public void setImpProdBatches(String impProdBatches) {
		this.impProdBatches = impProdBatches;
	}

	public String getImpProdControls() {
		return impProdControls;
	}

	public void setImpProdControls(String impProdControls) {
		this.impProdControls = impProdControls;
	}

	public String getLicNo() {
		return licNo;
	}

	public void setLicNo(String licNo) {
		this.licNo = licNo;
	}

	public String getLicDate() {
		return licDate;
	}

	public void setLicDate(String licDate) {
		this.licDate = licDate;
	}

	public String getDebitValue() {
		return debitValue;
	}

	public void setDebitValue(String debitValue) {
		this.debitValue = debitValue;
	}

	public String getQuantity51() {
		return quantity51;
	}

	public void setQuantity51(String quantity51) {
		this.quantity51 = quantity51;
	}

	public String getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(String documentNo) {
		this.documentNo = documentNo;
	}

	public String getReleaseAdvNo() {
		return releaseAdvNo;
	}

	public void setReleaseAdvNo(String releaseAdvNo) {
		this.releaseAdvNo = releaseAdvNo;
	}

	public String getReleaseAdvDate() {
		return releaseAdvDate;
	}

	public void setReleaseAdvDate(String releaseAdvDate) {
		this.releaseAdvDate = releaseAdvDate;
	}

	public String getRegisteredPort() {
		return registeredPort;
	}

	public void setRegisteredPort(String registeredPort) {
		this.registeredPort = registeredPort;
	}

	public String getProdAmtRs() {
		return prodAmtRs;
	}

	public void setProdAmtRs(String prodAmtRs) {
		this.prodAmtRs = prodAmtRs;
	}

	public String getFreight() {
		return freight;
	}

	public void setFreight(String freight) {
		this.freight = freight;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getCommission() {
		return commission;
	}

	public void setCommission(String commission) {
		this.commission = commission;
	}

	public String getMiscellaneous() {
		return miscellaneous;
	}

	public void setMiscellaneous(String miscellaneous) {
		this.miscellaneous = miscellaneous;
	}

	public String getcIFValue() {
		return cIFValue;
	}

	public void setcIFValue(String cIFValue) {
		this.cIFValue = cIFValue;
	}

	public String getAssessableValue() {
		return assessableValue;
	}

	public void setAssessableValue(String assessableValue) {
		this.assessableValue = assessableValue;
	}

	public String getTotalBasicDutyAmt() {
		return totalBasicDutyAmt;
	}

	public void setTotalBasicDutyAmt(String totalBasicDutyAmt) {
		this.totalBasicDutyAmt = totalBasicDutyAmt;
	}

	public String getTotalCVDAmt() {
		return totalCVDAmt;
	}

	public void setTotalCVDAmt(String totalCVDAmt) {
		this.totalCVDAmt = totalCVDAmt;
	}

	public String getTotalDutyAmt() {
		return totalDutyAmt;
	}

	public void setTotalDutyAmt(String totalDutyAmt) {
		this.totalDutyAmt = totalDutyAmt;
	}

		@Override
	public String toString() {
		return "Purchase [id=" + id + ", username=" + username + ", compIec=" + compIec 
				+  ",  version=" +  version
				+  ",  sender=" +  sender
				+  ",  receiver=" +  receiver
				+  ",  noOfDocuments=" +  noOfDocuments
				+  ",  generatedOn=" +  generatedOn
				+  ",  generator=" +  generator
				+  ",  doc_ID=" +  doc_ID
				+  ",  importer=" +  importer
				+  ",  importerBranchID=" +  importerBranchID
				+  ",  partyBank=" +  partyBank
				+  ",  destPort=" +  destPort
				+  ",  transportMode=" +  transportMode
				+  ",  typeOfBE=" +  typeOfBE
				+  ",  portOfShipment=" +  portOfShipment
				+  ",  freightMode=" +  freightMode
				+  ",  countryOfOrigin=" +  countryOfOrigin
				+  ",  alternateCountryOfOrigin=" +  alternateCountryOfOrigin
				+  ",  countryOfShipment=" +  countryOfShipment
				+  ",  bEHeading=" +  bEHeading
				+  ",  bENo=" +  bENo
				+  ",  bEDate=" +  bEDate
				+  ",  marks=" +  marks
				+  ",  freightCurrency=" +  freightCurrency
				+  ",  freightBank=" +  freightBank
				+  ",  freightBankCert=" +  freightBankCert
				+  ",  freightBankCertDate=" +  freightBankCertDate
				+  ",  freightCurncRate=" +  freightCurncRate
				+  ",  freightRate=" +  freightRate
				+  ",  freightAmount=" +  freightAmount
				+  ",  insuranceCurrency=" +  insuranceCurrency
				+  ",  insuranceBank=" +  insuranceBank
				+  ",  insuranceBankCert=" +  insuranceBankCert
				+  ",  insuranceBankCertDate=" +  insuranceBankCertDate
				+  ",  insuranceCurncRate=" +  insuranceCurncRate
				+  ",  insuranceRate=" +  insuranceRate
				+  ",  insuranceBasis=" +  insuranceBasis
				+  ",  insuranceAmount=" +  insuranceAmount
				+  ",  miscCurrency=" +  miscCurrency
				+  ",  miscBank=" +  miscBank
				+  ",  miscBankCert=" +  miscBankCert
				+  ",  miscBankCertDate=" +  miscBankCertDate
				+  ",  miscCurncRate=" +  miscCurncRate
				+  ",  miscRate=" +  miscRate
				+  ",  miscBasis=" +  miscBasis
				+  ",  miscAmount=" +  miscAmount
				+  ",  agencyCurrency=" +  agencyCurrency
				+  ",  agencyBank=" +  agencyBank
				+  ",  agencyBankCert=" +  agencyBankCert
				+  ",  agencyBankCertDate=" +  agencyBankCertDate
				+  ",  agencyRate=" +  agencyRate
				+  ",  agencyBasis=" +  agencyBasis
				+  ",  agencyAmount=" +  agencyAmount
				+  ",  loadingCurrency=" +  loadingCurrency
				+  ",  loadingBank=" +  loadingBank
				+  ",  loadingBankCert=" +  loadingBankCert
				+  ",  loadingBankCertDate=" +  loadingBankCertDate
				+  ",  loadingCurncRate=" +  loadingCurncRate
				+  ",  loadingRate=" +  loadingRate
				+  ",  loadingBasis=" +  loadingBasis
				+  ",  loadingAmount=" +  loadingAmount
				+  ",  wareHouse=" +  wareHouse
				+  ",  wareHouseCode=" +  wareHouseCode
				+  ",  partyRef=" +  partyRef
				+  ",  revenueDeposit=" +  revenueDeposit
				+  ",  revenueDepBasis=" +  revenueDepBasis
				+  ",  bECategory=" +  bECategory
				+  ",  filingStatus=" +  filingStatus
				+  ",  firstCheck=" +  firstCheck
				+  ",  firstCheckRemarks=" +  firstCheckRemarks
				+  ",  greenChannel=" +  greenChannel
				+  ",  greenChannelRemarks=" +  greenChannelRemarks
				+  ",  underSec46=" +  underSec46
				+  ",  underSec46Remarks=" +  underSec46Remarks
				+  ",  underSec48=" +  underSec48
				+  ",  underSec48Remarks=" +  underSec48Remarks
				+  ",  kachhaBE=" +  kachhaBE
				+  ",  kachhaBERemarks=" +  kachhaBERemarks
				+  ",  highSeaSale=" +  highSeaSale
				+  ",  highSeaSellerIEC=" +  highSeaSellerIEC
				+  ",  highSeaSellerBranchSNo=" +  highSeaSellerBranchSNo
				+  ",  highSeaSeller=" +  highSeaSeller
				+  ",  highSeaSellerAddress=" +  highSeaSellerAddress
				+  ",  highSeaSellerCity=" +  highSeaSellerCity
				+  ",  highSeaSellerPinCode=" +  highSeaSellerPinCode
				+  ",  stateCode=" +  stateCode
				+  ",  stateName=" +  stateName
				+  ",  commTaxType=" +  commTaxType
//				+  ",  commTax_Type=" +  commTax_Type
				+  ",  commTaxRegnNo=" +  commTaxRegnNo
				+  ",  clearanceAgainstBond=" +  clearanceAgainstBond
				+  ",  bondDetails=" +  bondDetails
				+  ",  procurementCertNumber=" +  procurementCertNumber
				+  ",  procurementCertDate=" +  procurementCertDate
				+  ",  certificateType=" +  certificateType
				+  ",  commissionerate=" +  commissionerate
				+  ",  division=" +  division
				+  ",  range=" +  range
				+  ",  finalDestination=" +  finalDestination
				+  ",  remarks=" +  remarks
				+  ",  totalDuty=" +  totalDuty
				+  ",  totalCIFValue=" +  totalCIFValue
				+  ",  totalAssessableValue=" +  totalAssessableValue
				+  ",  totalBasicDuty=" +  totalBasicDuty
				+  ",  totalSurchargeDuty=" +  totalSurchargeDuty
				+  ",  totalCVDDuty=" +  totalCVDDuty
				+  ",  totalCustHealthCessDuty=" +  totalCustHealthCessDuty
				+  ",  vessel=" +  vessel
				+  ",  transhipmentVessel=" +  transhipmentVessel
				+  ",  goodsLandingDate=" +  goodsLandingDate
				+  ",  voyageNumber=" +  voyageNumber
				+  ",  eTA=" +  eTA
				+  ",  rotationNumber=" +  rotationNumber
				+  ",  rotationDate=" +  rotationDate
				+  ",  lineNumber=" +  lineNumber
				+  ",  carrier=" +  carrier
				+  ",  hAWBNumber=" +  hAWBNumber
				+  ",  hAWBDate=" +  hAWBDate
				+  ",  mAWBNumber=" +  mAWBNumber
				+  ",  mAWBDate=" +  mAWBDate
				+  ",  noOfPkg=" +  noOfPkg
				+  ",  pkgUnit=" +  pkgUnit
				+  ",  saidToContain=" +  saidToContain
				+  ",  unitOfSaidToContain=" +  unitOfSaidToContain
				+  ",  saidToContain2=" +  saidToContain2
				+  ",  unitOfSaidToContain2=" +  unitOfSaidToContain2
				+  ",  grossWeight=" +  grossWeight
				+  ",  unitOfGrossWeight=" +  unitOfGrossWeight
				+  ",  netWeight=" +  netWeight
				+  ",  unitOfNetWeight=" +  unitOfNetWeight
				+  ",  portOfReporting=" +  portOfReporting
				+  ",  gatewayIGMNo=" +  gatewayIGMNo
				+  ",  gatewayIGMDate=" +  gatewayIGMDate
				+  ",  gatewayInwardDate=" +  gatewayInwardDate
				+  ",  containerNumber=" +  containerNumber
				+  ",  sealNumber=" +  sealNumber
				+  ",  containerSize=" +  containerSize
				+  ",  containerLoadType=" +  containerLoadType
				+  ",  containerType=" +  containerType
				+  ",  typeDesc=" +  typeDesc
				+  ",  truck_No=" +  truck_No
				+  ",  invoiceNo=" +  invoiceNo
				+  ",  invoiceDate=" +  invoiceDate
				+  ",  invoiceCurrency=" +  invoiceCurrency
				+  ",  invoiceBank=" +  invoiceBank
				+  ",  invoiceBankCert=" +  invoiceBankCert
				+  ",  invoiceBankCertDate=" +  invoiceBankCertDate
				+  ",  invoiceCurncRate=" +  invoiceCurncRate
				+  ",  invoiceValue=" +  invoiceValue
				+  ",  productValue=" +  productValue
				+  ",  termsOfInvoice=" +  termsOfInvoice
				+  ",  consignor=" +  consignor
				+  ",  consignorCountry=" +  consignorCountry
				+  ",  seller=" +  seller
				+  ",  sellerAddr=" +  sellerAddr
				+  ",  sellerCountry=" +  sellerCountry
				+  ",  indentor=" +  indentor
				+  ",  indentorCountry=" +  indentorCountry
				+  ",  indentorAddr=" +  indentorAddr
				+  ",  freightCurrency2=" +  freightCurrency2
				+  ",  freightBank3=" +  freightBank3
				+  ",  freightBankCert4=" +  freightBankCert4
				+  ",  freightBankCertDate5=" +  freightBankCertDate5
				+  ",  freightCurncRate6=" +  freightCurncRate6
				+  ",  freightRate7=" +  freightRate7
				+  ",  freightAmount8=" +  freightAmount8
				+  ",  insuranceCurrency9=" +  insuranceCurrency9
				+  ",  insuranceBank10=" +  insuranceBank10
				+  ",  insuranceBankCert11=" +  insuranceBankCert11
				+  ",  insuranceBankCertDate12=" +  insuranceBankCertDate12
				+  ",  insuranceCurncRate13=" +  insuranceCurncRate13
				+  ",  insuranceRate14=" +  insuranceRate14
				+  ",  insuranceBasis15=" +  insuranceBasis15
				+  ",  insuranceAmount16=" +  insuranceAmount16
				+  ",  miscCurrency17=" +  miscCurrency17
				+  ",  miscBank18=" +  miscBank18
				+  ",  miscBankCert19=" +  miscBankCert19
				+  ",  miscBankCertDate20=" +  miscBankCertDate20
				+  ",  miscCurncRate21=" +  miscCurncRate21
				+  ",  miscRate22=" +  miscRate22
				+  ",  miscBasis23=" +  miscBasis23
				+  ",  miscAmount24=" +  miscAmount24
				+  ",  agencyCurrency25=" +  agencyCurrency25
				+  ",  agencyBank26=" +  agencyBank26
				+  ",  agencyBankCert27=" +  agencyBankCert27
				+  ",  agencyBankCertDate28=" +  agencyBankCertDate28
				+  ",  agencyCurncRate=" +  agencyCurncRate
				+  ",  agencyRate29=" +  agencyRate29
				+  ",  agencyBasis30=" +  agencyBasis30
				+  ",  agencyAmount31=" +  agencyAmount31
				+  ",  loadingCurrency32=" +  loadingCurrency32
				+  ",  loadingBank33=" +  loadingBank33
				+  ",  loadingBankCert34=" +  loadingBankCert34
				+  ",  loadingBankCertDate35=" +  loadingBankCertDate35
				+  ",  loadingCurncRate36=" +  loadingCurncRate36
				+  ",  loadingRate37=" +  loadingRate37
				+  ",  loadingBasis38=" +  loadingBasis38
				+  ",  loadingAmount39=" +  loadingAmount39
				+  ",  paymentTerms=" +  paymentTerms
				+  ",  transactionType=" +  transactionType
				+  ",  saleCondition=" +  saleCondition
				+  ",  lOCNumber=" +  lOCNumber
				+  ",  lOCDate=" +  lOCDate
				+  ",  purchaseOrdNo=" +  purchaseOrdNo
				+  ",  purchaseOrdDate=" +  purchaseOrdDate
				+  ",  contractNo=" +  contractNo
				+  ",  contractDate=" +  contractDate
				+  ",  appraiserRemark=" +  appraiserRemark
				+  ",  sVBLoading=" +  sVBLoading
				+  ",  sVBRefNo=" +  sVBRefNo
				+  ",  sVBRefDate=" +  sVBRefDate
				+  ",  customsHouse=" +  customsHouse
				+  ",  sVBLoadingBasis=" +  sVBLoadingBasis
				+  ",  sVBLoadingPerAssb=" +  sVBLoadingPerAssb
				+  ",  sVBLoadingPerDuty=" +  sVBLoadingPerDuty
				+  ",  sVBLoadingStatusAssb=" +  sVBLoadingStatusAssb
				+  ",  sVBLoadingStatusDuty=" +  sVBLoadingStatusDuty
				+  ",  relation=" +  relation
				+  ",  relationBase=" +  relationBase
				+  ",  relationCondition=" +  relationCondition
				+  ",  valuationMethod=" +  valuationMethod
				+  ",  thirdParty_Name=" +  thirdParty_Name
				+  ",  thirdParty_Branch=" +  thirdParty_Branch
				+  ",  thirdParty_Address=" +  thirdParty_Address
				+  ",  thirdParty_Cntry=" +  thirdParty_Cntry
				+  ",  thirdParty_City=" +  thirdParty_City
				+  ",  thirdParty_State=" +  thirdParty_State
				+  ",  thirdParty_Pin=" +  thirdParty_Pin
				+  ",  aEO_Cntry=" +  aEO_Cntry
				+  ",  aEO_Role=" +  aEO_Role
				+  ",  aEO_Code=" +  aEO_Code
				+  ",  termsPlace=" +  termsPlace
				+  ",  discountPer=" +  discountPer
				+  ",  discountAmt=" +  discountAmt
				+  ",  discountType=" +  discountType
				+  ",  highSeaChrgPer=" +  highSeaChrgPer
				+  ",  highSeaChrgAmt=" +  highSeaChrgAmt
				+  ",  containerCostPer=" +  containerCostPer
				+  ",  containerCostAmt=" +  containerCostAmt
				+  ",  originCountryPer=" +  originCountryPer
				+  ",  originCountryAmt=" +  originCountryAmt
				+  ",  documentationPer=" +  documentationPer
				+  ",  documentationAmt=" +  documentationAmt
				+  ",  handlingCostPer=" +  handlingCostPer
				+  ",  handlingCostAmt=" +  handlingCostAmt
				+  ",  otherChrgPer=" +  otherChrgPer
				+  ",  otherChrgAmt=" +  otherChrgAmt
				+  ",  packingCostPer=" +  packingCostPer
				+  ",  packingCostAmt=" +  packingCostAmt
				+  ",  royaltyPer=" +  royaltyPer
				+  ",  royaltyAmt=" +  royaltyAmt
				+  ",  buyerServiceCostPer=" +  buyerServiceCostPer
				+  ",  buyerServiceCostAmt=" +  buyerServiceCostAmt
				+  ",  sellerObligationPer=" +  sellerObligationPer
				+  ",  sellerObligationAmt=" +  sellerObligationAmt
				+  ",  valueOfProceedsPer=" +  valueOfProceedsPer
				+  ",  valueOfProceedsAmt=" +  valueOfProceedsAmt
				+  ",  warrantyServicePer=" +  warrantyServicePer
				+  ",  warrantyServiceAmt=" +  warrantyServiceAmt
				+  ",  productDesc=" +  productDesc
				+  ",  productType=" +  productType
				+  ",  quantity=" +  quantity
				+  ",  unit=" +  unit
				+  ",  unitPrice=" +  unitPrice
				+  ",  amount=" +  amount
				+  ",  isFocItem=" +  isFocItem
				+  ",  altQuantity1=" +  altQuantity1
				+  ",  altUnit1=" +  altUnit1
				+  ",  altQuantity2=" +  altQuantity2
				+  ",  altUnit2=" +  altUnit2
				+  ",  cTHNumber=" +  cTHNumber
				+  ",  rITCNumber=" +  rITCNumber
				+  ",  iTCLocation=" +  iTCLocation
				+  ",  basicNotn=" +  basicNotn
				+  ",  basicNotnSNo=" +  basicNotnSNo
				+  ",  basicDutyPer=" +  basicDutyPer
				+  ",  basicDutyFlag=" +  basicDutyFlag
				+  ",  basicDutyQty=" +  basicDutyQty
				+  ",  basicDutyUnit=" +  basicDutyUnit
				+  ",  custHealthCessNotn=" +  custHealthCessNotn
				+  ",  custHealthCessNotnSNo=" +  custHealthCessNotnSNo
				+  ",  custHealthCessDutyPer=" +  custHealthCessDutyPer
				+  ",  custHealthCessDutyFlag=" +  custHealthCessDutyFlag
				+  ",  custHealthCessDutyQty=" +  custHealthCessDutyQty
				+  ",  custHealthCessDutyUnit=" +  custHealthCessDutyUnit
				+  ",  altBasicNotn=" +  altBasicNotn
				+  ",  altBasicNotnSNo=" +  altBasicNotnSNo
				+  ",  surchargeNotn=" +  surchargeNotn
				+  ",  surchargeNotnSNo=" +  surchargeNotnSNo
				+  ",  surchargeRate=" +  surchargeRate
				+  ",  auxillaryNotn=" +  auxillaryNotn
				+  ",  auxillaryDutyPer=" +  auxillaryDutyPer
				+  ",  antiDumpRatePer=" +  antiDumpRatePer
				+  ",  antiDumpCurrency=" +  antiDumpCurrency
				+  ",  antiDumpBank=" +  antiDumpBank
				+  ",  antiDumpBankCert=" +  antiDumpBankCert
				+  ",  antiDumpBankCertDate=" +  antiDumpBankCertDate
				+  ",  antiDumpCurncRate=" +  antiDumpCurncRate
				+  ",  antiDumpRateQty=" +  antiDumpRateQty
				+  ",  antiDumpUnit=" +  antiDumpUnit
				+  ",  antiDumpNotn=" +  antiDumpNotn
				+  ",  antiDumpSNo=" +  antiDumpSNo
				+  ",  antiDump_CTH=" +  antiDump_CTH
				+  ",  antiDump_Supplier_SNo=" +  antiDump_Supplier_SNo
				+  ",  antiDump_Qty=" +  antiDump_Qty
				+  ",  antiDump_Tariff_Notn=" +  antiDump_Tariff_Notn
				+  ",  antiDump_Tariff_SNo=" +  antiDump_Tariff_SNo
				+  ",  antiDump_Tariff_Qty=" +  antiDump_Tariff_Qty
				+  ",  antiDump_CalcMethod=" +  antiDump_CalcMethod
				+  ",  antiDump_Tariff_Amt=" +  antiDump_Tariff_Amt
				+  ",  antiDump_Tariff_Cur=" +  antiDump_Tariff_Cur
				+  ",  manufCode=" +  manufCode
				+  ",  manufAdd1=" +  manufAdd1
				+  ",  manufAdd2=" +  manufAdd2
				+  ",  sourceCntry=" +  sourceCntry
				+  ",  transitCntry=" +  transitCntry
				+  ",  manufCntry=" +  manufCntry
				+  ",  manufPostalCode=" +  manufPostalCode
				+  ",  manufState=" +  manufState
				+  ",  manufCodeType=" +  manufCodeType
				+  ",  accessoryStatus=" +  accessoryStatus
				+  ",  sWInfoReqd=" +  sWInfoReqd
				+  ",  rSP_Flag=" +  rSP_Flag
				+  ",  cVDDutyExempFlag=" +  cVDDutyExempFlag
				+  ",  antiDump_Tariff_CRate=" +  antiDump_Tariff_CRate
				+  ",  sAPTA_Notn=" +  sAPTA_Notn
				+  ",  sAPTA_SNo=" +  sAPTA_SNo
				+  ",  eDU_CESS_Notn=" +  eDU_CESS_Notn
				+  ",  eDU_CESS_SNo=" +  eDU_CESS_SNo
				+  ",  eDU_CESS_Rate=" +  eDU_CESS_Rate
				+  ",  cEX_EDU_CESS_Notn=" +  cEX_EDU_CESS_Notn
				+  ",  cEX_EDU_CESS_SNo=" +  cEX_EDU_CESS_SNo
				+  ",  eDU_CESS_Rate_Excise=" +  eDU_CESS_Rate_Excise
				+  ",  sHE_CESS_Notn=" +  sHE_CESS_Notn
				+  ",  sHE_CESS_SNo=" +  sHE_CESS_SNo
				+  ",  sHE_CESS_Rate=" +  sHE_CESS_Rate
				+  ",  sHE_CESS_Rate_Excise=" +  sHE_CESS_Rate_Excise
				+  ",  cETNumber=" +  cETNumber
				+  ",  cVDNotn=" +  cVDNotn
				+  ",  cVDNotnSNo=" +  cVDNotnSNo
				+  ",  cVDDutyPer=" +  cVDDutyPer
				+  ",  cVDDutyFlag=" +  cVDDutyFlag
				+  ",  cVDDutyQty=" +  cVDDutyQty
				+  ",  cVDDutyUnit=" +  cVDDutyUnit
				+  ",  aCVDNotn=" +  aCVDNotn
				+  ",  aCVDNotnSNo=" +  aCVDNotnSNo
				+  ",  aCVDDutyPer=" +  aCVDDutyPer
				+  ",  aCVDDutyFlag=" +  aCVDDutyFlag
				+  ",  aCVDDutyQty=" +  aCVDDutyQty
				+  ",  aCVDDutyUnit=" +  aCVDDutyUnit
				+  ",  aCS2Notn=" +  aCS2Notn
				+  ",  aCS2NotnSNo=" +  aCS2NotnSNo
				+  ",  aCS2DutyPer=" +  aCS2DutyPer
				+  ",  aCS2DutyFlag=" +  aCS2DutyFlag
				+  ",  aCS2DutyQty=" +  aCS2DutyQty
				+  ",  aCS2DutyUnit=" +  aCS2DutyUnit
				+  ",  sCVDNotn=" +  sCVDNotn
				+  ",  sCVDNotnSNo=" +  sCVDNotnSNo
				+  ",  sCVDDutyPer=" +  sCVDDutyPer
				+  ",  sCVDDutyFlag=" +  sCVDDutyFlag
				+  ",  sCVDDutyQty=" +  sCVDDutyQty
				+  ",  sCVDDutyUnit=" +  sCVDDutyUnit
				+  ",  cESSNotn=" +  cESSNotn
				+  ",  cESSNotnSNo=" +  cESSNotnSNo
				+  ",  cESSDutyPer=" +  cESSDutyPer
				+  ",  cESSDutyFlag=" +  cESSDutyFlag
				+  ",  cESSDutyQty=" +  cESSDutyQty
				+  ",  cESSDutyUnit=" +  cESSDutyUnit
				+  ",  nCDNotn=" +  nCDNotn
				+  ",  nCDNotnSNo=" +  nCDNotnSNo
				+  ",  nCDDutyPer=" +  nCDDutyPer
				+  ",  nCDDutyFlag=" +  nCDDutyFlag
				+  ",  nCDDutyQty=" +  nCDDutyQty
				+  ",  nCDDutyUnit=" +  nCDDutyUnit
				+  ",  sADNotn=" +  sADNotn
				+  ",  sADNotnSNo=" +  sADNotnSNo
				+  ",  sADDutyPer=" +  sADDutyPer
				+  ",  hLTHNotn=" +  hLTHNotn
				+  ",  hLTHNotnSNo=" +  hLTHNotnSNo
				+  ",  hLTHDutyPer=" +  hLTHDutyPer
				+  ",  hLTHDutyFlag=" +  hLTHDutyFlag
				+  ",  hLTHDutyQty=" +  hLTHDutyQty
				+  ",  hLTHDutyUnit=" +  hLTHDutyUnit
				+  ",  addlDutyNotn=" +  addlDutyNotn
				+  ",  addlDutyNotnSNo=" +  addlDutyNotnSNo
				+  ",  addlDutyPer=" +  addlDutyPer
				+  ",  aggrDutyNotn=" +  aggrDutyNotn
				+  ",  aggrDutyNotnSNo=" +  aggrDutyNotnSNo
				+  ",  aggrDutyPer=" +  aggrDutyPer
				+  ",  sGDutyNotn=" +  sGDutyNotn
				+  ",  sGDutyNotnSNo=" +  sGDutyNotnSNo
				+  ",  sGDutyPer=" +  sGDutyPer
				+  ",  iGSTNotnNo=" +  iGSTNotnNo
				+  ",  iGSTNotnSrNo=" +  iGSTNotnSrNo
				+  ",  iGSTNotnRatePer=" +  iGSTNotnRatePer
				+  ",  iGSTNotnDutyFlag=" +  iGSTNotnDutyFlag
				+  ",  iGSTNotnDutyQty=" +  iGSTNotnDutyQty
				+  ",  iGSTNotnDutyUnit=" +  iGSTNotnDutyUnit
				+  ",  gSTCESSNotnNo=" +  gSTCESSNotnNo
				+  ",  gSTCESSNotnSrNo=" +  gSTCESSNotnSrNo
				+  ",  gSTCESSNotnRatePer=" +  gSTCESSNotnRatePer
				+  ",  gSTCESSNotnDutyFlag=" +  gSTCESSNotnDutyFlag
				+  ",  gSTCESSNotnDutyQty=" +  gSTCESSNotnDutyQty
				+  ",  gSTCESSNotnDutyUnit=" +  gSTCESSNotnDutyUnit
				+  ",  iGSTExemptNotnNo=" +  iGSTExemptNotnNo
				+  ",  iGSTExemptNotnSrNo=" +  iGSTExemptNotnSrNo
				+  ",  iGSTExempNotnType=" +  iGSTExempNotnType
				+  ",  iGSTExempNotnRatePer=" +  iGSTExempNotnRatePer
				+  ",  iGSTExemptNotnDutyFlag=" +  iGSTExemptNotnDutyFlag
				+  ",  iGSTExemptNotnDutyQty=" +  iGSTExemptNotnDutyQty
				+  ",  iGSTExemptNotnDutyUnit=" +  iGSTExemptNotnDutyUnit
				+  ",  gSTCESSExemptNotnNo=" +  gSTCESSExemptNotnNo
				+  ",  gSTCESSExemptNotnSrNo=" +  gSTCESSExemptNotnSrNo
				+  ",  gSTCCESSExempNotnType=" +  gSTCCESSExempNotnType
				+  ",  gSTCCESSExempNotnRatePer=" +  gSTCCESSExempNotnRatePer
				+  ",  gSTCCESSExemptNotnDutyFlag=" +  gSTCCESSExemptNotnDutyFlag
				+  ",  gSTCCESSExemptNotnDutyQty=" +  gSTCCESSExemptNotnDutyQty
				+  ",  gSTCCESSExemptNotnDutyUnit=" +  gSTCCESSExemptNotnDutyUnit
				+  ",  rD_INFRA_CESS_Notn=" +  rD_INFRA_CESS_Notn
				+  ",  rD_INFRA_CESS_NotnSNo=" +  rD_INFRA_CESS_NotnSNo
				+  ",  rD_INFRA_CESS_DutyPer=" +  rD_INFRA_CESS_DutyPer
				+  ",  rD_INFRA_CESS_DutyFlag=" +  rD_INFRA_CESS_DutyFlag
				+  ",  rD_INFRA_CESS_DutyQty=" +  rD_INFRA_CESS_DutyQty
				+  ",  rD_INFRA_CESS_DutyUnit=" +  rD_INFRA_CESS_DutyUnit
				+  ",  sWSNotn=" +  sWSNotn
				+  ",  sWSNotnSNo=" +  sWSNotnSNo
				+  ",  sWSDutyPer=" +  sWSDutyPer
				+  ",  iTCHSCode=" +  iTCHSCode
				+  ",  policyPaara=" +  policyPaara
				+  ",  policyYear=" +  policyYear
				+  ",  loadingInPer=" +  loadingInPer
				+  ",  loadingBasis40=" +  loadingBasis40
				+  ",  loadingInQty=" +  loadingInQty
				+  ",  loadingAmount41=" +  loadingAmount41
				+  ",  sVBRefNo42=" +  sVBRefNo42
				+  ",  sVBRefDate43=" +  sVBRefDate43
				+  ",  customsHouse44=" +  customsHouse44
				+  ",  sVBLoadingBasis45=" +  sVBLoadingBasis45
				+  ",  sVBLoadingPerAssb46=" +  sVBLoadingPerAssb46
				+  ",  sVBLoadingPerDuty47=" +  sVBLoadingPerDuty47
				+  ",  sVBLoadingStatusAssb48=" +  sVBLoadingStatusAssb48
				+  ",  sVBLoadingStatusDuty49=" +  sVBLoadingStatusDuty49
				+  ",  genericDesc=" +  genericDesc
				+  ",  accessory=" +  accessory
				+  ",  manufacturer=" +  manufacturer
				+  ",  brand=" +  brand
				+  ",  model=" +  model
				+  ",  endUse=" +  endUse
				+  ",  countryOfOrigin50=" +  countryOfOrigin50
				+  ",  mRPSNo=" +  mRPSNo
				+  ",  mRP=" +  mRP
				+  ",  mRPUnit=" +  mRPUnit
				+  ",  abatement=" +  abatement
				+  ",  eXIMCode=" +  eXIMCode
				+  ",  schemeNotn=" +  schemeNotn
				+  ",  schemeNotnSNo=" +  schemeNotnSNo
				+  ",  prevImpBENo=" +  prevImpBENo
				+  ",  prevImpBEDate=" +  prevImpBEDate
				+  ",  prevImpCurrency=" +  prevImpCurrency
				+  ",  prevImpValue=" +  prevImpValue
				+  ",  prevImpCustomHouse=" +  prevImpCustomHouse
				+  ",  materialCode=" +  materialCode
				+  ",  dutyRateType=" +  dutyRateType
				+  ",  rSPNotn=" +  rSPNotn
				+  ",  rSPNotnSNo=" +  rSPNotnSNo
				+  ",  reImportDtls=" +  reImportDtls
				+  ",  infoType=" +  infoType
				+  ",  infoQualifier=" +  infoQualifier
				+  ",  infoCode=" +  infoCode
				+  ",  infoText=" +  infoText
				+  ",  infoMeasure=" +  infoMeasure
				+  ",  infoMeasUnit=" +  infoMeasUnit
				+  ",  impProdConsts=" +  impProdConsts
				+  ",  impProdBatches=" +  impProdBatches
				+  ",  impProdControls=" +  impProdControls
				+  ",  licNo=" +  licNo
				+  ",  licDate=" +  licDate
				+  ",  debitValue=" +  debitValue
				+  ",  quantity51=" +  quantity51
				+  ",  documentNo=" +  documentNo
				+  ",  releaseAdvNo=" +  releaseAdvNo
				+  ",  releaseAdvDate=" +  releaseAdvDate
				+  ",  registeredPort=" +  registeredPort
				+  ",  prodAmtRs=" +  prodAmtRs
				+  ",  freight=" +  freight
				+  ",  insurance=" +  insurance
				+  ",  commission=" +  commission
				+  ",  miscellaneous=" +  miscellaneous
				+  ",  cIFValue=" +  cIFValue
				+  ",  assessableValue=" +  assessableValue
				+  ",  totalBasicDutyAmt=" +  totalBasicDutyAmt
				+  ",  totalCVDAmt=" +  totalCVDAmt
				+  ",  totalDutyAmt=" +  totalDutyAmt
 
				+ "]";
	}

}
