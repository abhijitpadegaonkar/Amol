package com.ap.demo.respository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.ap.demo.model.Bill;
import com.ap.demo.model.BoE;
import com.ap.demo.model.Purchase;
import com.ap.demo.model.Item;

@Repository
public class BoERepositoryImpl implements BoERepository {

	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	private static String INSERT1 = "INSERT INTO purchase_master (username,comp_iec,type_of_purchase,part_number,part_desc,uom,pur_batch_number,grr_qty,grr_no,pur_inv_no,pur_inv_date,in_bond_boe_num,in_bond_boe_date,port_of_import,bottle_seal_number,insurance_details,per_unit_cost,total_pur_value,duty_bcd_rate,duty_bcd_amt,duty_cess_bcd_amt,duty_cess_bcd_rate,duty_gst_rate,duty_gst_amt,duty_cess_gst_rate,duty_cess_gst_amt,duty_other_rate,duty_other_amt,total_custom_duty,total_gst,vehicle_reg_num,warehouse_date,eway_bill_num,eway_bill_date,created_date,updated_date) "
			+ "VALUES (:username,:comp_iec,:type_of_purchase,:part_number,:part_desc,:uom,:pur_batch_number,:grr_qty,:grr_no,:pur_inv_no,:pur_inv_date,:in_bond_boe_num,:in_bond_boe_date,:port_of_import,:bottle_seal_number,:insurance_details,:per_unit_cost,:total_pur_value,:duty_bcd_rate,:duty_bcd_amt,:duty_cess_bcd_amt,:duty_cess_bcd_rate,:duty_gst_rate,:duty_gst_amt,:duty_cess_gst_rate,:duty_cess_gst_amt,:duty_other_rate,:duty_other_amt,:total_custom_duty,:total_gst,:vehicle_reg_num,:warehouse_date,:eway_bill_num,:eway_bill_date,NOW(),NOW())";
	
	private static String INSERT = "INSERT INTO purchase_master (username,comp_iec,type_of_purchase,part_number,part_desc,uom,pur_batch_number,grr_qty,grr_no,pur_inv_no,pur_inv_date,in_bond_boe_num,in_bond_boe_date,port_of_import,bottle_seal_number,insurance_details,per_unit_cost,total_pur_value,duty_bcd_rate,duty_bcd_amt,duty_cess_bcd_amt,duty_cess_bcd_rate,duty_gst_rate,duty_gst_amt,duty_cess_gst_rate,duty_cess_gst_amt,duty_other_rate,duty_other_amt,total_custom_duty,total_gst,vehicle_reg_num,warehouse_date,eway_bill_num,eway_bill_date,hsn_number,balance_duty,exbond_memo_duty,waived_off_duty,duty_paid_amount,available_qty,used_qty,created_date,updated_date) "
			+ "VALUES (:username,:comp_iec,:type_of_purchase,:part_number,:part_desc,:uom,:pur_batch_number,:grr_qty,:grr_no,:pur_inv_no,:pur_inv_date,:in_bond_boe_num,:in_bond_boe_date,:port_of_import,:bottle_seal_number,:insurance_details,:per_unit_cost,:total_pur_value,:duty_bcd_rate,:duty_bcd_amt,:duty_cess_bcd_amt,:duty_cess_bcd_rate,:duty_gst_rate,:duty_gst_amt,:duty_cess_gst_rate,:duty_cess_gst_amt,:duty_other_rate,:duty_other_amt,:total_custom_duty,:total_gst,:vehicle_reg_num,:warehouse_date,:eway_bill_num,:eway_bill_date,:hsn_number,:balance_duty,0,0,0,:grr_qty,0,NOW(),NOW())";

	private static String UPDATE = "UPDATE purchase_master SET " 
			+ "comp_iec = :comp_iec, "
			+ "type_of_purchase = :type_of_purchase, " 
			+ "part_desc = :part_desc, "
			+ "uom = :uom, "
			+ "pur_batch_number = :pur_batch_number, "
			+ "grr_qty = :grr_qty, "
			+ "grr_no = :grr_no, "
			+ "pur_inv_no = :pur_inv_no, "
			+ "pur_inv_date = :pur_inv_date, "
			+ "in_bond_boe_num = :in_bond_boe_num, "
			+ "in_bond_boe_date = :in_bond_boe_date, "
			+ "port_of_import = :port_of_import, "
			+ "bottle_seal_number = :bottle_seal_number, "
			+ "insurance_details = :insurance_details, "
			+ "per_unit_cost = :per_unit_cost, "
			+ "total_pur_value = :total_pur_value, "
			+ "duty_bcd_rate = :duty_bcd_rate, "
			+ "duty_bcd_amt = :duty_bcd_amt, "
			+ "duty_cess_bcd_amt = :duty_cess_bcd_amt, "
			+ "duty_cess_bcd_rate = :duty_cess_bcd_rate, "
			+ "duty_gst_rate = :duty_gst_rate, "
			+ "duty_gst_amt = :duty_gst_amt, "
			+ "duty_cess_gst_rate = :duty_cess_gst_rate, "
			+ "duty_cess_gst_amt = :duty_cess_gst_amt, "
			+ "duty_other_rate = :duty_other_rate, "
			+ "duty_other_amt = :duty_other_amt, "
			+ "total_custom_duty = :total_custom_duty, "
			+ "total_gst = :total_gst, "
			+ "vehicle_reg_num = :vehicle_reg_num, "
			+ "warehouse_date = :warehouse_date, "
			+ "eway_bill_num = :eway_bill_num, "
			+ "eway_bill_date = :eway_bill_date, "
			+ "hsn_number = :hsn_number, "
			+ "updated_date = NOW() " 
			+ "WHERE id = :id";

	private static String SELECT = "SELECT * FROM purchase_master";
	private static String DELETE = "DELETE FROM purchase_master WHERE id = :id";

//	@Override
//	public Purchase findById(Long purchaseId) {
//		return (Purchase) namedParameterJdbcTemplate.queryForObject("select * from purchase_master where id = :id",
//				new MapSqlParameterSource("id", purchaseId), (rs, rowNum) -> purchaseMapper);

//	}

//	@Override
//	public boolean delete(Long purchaseId) {
//		SqlParameterSource namedParameters = new MapSqlParameterSource("id", purchaseId);
//		int status = namedParameterJdbcTemplate.update(DELETE, namedParameters);
//		return status != 0;
//	}

//	@Override
	public long save(BoE boe) {

		Map<String, Object> params = new HashMap<String, Object>();

		params.put("username", boe.getUsername());
		params.put("comp_iec", boe.getCompIec());
			
		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource(params);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		namedParameterJdbcTemplate.update(INSERT, sqlParameterSource, keyHolder);
		return keyHolder.getKey().longValue();
	}

//	@Override
//	public boolean update(Purchase purchase) {

//		Map<String, Object> params = new HashMap<String, Object>();
//		params.put("id", purchase.getId());
//		//params.put("username", purchase.getUsername());
//		params.put("comp_iec", purchase.getCompIec());
//		params.put("part_desc", purchase.getPartDesc());
//		//params.put("part_number", purchase.getPartNumber());
//		params.put("type_of_purchase", purchase.getTypeOfPurchase());
//		params.put("uom", purchase.getUom());

//		MapSqlParameterSource sqlParameterSource = new MapSqlParameterSource(params);
//		long updateCount = namedParameterJdbcTemplate.update(UPDATE, sqlParameterSource);
//		return updateCount != 0;
//	}

	@Override
	public List<BoE> findAll() {
		return namedParameterJdbcTemplate.query(SELECT, boeMapper);
	}

	private RowMapper<BoE> boeMapper = new RowMapper<BoE>() {

		@Override
		public BoE mapRow(ResultSet rs, int num) throws SQLException {
			BoE boe = new BoE();
			boe.setId(rs.getLong("id"));
			boe.setUsername(rs.getString("username"));
			boe.setCompIec(rs.getString("comp_iec"));
			
			return boe;
		}

	};

//	@Override
//	public boolean isPurchasePresent(Purchase purchase) {
//		int count = (int) namedParameterJdbcTemplate.queryForObject("SELECT COUNT(*) FROM purchase_master WHERE pur_batch_number = :pur_batch_number",
//				new MapSqlParameterSource("pur_batch_number", purchase.getPurBatchNumber()), Integer.class);
//		
//		return (count > 0) ? true : false;
//	}
	
}