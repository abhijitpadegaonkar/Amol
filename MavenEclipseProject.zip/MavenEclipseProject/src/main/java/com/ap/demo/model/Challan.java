package com.ap.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "challan_master")
public class Challan {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "comp_iec")
	private String compIec;

	@Column(name = "sale_batch_number")
	private String saleBatchNumber;

	@Column(name = "prod_batch_number")
	private String prodBatchNumber;
	
	@Column(name = "username")
	private String username;
	
	@Column(name = "challan_number")
	private String challanNumber;

	@Column(name = "challan_date")
	private String challanDate;

	@Column(name = "challan_amount")
	private String challanAmount;

	@Column(name = "created_date")
	private String createdDate;

	@Column(name = "updated_date")
	private String updateDate;

	public Challan() {
		super();
	}

	public Challan(String compIec, String saleBatchNumber, String challanNumber, String challanDate,
			String challanAmount, String username, String prodBatchNumber) {
		super();
		this.compIec = compIec;
		this.saleBatchNumber = saleBatchNumber;
		this.challanNumber = challanNumber;
		this.challanDate = challanDate;
		this.challanAmount = challanAmount;
		this.username = username;
		this.prodBatchNumber = prodBatchNumber;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCompIec() {
		return compIec;
	}

	public void setCompIec(String compIec) {
		this.compIec = compIec;
	}

	public String getSalesBatchNumber() {
		return saleBatchNumber;
	}

	public void setSalesBatchNumber(String saleBatchNumber) {
		this.saleBatchNumber = saleBatchNumber;
	}

	public String getChallanNumber() {
		return challanNumber;
	}

	public void setChallanNumber(String challanNumber) {
		this.challanNumber = challanNumber;
	}

	public String getChallanDate() {
		return challanDate;
	}

	public void setChallanDate(String challanDate) {
		this.challanDate = challanDate;
	}

	public String getChallanAmount() {
		return challanAmount;
	}

	public void setChallanAmount(String challanAmount) {
		this.challanAmount = challanAmount;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getProdBatchNumber() {
		return prodBatchNumber;
	}

	public void setProdBatchNumber(String prodBatchNumber) {
		this.prodBatchNumber = prodBatchNumber;
	}
	
	public String getusername() {
		return username;
	}

	public void setusername(String username) {
		this.username = username;
	}
	
	@Override
	public String toString() {
		return "Challan [id=" + id + ", compIec=" + compIec + ", saleBatchNumber=" + saleBatchNumber + ", challanNumber="
				+ challanNumber + ", challanDate=" + challanDate + ", challanAmount=" + challanAmount + ", createdDate="
				+ createdDate + ", updateDate=" + updateDate + ", username=" +username 
				+ ", prodBatchNumber" + prodBatchNumber + "]";
	}

}
