$(document).ready(function() {
	
	var table = $('#saleTable').DataTable({
		"sAjaxSource" : "/sales",
		"sAjaxDataProp" : "",
		"lengthChange" : false,
		"aoColumns" : [{
			"mData" : "username",
		}, {
			"mData" : "compIec",
		}, {
			"mData" : "partNumber"
		}, {
			"mData" : "partDesc"
		}, {
			"mData" : "uom",
			"class" : "text-right"
		},/* {
			"mData" : "createdDate"
		}, {
			"mData" : "updateDate"
		},*/ {
			"bSortable": false,
			"class" : "text-center",
		    "mRender": function(data, type, row) {
		    	var actionMarkup = '<a href="#" class="btn btn-primary btn-circle btn-sm view-sale"><i class="fa fa-file" title="View"></i></a>'
		    		//+ '&nbsp;<a href="#" class="btn btn-info btn-circle btn-sm edit-sale"><i class="fa fa-edit" title="Edit" data-toggle="modal" data-target="#updateSaleModal"></i></a>'
		    		+ '&nbsp;<a href="#" class="btn btn-danger btn-circle btn-sm remove-sale"><i class="fa fa-trash" title="Delete Permanantly"></i></a>';
		    		
		    	return actionMarkup;
		    	
		    }
		 }]
	});
	
	// Action - view
	$('#saleTable tbody').on( 'click', '.view-sale', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
	    $.dialog({
	    	columnClass: 'col-md-12',
	        title: 'Sale Details',
			//username, compIec, partNumber, typeOfPurchase, partDesc, uom, createdDate, updateDate

	        content: '<div class="table-responsive">' +
	        '<table class="table table-bordered table-hover table-striped table-sm c-view-table sale-details ">' +
	        '<tr> <th class="col-md-4">Fields</th> <th class="col-md-8">Details</th> </tr>' +
	        '<tr> <td>Part Number</td> <td>' + rowData.partNumber + '</td> </tr>' +
	        '<tr> <td>Part Description</td> <td>' + rowData.partDesc + '</td> </tr>' +
	        '<tr> <td>Unit of Measurement</td> <td>' + rowData.uom + '</td> </tr>' +
	        '<tr> <td>Username</td> <td>' + rowData.username + '</td> </tr>' +
	        '<tr> <td>Company IEC</td> <td>' + rowData.compIec + '</td> </tr>' +
	        '<tr> <td>Type of Sale</td> <td>' + rowData.typeOfSale + '</td> </tr>' +
	        '<tr> <td>Quantity</td> <td>' + rowData.quantity + '</td> </tr>' +
	        '<tr> <td>HSN No</td> <td>' + rowData.hsnNo + '</td> </tr>' +
	        '<tr> <td>Temp Invoice Number</td> <td>' + rowData.tempInvoiceNumber + '</td> </tr>' +
	        '<tr> <td>Temp Invoice Date</td> <td>' + rowData.tempInvoiceDate + '</td> </tr>' +
	        '<tr> <td>GST invoice number</td> <td>' + rowData.gstInvoiceNumber + '</td> </tr>' +
	        '<tr> <td>GST Invoice date</td> <td>' + rowData.gstInvoiceDate + '</td> </tr>' +
	        '<tr> <td>SHB Number</td> <td>' + rowData.shbNumber + '</td> </tr>' +
	        '<tr> <td>SHB Date</td> <td>' + rowData.shbDate + '</td> </tr>' +
	        '<tr> <td>Port of Export</td> <td>' + rowData.portOfExport + '</td> </tr>' +
	        '<tr> <td>Details of Insurance</td> <td>' + rowData.detailsOfInsurance + '</td> </tr>' +
	        '<tr> <td>Per unit assessible value</td> <td>' + rowData.perUnitAssessibleValue + '</td> </tr>' +
	        '<tr> <td>Assessible Value</td> <td>' + rowData.assessibleValue + '</td> </tr>' +
	        '<tr> <td>Duty GST</td> <td>' + rowData.dutyGst + '</td> </tr>' +
	        '<tr> <td>Duty Cess on GST</td> <td>' + rowData.dutyCessOnGst + '</td> </tr>' +
	        '<tr> <td>Registration Number of means of Transport</td> <td>' + rowData.vehicleRegNumber + '</td> </tr>' +
	        '<tr> <td>One time lock number</td> <td>' + rowData.oneTimeLockNumber + '</td> </tr>' +
	        '<tr> <td>Date of removal of goods from warehouse</td> <td>' + rowData.goodsRemovalDate + '</td> </tr>' +
	        '<tr> <td>Time of removal of goods from warehouse</td> <td>' + rowData.goodsRemovalTime + '</td> </tr>' +
	        '<tr> <td>Eway Bill Number</td> <td>' + rowData.ewayBillNumber + '</td> </tr>' +
	        '<tr> <td>Eway Bill Date</td> <td>' + rowData.ewayBillDate + '</td> </tr>' +
	        '<tr> <td>Remarks</td> <td>' + rowData.remark + '</td> </tr>' +
	        '<tr> <td>Purchaser Batch Number</td> <td>' + rowData.purBatchNumber + '</td> </tr>' +
	        '<tr> <td>Production Batch Number</td> <td>' + rowData.prodBatchNumber + '</td> </tr>' +
	        '<tr> <td>Created Date</td> <td>' + rowData.createdDate + '</td> </tr>' +
	        '<tr> <td>Updated Date</td> <td>' + rowData.updateDate + '</td> </tr>' +
	        '</table></div>',
	    });
	});
	
	// Action - edit
	$('#saleTable tbody').on( 'click', '.edit-sale', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$("#updateSaleModal #username").val(rowData.username);
		$("#updateSaleModal #compIec").val(rowData.compIec);
		$("#updateSaleModal #partNumber").val(rowData.partNumber);
		$("#updateSaleModal #typeOfPurchase").val(rowData.typeOfPurchase);
		$("#updateSaleModal #partDesc").val(rowData.partDesc);
		$("#updateSaleModal #uom").val(rowData.uom);
		//$("#updateSaleModal #createdDate").val(rowData.createdDate);
		//$("#updateSaleModal #updateDate").val(rowData.updateDate);
		$("#updateSaleModal #id").val(rowData.id);
	});
	
	// Action - update save
	$('body').on( 'click', '#updateSaleBtn', function () {
		
		// Extract form data
		var saleId = $("#updateSaleModal #id").val();
		var username = $("#updateSaleModal #username").val();
		var compIec = $("#updateSaleModal #compIec").val();
		var partNumber = $("#updateSaleModal #partNumber").val();
		var typeOfPurchase = $("#updateSaleModal #typeOfPurchase").val();
		var partDesc = $("#updateSaleModal #partDesc").val();
		var uom = $("#updateSaleModal #uom").val();
		//var createdDate = $("#updateSaleModal #createdDate").val();
		//var updateDate = $("#updateSaleModal #updateDate").val();
		
		console.log( username
				+ ' --- ' + compIec
				+ ' --- ' + partNumber
				+ ' --- ' + typeOfPurchase
				+ ' --- ' + partDesc
				+ ' --- ' + uom
				//+ ' --- ' + createdDate
				//+ ' --- ' + updateDate
		);
		
		$.ajax({
			method: "POST",
			url: "update-sale",
			data: { 
				//id : saleId,
				username : username,
				compIec : compIec,
				partNumber : partNumber,
				partDesc : partDesc,
				uom : uom,
				//createdDate : createdDate,
				//updateDate : updateDate
			}
		})
		.done(function( msg ) {
			$.dialog('Sale updated successfully');
		})
		.fail(function() {
			$.dialog('Failed to update sale');
		})
		.always(function() {
			table.ajax.reload();
			$('#updateSaleModal').modal('hide');
		});
	});
	
	// Action - delete
	$('#saleTable tbody').on( 'click', '.remove-sale', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Delete sale: ' + rowData.partNumber,
			buttons: {
				confirm: function () {
					$.post("remove-sale", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
}); // END OF READY