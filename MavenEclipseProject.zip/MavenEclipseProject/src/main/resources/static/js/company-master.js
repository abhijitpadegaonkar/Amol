$(document).ready(function() {
	
	var table = $('#userTable').DataTable({
		"sAjaxSource" : "/companies",
		"sAjaxDataProp" : "",
		"lengthChange" : false,
		"aoColumns" : [{
			"mData" : "username",
		}, {
			"mData" : "compName",
		}, {
			"mData" : "compEmailId"
		}, {
			"mData" : "compUrl"
		},/* {
			"mData" : "compIec"
		}, {
			"mData" : "compPan"
		}, {
			"mData" : "compTin"
		}, {
			"mData" : "compIncorporationNumber"
		}, {
			"mData" : "compType"
		}, {
			"mData" : "industryType"
		}, {
			"mData" : "addrLine1"
		}, {
			"mData" : "addrLine2"
		}, {
			"mData" : "addrLine3"
		}, {
			"mData" : "city"
		}, {
			"mData" : "state"
		}, {
			"mData" : "country"
		}, {
			"mData" : "pinCode"
		}, {
			"mData" : "prodSiteAddr"
		}, {
			"mData" : "contPersonName"
		}, {
			"mData" : "contPersonEmail"
		}, {
			"mData" : "contPersonPhone"
		}, {
			"mData" : "moowrNumber"
		}, {
			"mData" : "gstProductionPlant"
		},*/ {
		    "mRender": function(data, type, row) {
		    	return (row.active) ? "Active" : "Disabled";
		    }
		}, {
			"bSortable": false,
			"class" : "text-center",
		    "mRender": function(data, type, row) {
		    	var actionMarkup = '<a href="#" class="btn btn-primary btn-circle btn-sm view-company"><i class="fa fa-file" title="View"></i></a>';
		    		//+ '&nbsp;<a href="#" class="btn btn-info btn-circle btn-sm edit-company"><i class="fa fa-edit" title="Edit" data-toggle="modal" data-target="#updateCompanyModal"></i></a>';
		    	
		    	if(row.active){
		    		actionMarkup += '&nbsp;<a href="#" class="btn btn-warning btn-circle btn-sm disable-company"><i class="fa fa-ban" title="Disable"></i></a>';
		    	} else {
		    		actionMarkup += '&nbsp;<a href="#" class="btn btn-warning btn-circle btn-sm enable-company"><i class="fa fa-check" title="Enable"></i></a>';
		    	}
		    	
		    	actionMarkup += '&nbsp;<a href="#" class="btn btn-danger btn-circle btn-sm remove-company"><i class="fa fa-trash" title="Delete Permanantly"></i></a>';
		    		
		    	return actionMarkup;
		    	
		    }
		 }]
	});
	
	// Action - view
	$('#userTable tbody').on( 'click', '.view-company', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
	    $.dialog({
	    	columnClass: 'col-md-12',
	        title: 'Company Details',
	        content: '<div class="table-responsive">' +
	        '<table class="table table-bordered table-hover table-striped table-sm c-view-table company-details ">' +
	        '<tr> <th class="col-md-4">Fields</th> <th class="col-md-8">Details</th> </tr>' +
	        '<tr> <td>Username</td> <td>' + rowData.username + '</td> </tr>' +
	        '<tr> <td>Company Name</td> <td>' + rowData.compName + '</td> </tr>' +
	        '<tr> <td>Company Email</td> <td>' + rowData.compEmailId + '</td> </tr>' +
	        '<tr> <td>Company URL</td> <td>' + rowData.compUrl + '</td> </tr>' +
	        '<tr> <td>Company IEC</td> <td>' + rowData.compIec + '</td> </tr>' +
	        '<tr> <td>Company PAN</td> <td>' + rowData.compPan + '</td> </tr>' +
	        '<tr> <td>Company TIN</td> <td>' + rowData.compTin + '</td> </tr>' +
	        '<tr> <td>Company Incorporation Number</td> <td>' + rowData.compIncorporationNumber + '</td> </tr>' +
	        '<tr> <td>Company Type</td> <td>' + rowData.compType + '</td> </tr>' +
	        '<tr> <td>Industry Type</td> <td>' + rowData.industryType + '</td> </tr>' +
	        '<tr> <td>Address Line 1</td> <td>' + rowData.addrLine1 + '</td> </tr>' +
	        '<tr> <td>Address Line 2</td> <td>' + rowData.addrLine2 + '</td> </tr>' +
	        '<tr> <td>Address Line 3</td> <td>' + rowData.addrLine3 + '</td> </tr>' +
	        '<tr> <td>City</td> <td>' + rowData.city + '</td> </tr>' +
	        '<tr> <td>State</td> <td>' + rowData.state + '</td> </tr>' +
	        '<tr> <td>Country</td> <td>' + rowData.country + '</td> </tr>' +
	        '<tr> <td>PIN Code</td> <td>' + rowData.pinCode + '</td> </tr>' +
	        '<tr> <td>Production Site Address</td> <td>' + rowData.prodSiteAddr + '</td> </tr>' +
	        '<tr> <td>Contact Person Name</td> <td>' + rowData.contPersonName + '</td> </tr>' +
	        '<tr> <td>Contact Person Email</td> <td>' + rowData.contPersonEmail + '</td> </tr>' +
	        '<tr> <td>Contact Person Phone</td> <td>' + rowData.contPersonPhone + '</td> </tr>' +
	        '<tr> <td>Moowr Number</td> <td>' + rowData.moowrNumber + '</td> </tr>' +
	        '<tr> <td>GST Production Plant</td> <td>' + rowData.gstProductionPlant + '</td> </tr>' +
	        '<tr> <td>HSN</td> <td>' + rowData.hsnNumber + '</td> </tr>' +
	        '<tr> <td>Status</td> <td>' + ((rowData.active) ? "Active" : "Disabled") + '</td> </tr>' +
	        '</table></div>',
	    });
	});
	
	// Action - edit
	$('#userTable tbody').on( 'click', '.edit-company', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		
		$("#updateCompanyModal #username").val(rowData.username);
		$("#updateCompanyModal #compName").val(rowData.compName);
		$("#updateCompanyModal #compEmailId").val(rowData.compEmailId);
		$("#updateCompanyModal #compUrl").val(rowData.compUrl);
		$("#updateCompanyModal #compIec").val(rowData.compIec);
		$("#updateCompanyModal #compPan").val(rowData.compPan);
		$("#updateCompanyModal #compTin").val(rowData.compTin);
		$("#updateCompanyModal #compIncorporationNumber").val(rowData.compIncorporationNumber);
		$("#updateCompanyModal #compType").val(rowData.compType);
		$("#updateCompanyModal #industryType").val(rowData.industryType);
		$("#updateCompanyModal #addrLine1").val(rowData.addrLine1);
		$("#updateCompanyModal #addrLine2").val(rowData.addrLine2);
		$("#updateCompanyModal #addrLine3").val(rowData.addrLine3);
		$("#updateCompanyModal #city").val(rowData.city);
		$("#updateCompanyModal #state").val(rowData.state);
		$("#updateCompanyModal #country").val(rowData.country);
		$("#updateCompanyModal #pinCode").val(rowData.pinCode);
		$("#updateCompanyModal #prodSiteAddr").val(rowData.prodSiteAddr);
		$("#updateCompanyModal #contPersonName").val(rowData.contPersonName);
		$("#updateCompanyModal #contPersonEmail").val(rowData.contPersonEmail);
		$("#updateCompanyModal #contPersonPhone").val(rowData.contPersonPhone);
		$("#updateCompanyModal #moowrNumber").val(rowData.moowrNumber);
		$("#updateCompanyModal #gstProductionPlant").val(rowData.gstProductionPlant);
		$("#updateCompanyModal #id").val(rowData.id);
	});
	
	// Action - update save
	$('body').on( 'click', '#updateCompanyBtn', function () {
		
		// Extract form data
		var companyId = $("#updateCompanyModal #id").val();
		var username = $("#updateCompanyModal #username").val();
		var compName = $("#updateCompanyModal #compName").val();
		var compEmailId = $("#updateCompanyModal #compEmailId").val();
		var compUrl = $("#updateCompanyModal #compUrl").val();
		var compIec = $("#updateCompanyModal #compIec").val();
		var compPan = $("#updateCompanyModal #compPan").val();
		var compTin = $("#updateCompanyModal #compTin").val();
		var compIncorporationNumber = $("#updateCompanyModal #compIncorporationNumber").val();
		var compType = $("#updateCompanyModal #compType").val();
		var industryType = $("#updateCompanyModal #industryType").val();
		var addrLine1 = $("#updateCompanyModal #addrLine1").val();
		var addrLine2 = $("#updateCompanyModal #addrLine2").val();
		var addrLine3 = $("#updateCompanyModal #addrLine3").val();
		var city = $("#updateCompanyModal #city").val();
		var state = $("#updateCompanyModal #state").val();
		var country = $("#updateCompanyModal #country").val();
		var pinCode = $("#updateCompanyModal #pinCode").val();
		var prodSiteAddr = $("#updateCompanyModal #prodSiteAddr").val();
		var contPersonName = $("#updateCompanyModal #contPersonName").val();
		var contPersonEmail = $("#updateCompanyModal #contPersonEmail").val();
		var contPersonPhone = $("#updateCompanyModal #contPersonPhone").val();
		var moowrNumber = $("#updateCompanyModal #moowrNumber").val();
		var gstProductionPlant= $("#updateCompanyModal #gstProductionPlant").val();
		
		console.log( username
				+ ' --- ' + compName
				+ ' --- ' + compEmailId
				+ ' --- ' + compUrl
				+ ' --- ' + compIec
				+ ' --- ' + compPan
				+ ' --- ' + compTin
				+ ' --- ' + compIncorporationNumber
				+ ' --- ' + compType
				+ ' --- ' + industryType
				+ ' --- ' + addrLine1
				+ ' --- ' + addrLine2
				+ ' --- ' + addrLine3
				+ ' --- ' + city
				+ ' --- ' + state
				+ ' --- ' + country
				+ ' --- ' + pinCode
				+ ' --- ' + prodSiteAddr
				+ ' --- ' + contPersonName
				+ ' --- ' + contPersonEmail
				+ ' --- ' + contPersonPhone
				+ ' --- ' + moowrNumber
				+ ' --- ' + gstProductionPlant
		
		);
		
		$.ajax({
			method: "POST",
			url: "update-company",
			data: { 
				id : companyId,
				username : username,
				compName : compName,
				compEmailId : compEmailId,
				compUrl : compUrl,
				compIec : compIec,
				compPan : compPan,
				compTin : compTin,
				compIncorporationNumber : compIncorporationNumber,
				compType : compType,
				industryType : industryType,
				addrLine1 : addrLine1,
				addrLine2 : addrLine2,
				addrLine3 : addrLine3,
				city : city,
				state : state,
				country : country,
				pinCode : pinCode,
				prodSiteAddr : prodSiteAddr,
				contPersonName : contPersonName,
				contPersonEmail : contPersonEmail,
				contPersonPhone : contPersonPhone,
				moowrNumber : moowrNumber,
				gstProductionPlant : gstProductionPlant
			}
		})
		.done(function( msg ) {
			$.dialog('Company updated successfully');
		})
		.fail(function() {
			$.dialog('Failed to update company');
		})
		.always(function() {
			table.ajax.reload();
			$('#updateCompanyModal').modal('hide');
		});
	});
	
	// Action - enable
	$('#userTable tbody').on( 'click', '.enable-company', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Enable company: ' + rowData.compName,
			buttons: {
				confirm: function () {
					$.post("enable-company", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
	// Action
	$('#userTable tbody').on( 'click', '.disable-company', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Disable company: ' + rowData.compName,
			buttons: {
				confirm: function () {
					$.post("disable-company", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
	// Action - delete
	$('#userTable tbody').on( 'click', '.remove-company', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Delete company: ' + rowData.compName,
			buttons: {
				confirm: function () {
					$.post("remove-company", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
}); // END OF READY