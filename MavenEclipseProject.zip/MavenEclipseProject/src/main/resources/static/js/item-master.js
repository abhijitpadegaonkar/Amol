$(document).ready(function() {
	
	var table = $('#itemTable').DataTable({
		"sAjaxSource" : "/items",
		"sAjaxDataProp" : "",
		"lengthChange" : false,
		"aoColumns" : [{
			"mData" : "username",
		}, {
			"mData" : "compIec",
		}, {
			"mData" : "typeOfPurchase"
		}, {
			"mData" : "partNumber"
		}, {
			"mData" : "partDesc"
		}, {
			"mData" : "uom"
		}, {
			"mData" : "hsnNumber"
		},/* {
			"mData" : "createdDate"
		}, {
			"mData" : "updateDate"
		},*/ {
			"bSortable": false,
			"class" : "text-center",
		    "mRender": function(data, type, row) {
		    	var actionMarkup = '<a href="#" class="btn btn-primary btn-circle btn-sm view-item"><i class="fa fa-file" title="View"></i></a>'
		    		//+ '&nbsp;<a href="#" class="btn btn-info btn-circle btn-sm edit-item"><i class="fa fa-edit" title="Edit" data-toggle="modal" data-target="#updateItemModal"></i></a>'
		    		+ '&nbsp;<a href="#" class="btn btn-danger btn-circle btn-sm remove-item"><i class="fa fa-trash" title="Delete Permanantly"></i></a>';
		    		
		    	return actionMarkup;
		    	
		    }
		 }]
	});
	
	// Action - view
	$('#itemTable tbody').on( 'click', '.view-item', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
	    $.dialog({
	    	columnClass: 'col-md-12',
	        title: 'Item Details',
			//username, compIec, partNumber, typeOfPurchase, partDesc, uom, createdDate, updateDate

	        content: '<div class="table-responsive">' +
	        '<table class="table table-bordered table-hover table-striped table-sm c-view-table item-details ">' +
	        '<tr> <th class="col-md-4">Fields</th> <th class="col-md-8">Details</th> </tr>' +
	        '<tr> <td>Part Number</td> <td>' + rowData.partNumber + '</td> </tr>' +
	        '<tr> <td>Part Description</td> <td>' + rowData.partDesc + '</td> </tr>' +
	        '<tr> <td>Type Of Purchase</td> <td>' + rowData.typeOfPurchase + '</td> </tr>' +
	        '<tr> <td>UOM</td> <td>' + rowData.uom + '</td> </tr>' +
	        '<tr> <td>HSN Number</td> <td>' + rowData.hsnNumber + '</td> </tr>' +
	        '<tr> <td>Username</td> <td>' + rowData.username + '</td> </tr>' +
	        '<tr> <td>Company IEC</td> <td>' + rowData.compIec + '</td> </tr>' +
	        '<tr> <td>Created Date</td> <td>' + rowData.createdDate + '</td> </tr>' +
	        '<tr> <td>Updated Date</td> <td>' + rowData.updateDate + '</td> </tr>' +
	        '</table></div>',
	    });
	});
	
	// Action - edit
	$('#itemTable tbody').on( 'click', '.edit-item', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$("#updateItemModal #username").val(rowData.username);
		$("#updateItemModal #compIec").val(rowData.compIec);
		$("#updateItemModal #partNumber").val(rowData.partNumber);
		$("#updateItemModal #typeOfPurchase").val(rowData.typeOfPurchase);
		$("#updateItemModal #partDesc").val(rowData.partDesc);
		$("#updateItemModal #uom").val(rowData.uom);
		$("#updateItemModal #hsnNumber").val(rowData.hsnNumber);
		//$("#updateItemModal #createdDate").val(rowData.createdDate);
		//$("#updateItemModal #updateDate").val(rowData.updateDate);
		$("#updateItemModal #id").val(rowData.id);
	});
	
	// Action - update save
	$('body').on( 'click', '#updateItemBtn', function () {
		
		// Extract form data
		var itemId = $("#updateItemModal #id").val();
		var username = $("#updateItemModal #username").val();
		var compIec = $("#updateItemModal #compIec").val();
		var partNumber = $("#updateItemModal #partNumber").val();
		var typeOfPurchase = $("#updateItemModal #typeOfPurchase").val();
		var partDesc = $("#updateItemModal #partDesc").val();
		var uom = $("#updateItemModal #uom").val();
		var hsnNumber = $("#updateItemModal #hsnNumber").val();
		//var createdDate = $("#updateItemModal #createdDate").val();
		//var updateDate = $("#updateItemModal #updateDate").val();
		
		console.log( username
				+ ' --- ' + compIec
				+ ' --- ' + partNumber
				+ ' --- ' + typeOfPurchase
				+ ' --- ' + partDesc
				+ ' --- ' + uom
				+ ' --- ' + hsnNumber
				//+ ' --- ' + createdDate
				//+ ' --- ' + updateDate
		);
		
		$.ajax({
			method: "POST",
			url: "update-item",
			data: { 
				id : itemId,
				username : username,
				compIec : compIec,
				partNumber : partNumber,
				typeOfPurchase : typeOfPurchase,
				partDesc : partDesc,
				uom : uom,
				hsnNumber: hsnNumber,
				//createdDate : createdDate,
				//updateDate : updateDate
			}
		})
		.done(function( msg ) {
			$.dialog('Item updated successfully');
		})
		.fail(function() {
			$.dialog('Failed to update item');
		})
		.always(function() {
			table.ajax.reload();
			$('#updateItemModal').modal('hide');
		});
	});
	
	// Action - delete
	$('#itemTable tbody').on( 'click', '.remove-item', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Delete item: ' + rowData.partNumber,
			buttons: {
				confirm: function () {
					$.post("remove-item", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
}); // END OF READY