$(document).ready(function() {
	
	var table = $('#userTable').DataTable({
		"sAjaxSource" : "/challans",
		"sAjaxDataProp" : "",
		"lengthChange" : false,
		"aoColumns" : [{
			"mData" : "compIec",
		}, {
			"mData" : "purBatchNumber",
		}, {
			"mData" : "challanNumber"
		}, {
			"mData" : "challanDate"
		}, {
			"mData" : "challanAmount"
		}, {
			"bSortable": false,
			"class" : "text-center",
		    "mRender": function(data, type, row) {
		    	var actionMarkup = '<a href="#" class="btn btn-primary btn-circle btn-sm view-challan"><i class="fa fa-file" title="View"></i></a>'
		    		//+ '&nbsp;<a href="#" class="btn btn-info btn-circle btn-sm edit-challan"><i class="fa fa-edit" title="Edit" data-toggle="modal" data-target="#updateChallanModal"></i></a>'
		    		+ '&nbsp;<a href="#" class="btn btn-danger btn-circle btn-sm remove-challan"><i class="fa fa-trash" title="Delete Permanantly"></i></a>';
		    		
		    	return actionMarkup;
		    	
		    }
		 }]
	});
	
	// Action - view
	$('#userTable tbody').on( 'click', '.view-challan', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
	    $.dialog({
	    	columnClass: 'col-md-12',
	        title: 'Challan Details',
	        content: '<div class="table-responsive">' +
	        '<table class="table table-bordered table-hover table-striped table-sm c-view-table challan-details ">' +
	        '<tr> <th class="col-md-4">Fields</th> <th class="col-md-8">Details</th> </tr>' +
	        '<tr> <td>User Name</td> <td>' + rowData.username + '</td> </tr>' +
	        '<tr> <td>Company IEC</td> <td>' + rowData.compIec + '</td> </tr>' +
	        '<tr> <td>Purchase Batch Number</td> <td>' + rowData.purBatchNumber + '</td> </tr>' +
	        '<tr> <td>Challan Number</td> <td>' + rowData.challanNumber + '</td> </tr>' +
	        '<tr> <td>Challan Date</td> <td>' + rowData.challanDate + '</td> </tr>' +
	        '<tr> <td>Challan Amount</td> <td>' + rowData.challanAmount + '</td> </tr>' +
	        '</table></div>',
	    });
	});
	
	// Action - edit
	$('#userTable tbody').on( 'click', '.edit-challan', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		
		$("#updateChallanModal #compIec").val(rowData.compIec);
		$("#updateChallanModal #purBatchNumber").val(rowData.purBatchNumber);
		$("#updateChallanModal #challanNumber").val(rowData.challanNumber);
		$("#updateChallanModal #challanDate").val(rowData.challanDate);
		$("#updateChallanModal #challanAmount").val(rowData.challanAmount);
		$("#updateChallanModal #id").val(rowData.id);
	});
	
	// Action - update save
	$('body').on( 'click', '#updateChallanBtn', function () {
		
		// Extract form data
		var challanId = $("#updateChallanModal #id").val();
		var compIec = $("#updateChallanModal #compIec").val();
		var purBatchNumber = $("#updateChallanModal #purBatchNumber").val();
		var challanNumber = $("#updateChallanModal #challanNumber").val();
		var challanDate = $("#updateChallanModal #challanDate").val();
		var challanAmount = $("#updateChallanModal #challanAmount").val();
		
		console.log( compIec
				+ ' --- ' + purBatchNumber
				+ ' --- ' + challanNumber
				+ ' --- ' + challanDate
				+ ' --- ' + challanAmount
		
		);
		
		$.ajax({
			method: "POST",
			url: "update-challan",
			data: { 
				id : challanId,
				compIec : compIec,
				purBatchNumber : challanNumber,
				challanNumber : challanNumber,
				challanDate : challanDate,
				challanAmount : challanAmount
			}
		})
		.done(function( msg ) {
			$.dialog('Challan updated successfully');
		})
		.fail(function() {
			$.dialog('Failed to update challan');
		})
		.always(function() {
			table.ajax.reload();
			$('#updateChallanModal').modal('hide');
		});
	});
	
	// Action - delete
	$('#userTable tbody').on( 'click', '.remove-challan', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Delete challan: ' + rowData.challanNumber,
			buttons: {
				confirm: function () {
					$.post("remove-challan", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
//	// Action - autosuggest
//	$('body').on( 'click', '#autoSuggestBtn', function () {
//		$.ajax({
//			method: "POST",
//			url: "get-purchase-batch-numbers"
//		})
//		.done(function( data ) {
//			console.log(data);
//		})
//		.fail(function() {
//			$.dialog('Failed to auto suggest purchase batch number');
//			$('#purBatchNumber').val("");
//		})
//		.always(function() {
//			//
//		});
//	});
	
}); // END OF READY