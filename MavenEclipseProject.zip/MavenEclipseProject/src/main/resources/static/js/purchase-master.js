$(document).ready(function() {
	
	var table = $('#purchaseTable').DataTable({
		"sAjaxSource" : "/purchases",
		"sAjaxDataProp" : "",
		"lengthChange" : false,
		"aoColumns" : [{
			"mData" : "purBatchNumber",
		},{
			"mData" : "username",
		}, {
			"mData" : "compIec",
		}, {
			"mData" : "typeOfPurchase"
		}, {
			"mData" : "partNumber"
		}, {
			"mData" : "partDesc"
		}, {
			"mData" : "uom",
			"class" : "text-right"
		},/* {
			"mData" : "createdDate"
		}, {
			"mData" : "updateDate"
		},*/ {
			"bSortable": false,
			"class" : "text-center",
		    "mRender": function(data, type, row) {
		    	var actionMarkup = '<a href="#" class="btn btn-primary btn-circle btn-sm view-purchase"><i class="fa fa-file" title="View"></i></a>'
		    		//+ '&nbsp;<a href="#" class="btn btn-info btn-circle btn-sm edit-purchase"><i class="fa fa-edit" title="Edit" data-toggle="modal" data-target="#updatePurchaseModal"></i></a>'
		    		+ '&nbsp;<a href="#" class="btn btn-danger btn-circle btn-sm remove-purchase"><i class="fa fa-trash" title="Delete Permanantly"></i></a>'
		    		+ '&nbsp;<a href="#" class="btn btn-primary btn-circle btn-sm add-challan" data-toggle="modal" data-target="#addChallanModal"><i class="fa fa-plus" title="add Challan"></i></a>';
		    	return actionMarkup;
		    	
		    }
		 }]
	});
	
	// Action - view
	$('#purchaseTable tbody').on( 'click', '.view-purchase', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		var dutyPaid = 0;
		
		$.ajax({
			method: "POST",
			url: "get-challan-entries",
			data: { 
				compIec : "iec1",
				purBatchNumber : "pbn1"
			}
		}).done(function( challans ) {
			console.log(challans);
			for (var i = 0; i < challans.length; i++) {
				dutyPaid += parseFloat(challans[i].challanAmount);
			}
		}).always(function() {
		    $.dialog({
		    	columnClass: 'col-md-12',
		        title: 'Purchase Details',
		        content: '<div class="table-responsive">' +
		        '<table class="table table-bordered table-hover table-striped table-sm c-view-table purchase-details ">' +
		        '<tr> <th class="col-md-4">Fields</th> <th class="col-md-8">Details</th> </tr>' +
		        '<tr> <td>Part Number</td> <td>' + rowData.partNumber + '</td> </tr>' +
		        '<tr> <td>Part Description</td> <td>' + rowData.partDesc + '</td> </tr>' +
		        '<tr> <td>Type Of Purchase</td> <td>' + rowData.typeOfPurchase + '</td> </tr>' +
		        '<tr> <td>UOM</td> <td>' + rowData.uom + '</td> </tr>' +
		        '<tr> <td>Username</td> <td>' + rowData.username + '</td> </tr>' +
		        '<tr> <td>Company IEC</td> <td>' + rowData.compIec + '</td> </tr>' +
		        '<tr> <td>Purchase Batch Number</td> <td>' + rowData.purBatchNumber + '</td> </tr>' +
		        '<tr> <td>Grr Quantity</td> <td>' + rowData.grrQty + '</td> </tr>' +
		        '<tr> <td>Grr Number</td> <td>' + rowData.grrNo + '</td> </tr>' +
		        '<tr> <td>Purchase Invoice Number</td> <td>' + rowData.purInvNo + '</td> </tr>' +
		        '<tr> <td>Purchase Invoice Date</td> <td>' + rowData.purInvDate + '</td> </tr>' +
		        '<tr> <td>Invoice Bond Number</td> <td>' + rowData.inBondBoeNum + '</td> </tr>' +
		        '<tr> <td>Invoice Bond Date</td> <td>' + rowData.inBondBoeDate + '</td> </tr>' +
		        '<tr> <td>Port Of Import</td> <td>' + rowData.portOfImport + '</td> </tr>' +
		        '<tr> <td>Bottle Seal Number</td> <td>' + rowData.bottleSealNumber + '</td> </tr>' +
		        '<tr> <td>Insuarance Details</td> <td>' + rowData.insuranceDetails + '</td> </tr>' +
		        '<tr> <td>Per Unit Cost</td> <td>' + rowData.perUnitCost + '</td> </tr>' +
		        '<tr> <td>Total Purchase Value</td> <td>' + rowData.totalPurValue + '</td> </tr>' +
		        '<tr> <td>Duty BCD Rate</td> <td>' + rowData.dutyBcdRate + '</td> </tr>' +
		        '<tr> <td>Duty BCD Amount</td> <td>' + rowData.dutyBcdAmt + '</td> </tr>' +
		        '<tr> <td>Duty Cess BCD Amount</td> <td>' + rowData.dutyCessBcdAmt + '</td> </tr>' +
		        '<tr> <td>Duty Cess BCD Rate</td> <td>' + rowData.dutyCessBcdRate + '</td> </tr>' +
		        '<tr> <td>Duty GST Rate</td> <td>' + rowData.dutyGstRate + '</td> </tr>' +
		        '<tr> <td>Duty GST Amount</td> <td>' + rowData.dutyGstAmt + '</td> </tr>' +
		        '<tr> <td>Duty Cess GST Rate</td> <td>' + rowData.dutyCessGstRate + '</td> </tr>' +
		        '<tr> <td>Duty Cess GST Amount</td> <td>' + rowData.dutyCessGstAmt + '</td> </tr>' +
		        '<tr> <td>Duty Other Rate</td> <td>' + rowData.dutyOtherRate + '</td> </tr>' +
		        '<tr> <td>Duty Other Amount</td> <td>' + rowData.dutyOtherAmt + '</td> </tr>' +
		        '<tr> <td>Total GST</td> <td>' + rowData.totalGst + '</td> </tr>' +
		        '<tr> <td>Total Custom Duty</td> <td><b>' + rowData.totalCustomDuty + '</b></td> </tr>' +
		        '<tr> <td>Custom Duty Paid</td> <td><b>' + dutyPaid + '</b></td> </tr>' +
		        '<tr> <td>Balance Custom Duty</td> <td><b>' + (rowData.totalCustomDuty - dutyPaid) + '</b></td> </tr>' +
		        '<tr> <td>Vehicle Registration Number</td> <td>' + rowData.vehicleRegNum + '</td> </tr>' +
		        '<tr> <td>Warehouse Receipt Date</td> <td>' + rowData.warehouseDate + '</td> </tr>' +
		        '<tr> <td>EWAY Bill Number</td> <td>' + rowData.ewayBillNum + '</td> </tr>' +
		        '<tr> <td>EWAY Bill Date</td> <td>' + rowData.ewayBillDate + '</td> </tr>' +
		        '<tr> <td>Created Date</td> <td>' + rowData.createdDate + '</td> </tr>' +
		        '<tr> <td>Updated Date</td> <td>' + rowData.updateDate + '</td> </tr>' +
		        '</table></div>',
		    });
		});
	});
	
	// Action - edit
	$('#purchaseTable tbody').on( 'click', '.edit-purchase', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$("#updatePurchaseModal #username").val(rowData.username);
		$("#updatePurchaseModal #compIec").val(rowData.compIec);
		$("#updatePurchaseModal #partNumber").val(rowData.partNumber);
		$("#updatePurchaseModal #typeOfPurchase").val(rowData.typeOfPurchase);
		$("#updatePurchaseModal #partDesc").val(rowData.partDesc);
		$("#updatePurchaseModal #uom").val(rowData.uom);
		//$("#updatePurchaseModal #createdDate").val(rowData.createdDate);
		//$("#updatePurchaseModal #updateDate").val(rowData.updateDate);
		$("#updatePurchaseModal #id").val(rowData.id);
	});
	
	// Action - add challan
	$('#purchaseTable tbody').on( 'click', '.add-challan', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$("#addChallanModal #compIec").val(rowData.compIec);
		$("#addChallanModal #purBatchNumber").val(rowData.purBatchNumber);
//		$("#addChallanModal #challanNumber").val(rowData.challanNumber);
//		$("#addChallanModal #challanDate").val(rowData.challanDate);
//		$("#addChallanModal #challanAmount").val(rowData.challanAmount);
		$("#addChallanModal #totalCustomDuty").val(rowData.totalCustomDuty);
	});

	// Action - save challan
	$('body').on( 'click', '#addChallanBtn', function () {
		
		// Extract form data
		var compIec = $("#addChallanModal #compIec").val();
		var purBatchNumber = $("#addChallanModal #purBatchNumber").val();
		var challanNumber = $("#addChallanModal #challanNumber").val();
		var challanDate = $("#addChallanModal #challanDate").val();
		var challanAmount = $("#addChallanModal #challanAmount").val();
		
		console.log( compIec
				+ ' --- ' + purBatchNumber
				+ ' --- ' + challanNumber
				+ ' --- ' + challanDate
				+ ' --- ' + challanAmount
		
		);
		
		$.ajax({
			method: "POST",
			url: "add-challan-entry",
			data: { 
				compIec : compIec,
				purBatchNumber : purBatchNumber,
				challanNumber : challanNumber,
				challanDate : challanDate,
				challanAmount : challanAmount
			}
		})
		.done(function( msg ) {
			$.dialog('Challan added successfully');
		})
		.fail(function() {
			$.dialog('Failed to add challan');
		})
		.always(function() {
			table.ajax.reload();
			$('#addChallanModal').modal('hide');
		});
	});
	
	// Action - update save
	$('body').on( 'click', '#updatePurchaseBtn', function () {
		
		// Extract form data
		var purchaseId = $("#updatePurchaseModal #id").val();
		var username = $("#updatePurchaseModal #username").val();
		var compIec = $("#updatePurchaseModal #compIec").val();
		var partNumber = $("#updatePurchaseModal #partNumber").val();
		var typeOfPurchase = $("#updatePurchaseModal #typeOfPurchase").val();
		var partDesc = $("#updatePurchaseModal #partDesc").val();
		var uom = $("#updatePurchaseModal #uom").val();
		//var createdDate = $("#updatePurchaseModal #createdDate").val();
		//var updateDate = $("#updatePurchaseModal #updateDate").val();
		
		console.log( username
				+ ' --- ' + compIec
				+ ' --- ' + partNumber
				+ ' --- ' + typeOfPurchase
				+ ' --- ' + partDesc
				+ ' --- ' + uom
				//+ ' --- ' + createdDate
				//+ ' --- ' + updateDate
		);
		
		$.ajax({
			method: "POST",
			url: "update-purchase",
			data: { 
				id : purchaseId,
				username : username,
				compIec : compIec,
				partNumber : partNumber,
				typeOfPurchase : typeOfPurchase,
				partDesc : partDesc,
				uom : uom,
				//createdDate : createdDate,
				//updateDate : updateDate
			}
		})
		.done(function( msg ) {
			$.dialog('Purchase updated successfully');
		})
		.fail(function() {
			$.dialog('Failed to update purchase');
		})
		.always(function() {
			table.ajax.reload();
			$('#updatePurchaseModal').modal('hide');
		});
	});
	
	// Action - delete
	$('#purchaseTable tbody').on( 'click', '.remove-purchase', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Delete purchase: ' + rowData.purBatchNumber,
			buttons: {
				confirm: function () {
					$.post("remove-purchase", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
}); // END OF READY