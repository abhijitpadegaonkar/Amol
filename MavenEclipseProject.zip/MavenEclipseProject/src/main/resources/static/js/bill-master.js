$(document).ready(function() {
	
	var table = $('#billTable').DataTable({
		"sAjaxSource" : "/bills",
		"sAjaxDataProp" : "",
		"lengthChange" : false,
		"aoColumns" : [{
			"mData" : "prodBatchNumber",
		}, {
			"mData" : "purBatchNumber",
		}, {
			"mData" : "username",
		}, {
			"mData" : "compIec",
		}, {
			"mData" : "partNumber"
		}, {
			"mData" : "partDesc"
		}, {
			"mData" : "uom",
			"class" : "text-right"
		},/* {
			"mData" : "createdDate"
		}, {
			"mData" : "updateDate"
		},*/ {
			"bSortable": false,
			"class" : "text-center",
		    "mRender": function(data, type, row) {
		    	var actionMarkup = '<a href="#" class="btn btn-primary btn-circle btn-sm view-bill"><i class="fa fa-file" title="View"></i></a>'
		    		//+ '&nbsp;<a href="#" class="btn btn-info btn-circle btn-sm edit-bill"><i class="fa fa-edit" title="Edit" data-toggle="modal" data-target="#updateBillModal"></i></a>'
		    		+ '&nbsp;<a href="#" class="btn btn-danger btn-circle btn-sm remove-bill"><i class="fa fa-trash" title="Delete Permanantly"></i></a>';
		    		
		    	return actionMarkup;
		    	
		    }
		 }]
	});
	
	// Action - view
	$('#billTable tbody').on( 'click', '.view-bill', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
	    $.dialog({
	    	columnClass: 'col-md-12',
	        title: 'Bill Details',
			//username, compIec, partNumber, typeOfPurchase, partDesc, uom, createdDate, updateDate

	        content: '<div class="table-responsive">' +
	        '<table class="table table-bordered table-hover table-striped table-sm c-view-table bill-details ">' +
	        '<tr> <th class="col-md-4">Fields</th> <th class="col-md-8">Details</th> </tr>' +
	        '<tr> <td>Part Number</td> <td>' + rowData.partNumber + '</td> </tr>' +
	        '<tr> <td>Part Description</td> <td>' + rowData.partDesc + '</td> </tr>' +
	        '<tr> <td>Unit of Measurement</td> <td>' + rowData.uom + '</td> </tr>' +
	        '<tr> <td>Username</td> <td>' + rowData.username + '</td> </tr>' +
	        '<tr> <td>Company IEC</td> <td>' + rowData.compIec + '</td> </tr>' +
	        '<tr> <td>Recoverable Wastage</td> <td>' + rowData.recWastage + '</td> </tr>' +
	        '<tr> <td>Irrecoverable Wastage</td> <td>' + rowData.irrecWastage + '</td> </tr>' +
	        '<tr> <td>Quantity Consumed</td> <td>' + rowData.netQty + '</td> </tr>' +
	        '<tr> <td>Source of Material</td> <td>' + rowData.sourceOfMaterial + '</td> </tr>' +
	        '<tr> <td>Type of Material</td> <td>' + rowData.typeOfMaterial + '</td> </tr>' +
	        '<tr> <td>Remarks about bill transaction</td> <td>' + rowData.remarks + '</td> </tr>' +
	        '<tr> <td>Purchaser Batch Number</td> <td>' + rowData.purBatchNumber + '</td> </tr>' +
	        '<tr> <td>Production Batch Number</td> <td>' + rowData.prodBatchNumber + '</td> </tr>' +
	        '<tr> <td>Created Date</td> <td>' + rowData.createdDate + '</td> </tr>' +
	        '<tr> <td>Updated Date</td> <td>' + rowData.updateDate + '</td> </tr>' +
	        '</table></div>',
	    });
	});
	
	// Action - edit
	$('#billTable tbody').on( 'click', '.edit-bill', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$("#updateBillModal #username").val(rowData.username);
		$("#updateBillModal #compIec").val(rowData.compIec);
		$("#updateBillModal #partNumber").val(rowData.partNumber);
		$("#updateBillModal #typeOfPurchase").val(rowData.typeOfPurchase);
		$("#updateBillModal #partDesc").val(rowData.partDesc);
		$("#updateBillModal #uom").val(rowData.uom);
		//$("#updateBillModal #createdDate").val(rowData.createdDate);
		//$("#updateBillModal #updateDate").val(rowData.updateDate);
		$("#updateBillModal #id").val(rowData.id);
	});
	
	// Action - update save
	$('body').on( 'click', '#updateBillBtn', function () {
		
		// Extract form data
		var billId = $("#updateBillModal #id").val();
		var username = $("#updateBillModal #username").val();
		var compIec = $("#updateBillModal #compIec").val();
		var partNumber = $("#updateBillModal #partNumber").val();
		var typeOfPurchase = $("#updateBillModal #typeOfPurchase").val();
		var partDesc = $("#updateBillModal #partDesc").val();
		var uom = $("#updateBillModal #uom").val();
		//var createdDate = $("#updateBillModal #createdDate").val();
		//var updateDate = $("#updateBillModal #updateDate").val();
		
		console.log( username
				+ ' --- ' + compIec
				+ ' --- ' + partNumber
				+ ' --- ' + typeOfPurchase
				+ ' --- ' + partDesc
				+ ' --- ' + uom
				//+ ' --- ' + createdDate
				//+ ' --- ' + updateDate
		);
		
		$.ajax({
			method: "POST",
			url: "update-bill",
			data: { 
				//id : billId,
				username : username,
				compIec : compIec,
				partNumber : partNumber,
				partDesc : partDesc,
				uom : uom,
				//createdDate : createdDate,
				//updateDate : updateDate
			}
		})
		.done(function( msg ) {
			$.dialog('Bill updated successfully');
		})
		.fail(function() {
			$.dialog('Failed to update bill');
		})
		.always(function() {
			table.ajax.reload();
			$('#updateBillModal').modal('hide');
		});
	});
	
	// Action - delete
	$('#billTable tbody').on( 'click', '.remove-bill', function () {
		var rowData = table.row( $(this).parents('tr') ).data();
		$.confirm({
			title: 'Please confirm',
			content: 'Delete bill: ' + rowData.partNumber,
			buttons: {
				confirm: function () {
					$.post("remove-bill", { id: rowData.id },
							function(data, status){
								table.ajax.reload();
	    	        		});
					},
					cancel: {
						text: 'cancel',
						btnClass: 'btn-blue',
					}
			}
		});
	});
	
}); // END OF READY